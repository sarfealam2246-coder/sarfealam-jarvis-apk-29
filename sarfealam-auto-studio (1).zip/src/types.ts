export type Language = 'en' | 'hi';
export type ControlMode = 'jarvis' | 'manual';
export type ManualTab = 'copilot' | 'build' | 'vault' | 'admin' | 'skills' | 'secrets';
export type FloatingPanelId =
  | null
  | 'secrets'
  | 'vault'
  | 'admin'
  | 'skills'
  | 'code_explorer'
  | 'system_map';

export type AIProviderId = 'gemini' | 'groq' | 'nvidia' | 'openrouter' | 'cohere';

export interface APIKeyEntry {
  id: string;
  value: string;
  provider: AIProviderId | null;
  providerLabel: string;
  verified: boolean;
  lastError?: string;
}

export type DepartmentId =
  | 'brain'
  | 'code'
  | 'fast'
  | 'vision'
  | 'stt'
  | 'tts'
  | 'reason';

export interface DepartmentAssignment {
  department: DepartmentId;
  label: string;
  provider: AIProviderId | 'native' | null;
  model: string | null;
  keyId: string | null;
  available: boolean;
  missingHint: string;
}

export interface GitHubConfig {
  username: string;
  token: string;
  connected: boolean;
  verifiedLogin?: string;
  avatarUrl?: string;
  lastCheckedAt?: string;
  error?: string;
}

export interface SupabaseServerConfig {
  url: string;
  anonKey: string;
  connected: boolean;
  lastSyncedAt?: string;
  error?: string;
}

export interface SecretsState {
  apiKeys: APIKeyEntry[];
  github: GitHubConfig;
  studioSupabase: SupabaseServerConfig;
  appsSupabase: SupabaseServerConfig;
}

export type ProjectCategory =
  | 'game_3d'
  | 'ecommerce'
  | 'khata_pos'
  | 'ride_booking'
  | 'finance_wallet'
  | 'card_board';

export type TargetEngine = 'flutter' | 'godot4';

export interface Game3DConfig {
  theme: 'golden_highway' | 'tactical_basecamp' | 'neon_city' | 'alpine_rally';
  vehicleType: 'sports_coupe' | 'tactical_jeep' | 'cyber_racer' | 'hero_runner';
  primaryColor: string;
  accentColor: string;
  topSpeed: number;
  timeOfDay: 'golden' | 'noon' | 'night';
  fogDensity: number;
  customBannerDataUrl?: string;
}

export interface CommercialAppConfig {
  category: Exclude<ProjectCategory, 'game_3d'>;
  appName: string;
  tagline: string;
  primaryColor: string;
  accentColor: string;
  currency: string;
  bannerText: string;
  customBannerDataUrl?: string;
  vipUnlocked?: boolean;
  discountPercent?: number;
}

export interface DesignBlueprint {
  id: string;
  title: string;
  prompt: string;
  category: ProjectCategory;
  engine: TargetEngine;
  summary: string;
  themePalette: string[];
  features: string[];
  screensOrZones: string[];
  game3d?: Game3DConfig;
  commercial?: CommercialAppConfig;
  approved: boolean;
  createdAt: string;
}

export interface GeneratedFile {
  path: string;
  language: string;
  content: string;
}

export interface Checkpoint {
  id: string;
  label: string;
  stage: number;
  timestamp: string;
  blueprint: DesignBlueprint;
  files: GeneratedFile[];
}

export interface VaultBuild {
  id: string;
  name: string;
  repoName: string;
  engine: TargetEngine;
  category: ProjectCategory;
  createdAt: string;
  stageReached: number;
  status: 'local_only' | 'pushing' | 'actions_running' | 'apk_ready' | 'failed';
  publicApkUrl?: string;
  ownerAdminUrl?: string;
  repoUrl?: string;
  actionsRunUrl?: string;
  adminPin: string;
  errorMessage?: string;
  files: GeneratedFile[];
  blueprint: DesignBlueprint;
}

export interface DynamicSkill {
  id: string;
  name: string;
  query: string;
  source: 'pub.dev' | 'npm' | 'github' | 'polyhaven' | 'wikipedia' | 'builtin';
  packageName: string;
  description: string;
  url: string;
  enabled: boolean;
  discoveredAt: string;
}

export interface WorkflowTemplates {
  flutterApkYaml: string;
  godotApkYaml: string;
  deployAdminYaml: string;
}

export interface CoreSkillToggles {
  visionSelfHeal: boolean;
  autoCheckpoint: boolean;
  polyHavenAssets: boolean;
  selfDiscoverSkills: boolean;
  dualSupabaseInject: boolean;
}

export interface ChatMessage {
  id: string;
  role: 'user' | 'jarvis' | 'system';
  text: string;
  timestamp: string;
  providerUsed?: string;
  modelUsed?: string;
  toolCalls?: string[];
  imageUrl?: string;
}

export type JarvisStatus = 'idle' | 'listening' | 'thinking' | 'working' | 'speaking';

export interface WorkerNodeState {
  research: 'idle' | 'active' | 'done' | 'error';
  codeAi: 'idle' | 'active' | 'done' | 'error';
  image3d: 'idle' | 'active' | 'done' | 'error';
  githubSupabase: 'idle' | 'active' | 'done' | 'error';
  detail: {
    research: string;
    codeAi: string;
    image3d: string;
    githubSupabase: string;
  };
}

export interface RemoteAdminConfig {
  appSlug: string;
  pin: string;
  bannerTitle: string;
  announcement: string;
  vipUnlocked: boolean;
  speedMultiplier: number;
  discountPercent: number;
  maintenanceMode: boolean;
  updatedAt?: string;
}
