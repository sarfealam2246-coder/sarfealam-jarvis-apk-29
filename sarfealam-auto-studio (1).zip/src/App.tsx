import { useCallback, useEffect, useMemo, useRef, useState } from 'react';
import {
  CheckCircle2,
  Home,
  Mic,
  MicOff,
  Volume2,
  X,
  XCircle,
} from 'lucide-react';
import {
  ChatMessage,
  Checkpoint,
  ControlMode,
  CoreSkillToggles,
  DesignBlueprint,
  DynamicSkill,
  FloatingPanelId,
  GeneratedFile,
  JarvisStatus,
  Language,
  ManualTab,
  RemoteAdminConfig,
  SecretsState,
  TargetEngine,
  VaultBuild,
  WorkerNodeState,
  WorkflowTemplates,
} from './types';
import { t } from './services/i18n';
import {
  buildRoutingAnnouncement,
  computeDepartmentRouting,
  hasAnyAIKey,
  loadSecretsFromLocal,
  saveSecretsToLocal,
} from './services/secretsEngine';
import {
  applyLivePatchToBlueprint,
  createDesignBlueprintFromPrompt,
  DEFAULT_WORKFLOW_TEMPLATES,
  downloadProjectZip,
  generateProjectFiles,
  slugifyProjectName,
} from './services/projectGenerator';
import {
  generateStudioImageWithGemini,
  JarvisToolCall,
  runJarvisBrain,
  runVisionSelfHealQA,
} from './services/aiRouter';
import { fetchExternalSource, discoverDynamicSkill } from './services/externalSources';
import { pushProjectToGitHub } from './services/githubExporter';
import {
  restoreStudioStateFromSupabase,
  syncStudioStateToSupabase,
} from './services/supabaseClient';
import { JarvisDuplexVoiceEngine } from './services/voiceEngine';
import { DisplayA } from './components/DisplayA';
import { ThreeGameViewportHandle } from './components/ThreeGameViewport';
import { JarvisCommandCenter } from './components/JarvisCommandCenter';
import { ManualWorkspace } from './components/ManualWorkspace';
import { SecretsPanel } from './components/SecretsPanel';
import {
  AdminPanel,
  CodeExplorerPanel,
  SkillsPanel,
  SystemMapPanel,
  VaultPanel,
} from './components/StudioPanels';

const STUDIO_STATE_STORAGE = 'sarfealam_autostudio_workspace_v1';

interface SavedWorkspace {
  language: Language;
  vaultBuilds: VaultBuild[];
  checkpoints: Checkpoint[];
  dynamicSkills: DynamicSkill[];
  workflows: WorkflowTemplates;
  coreToggles: CoreSkillToggles;
  adminConfig: RemoteAdminConfig;
}

function loadSavedWorkspace(): SavedWorkspace {
  const defaults: SavedWorkspace = {
    language: 'en',
    vaultBuilds: [],
    checkpoints: [],
    dynamicSkills: [],
    workflows: DEFAULT_WORKFLOW_TEMPLATES,
    coreToggles: {
      visionSelfHeal: true,
      autoCheckpoint: true,
      polyHavenAssets: true,
      selfDiscoverSkills: true,
      dualSupabaseInject: true,
    },
    adminConfig: {
      appSlug: 'apex-highway-3d',
      pin: '1234',
      bannerTitle: 'Live Championship Event',
      announcement: 'Welcome to Sarfealam Auto-Studio powered app!',
      vipUnlocked: false,
      speedMultiplier: 1.0,
      discountPercent: 15,
      maintenanceMode: false,
    },
  };
  try {
    const raw = localStorage.getItem(STUDIO_STATE_STORAGE);
    if (!raw) return defaults;
    const parsed = JSON.parse(raw) as Partial<SavedWorkspace>;
    return {
      ...defaults,
      ...parsed,
      workflows: { ...defaults.workflows, ...(parsed.workflows || {}) },
      coreToggles: { ...defaults.coreToggles, ...(parsed.coreToggles || {}) },
      adminConfig: { ...defaults.adminConfig, ...(parsed.adminConfig || {}) },
    };
  } catch {
    return defaults;
  }
}

export default function App() {
  const initialWorkspace = useMemo(() => loadSavedWorkspace(), []);
  const [lang, setLang] = useState<Language>(initialWorkspace.language);
  const [mode, setMode] = useState<ControlMode>('jarvis');
  const [manualTab, setManualTab] = useState<ManualTab>('build');
  const [floatingPanel, setFloatingPanel] = useState<FloatingPanelId>(null);

  const [secrets, setSecrets] = useState<SecretsState>(() => loadSecretsFromLocal());
  const routing = useMemo(() => computeDepartmentRouting(secrets), [secrets]);

  // Display A & Active Build State
  const [previewVisible, setPreviewVisible] = useState(true);
  const [previewFullscreen, setPreviewFullscreen] = useState(false);
  const [blueprint, setBlueprint] = useState<DesignBlueprint | null>(null);
  const [buildStage, setBuildStage] = useState<number>(0);
  const [isBuilding, setIsBuilding] = useState(false);
  const [generatedFiles, setGeneratedFiles] = useState<GeneratedFile[]>([]);
  const [generatedImageUrl, setGeneratedImageUrl] = useState<string | null>(null);
  const [visionQaBusy, setVisionQaBusy] = useState(false);
  const [visionQaNote, setVisionQaNote] = useState<string | null>(null);
  const [exportBusy, setExportBusy] = useState(false);

  // Persisted Studio Records
  const [vaultBuilds, setVaultBuilds] = useState<VaultBuild[]>(initialWorkspace.vaultBuilds);
  const [checkpoints, setCheckpoints] = useState<Checkpoint[]>(initialWorkspace.checkpoints);
  const [dynamicSkills, setDynamicSkills] = useState<DynamicSkill[]>(initialWorkspace.dynamicSkills);
  const [workflows, setWorkflows] = useState<WorkflowTemplates>(initialWorkspace.workflows);
  const [coreToggles, setCoreToggles] = useState<CoreSkillToggles>(initialWorkspace.coreToggles);
  const [adminConfig, setAdminConfig] = useState<RemoteAdminConfig>(initialWorkspace.adminConfig);

  // JARVIS Live Voice & Pipeline Nodes State
  const [liveVoiceOn, setLiveVoiceOn] = useState(false);
  const [jarvisStatus, setJarvisStatus] = useState<JarvisStatus>('idle');
  const [liveTranscript, setLiveTranscript] = useState('');
  const [lastError, setLastError] = useState<string | undefined>(undefined);
  const [greetingPending, setGreetingPending] = useState(false);

  const [workers, setWorkers] = useState<WorkerNodeState>({
    research: 'idle',
    codeAi: 'idle',
    image3d: 'idle',
    githubSupabase: 'idle',
    detail: {
      research: 'Poly Haven · GitHub · Wiki',
      codeAi: 'Architect · Patcher · Critic',
      image3d: 'Gemini Img · Three.js PBR',
      githubSupabase: 'Direct REST · Dual DB',
    },
  });

  const [messages, setMessages] = useState<ChatMessage[]>(() => [
    {
      id: 'welcome_init',
      role: 'jarvis',
      text: hasAnyAIKey(loadSecretsFromLocal())
        ? t(initialWorkspace.language, 'welcomeReady')
        : t(initialWorkspace.language, 'welcomeNoKeys'),
      timestamp: new Date().toISOString(),
      providerUsed: hasAnyAIKey(loadSecretsFromLocal()) ? 'JARVIS Online' : 'Zero-Key Welcome',
      modelUsed: 'Native Voice Ready',
    },
  ]);

  const threeRef = useRef<ThreeGameViewportHandle | null>(null);
  const buildTimersRef = useRef<number[]>([]);
  const secretsRef = useRef(secrets);
  secretsRef.current = secrets;
  const langRef = useRef(lang);
  langRef.current = lang;
  const blueprintRef = useRef(blueprint);
  blueprintRef.current = blueprint;
  const buildStageRef = useRef(buildStage);
  buildStageRef.current = buildStage;
  const filesRef = useRef(generatedFiles);
  filesRef.current = generatedFiles;
  const messagesRef = useRef(messages);
  messagesRef.current = messages;
  const voiceRef = useRef<JarvisDuplexVoiceEngine | null>(null);

  const appendMessage = useCallback(
    (msg: Omit<ChatMessage, 'id' | 'timestamp'>) => {
      const full: ChatMessage = {
        ...msg,
        id: `m_${Date.now()}_${Math.random().toString(36).slice(2, 6)}`,
        timestamp: new Date().toISOString(),
      };
      setMessages((prev) => [...prev.slice(-40), full]);
      return full.id;
    },
    []
  );

  // Persist workspace locally & sync to Studio Supabase when connected
  useEffect(() => {
    const payload: SavedWorkspace = {
      language: lang,
      vaultBuilds,
      checkpoints: checkpoints.slice(0, 10),
      dynamicSkills,
      workflows,
      coreToggles,
      adminConfig,
    };
    try {
      localStorage.setItem(STUDIO_STATE_STORAGE, JSON.stringify(payload));
    } catch {
      // Ignore storage quota
    }

    if (secrets.studioSupabase.connected) {
      syncStudioStateToSupabase(secrets.studioSupabase, {
        language: lang,
        vaultBuilds,
        checkpoints: checkpoints.slice(0, 10),
        dynamicSkills,
        activePrompt: blueprint?.prompt,
        updatedAt: new Date().toISOString(),
      }).catch(() => {});
    }
  }, [
    lang,
    vaultBuilds,
    checkpoints,
    dynamicSkills,
    workflows,
    coreToggles,
    adminConfig,
    secrets.studioSupabase,
    blueprint?.prompt,
  ]);

  // Restore studio state from Studio Supabase on startup if configured
  const restoreFromStudioSupabase = useCallback(async () => {
    const cfg = secretsRef.current.studioSupabase;
    if (!cfg.connected) return;
    setWorkers((w) => ({
      ...w,
      githubSupabase: 'active',
      detail: { ...w.detail, githubSupabase: 'Restoring Studio DB...' },
    }));
    const res = await restoreStudioStateFromSupabase(cfg);
    if (res.ok && res.data) {
      if (res.data.vaultBuilds.length > 0) setVaultBuilds(res.data.vaultBuilds);
      if (res.data.checkpoints.length > 0) setCheckpoints(res.data.checkpoints);
      if (res.data.dynamicSkills.length > 0) setDynamicSkills(res.data.dynamicSkills);
      setWorkers((w) => ({
        ...w,
        githubSupabase: 'done',
        detail: { ...w.detail, githubSupabase: 'Studio DB Restored' },
      }));
    } else {
      setWorkers((w) => ({
        ...w,
        githubSupabase: 'idle',
        detail: { ...w.detail, githubSupabase: res.error || 'Studio DB Ready' },
      }));
    }
  }, []);

  useEffect(() => {
    if (secrets.studioSupabase.connected) {
      restoreFromStudioSupabase();
    }
  }, [restoreFromStudioSupabase, secrets.studioSupabase.connected]);

  // Save Checkpoint helper
  const pushCheckpoint = useCallback(
    (label: string, bp: DesignBlueprint, stage: number, files: GeneratedFile[]) => {
      if (!coreToggles.autoCheckpoint) return;
      const cp: Checkpoint = {
        id: `cp_${Date.now()}`,
        label,
        stage,
        timestamp: new Date().toISOString(),
        blueprint: JSON.parse(JSON.stringify(bp)),
        files: JSON.parse(JSON.stringify(files)),
      };
      setCheckpoints((prev) => [cp, ...prev.slice(0, 11)]);
    },
    [coreToggles.autoCheckpoint]
  );

  // Cancel active build timers
  const clearBuildTimers = useCallback(() => {
    for (const id of buildTimersRef.current) {
      window.clearTimeout(id);
    }
    buildTimersRef.current = [];
    setIsBuilding(false);
  }, []);

  // 1. Design-First Blueprint Stage
  const handleStartDesign = useCallback(
    (promptText: string, forcedEngine: 'auto' | TargetEngine = 'auto') => {
      clearBuildTimers();
      setGeneratedImageUrl(null);
      setVisionQaNote(null);
      setPreviewVisible(true);
      const bp = createDesignBlueprintFromPrompt(promptText, forcedEngine);
      setBlueprint(bp);
      setBuildStage(0);
      setAdminConfig((prev) => ({
        ...prev,
        appSlug: slugifyProjectName(bp.title),
        bannerTitle: bp.commercial?.bannerText || `${bp.title} Live Event`,
      }));
      const initialFiles = generateProjectFiles(
        bp,
        secretsRef.current.appsSupabase,
        workflows,
        dynamicSkills,
        adminConfig.pin
      );
      setGeneratedFiles(initialFiles);
      setWorkers((w) => ({
        ...w,
        codeAi: 'done',
        image3d: bp.category === 'game_3d' ? 'done' : 'idle',
        detail: {
          ...w.detail,
          codeAi: `Designed: ${bp.title}`,
          image3d: bp.category === 'game_3d' ? '3D PBR Blueprint Ready' : w.detail.image3d,
        },
      }));
    },
    [clearBuildTimers, workflows, dynamicSkills, adminConfig.pin]
  );

  // 2. Progressive 5-Stage Assembly Build
  const handleStartBuild = useCallback(
    (overridePrompt?: string, forcedEngine: 'auto' | TargetEngine = 'auto') => {
      clearBuildTimers();
      let activeBp = blueprintRef.current;
      if (!activeBp || (overridePrompt && overridePrompt.length > 14 && !/design ok|build it|start build/i.test(overridePrompt))) {
        activeBp = createDesignBlueprintFromPrompt(overridePrompt || '3D Highway Sports Car Racer', forcedEngine);
      }
      const approvedBp: DesignBlueprint = { ...activeBp, approved: true };
      setBlueprint(approvedBp);
      setPreviewVisible(true);
      setGeneratedImageUrl(null);
      setIsBuilding(true);
      setJarvisStatus('working');

      const files = generateProjectFiles(
        approvedBp,
        secretsRef.current.appsSupabase,
        workflows,
        dynamicSkills,
        adminConfig.pin
      );
      setGeneratedFiles(files);
      pushCheckpoint(`Before Build: ${approvedBp.title}`, approvedBp, 1, files);

      setWorkers((w) => ({
        ...w,
        codeAi: 'active',
        image3d: 'active',
        detail: {
          ...w.detail,
          codeAi: 'Stage 1/5 App Shell...',
          image3d: approvedBp.category === 'game_3d' ? 'Compiling PBR Shaders' : 'Laying Out Screens',
        },
      }));
      setBuildStage(1);

      const stages: Array<{ stage: number; delay: number; label: string }> = [
        { stage: 2, delay: 650, label: 'Stage 2/5 World & Screens' },
        { stage: 3, delay: 1350, label: 'Stage 3/5 Hero & Core UI' },
        { stage: 4, delay: 2050, label: 'Stage 4/5 Touch Controls & HUD' },
        { stage: 5, delay: 2750, label: 'Stage 5/5 Ready to Test' },
      ];

      stages.forEach(({ stage, delay, label }) => {
        const tid = window.setTimeout(() => {
          setBuildStage(stage);
          setWorkers((w) => ({
            ...w,
            codeAi: stage === 5 ? 'done' : 'active',
            image3d: stage === 5 ? 'done' : 'active',
            detail: {
              ...w.detail,
              codeAi: label,
              image3d: stage === 5 ? 'Display A Interactive' : label,
            },
          }));
          if (stage === 5) {
            setIsBuilding(false);
            setJarvisStatus('idle');
            pushCheckpoint(`Stage 5 Ready: ${approvedBp.title}`, approvedBp, 5, files);
            const doneMsg =
              langRef.current === 'hi'
                ? `${approvedBp.title} का स्टेज 5 बिल्ड पूरा हो गया है सर! डिस्प्ले A पर टेस्ट करें और तैयार होने पर OK दबाएं।`
                : `${approvedBp.title} reached Stage 5 and is ready to test on Display A, Sir. Tap OK when ready to export!`;
            appendMessage({ role: 'jarvis', text: doneMsg });
            voiceRef.current?.speakText(doneMsg, false);
          }
        }, delay);
        buildTimersRef.current.push(tid);
      });
    },
    [clearBuildTimers, workflows, dynamicSkills, adminConfig.pin, pushCheckpoint, appendMessage]
  );

  // 3. Live Hot-Patcher
  const handleHotPatch = useCallback(
    (instruction: string) => {
      const current = blueprintRef.current;
      if (!current) {
        handleStartDesign(instruction);
        return;
      }
      pushCheckpoint(`Before Patch: ${instruction.slice(0, 24)}`, current, buildStageRef.current, filesRef.current);
      const { updated, summary } = applyLivePatchToBlueprint(current, instruction);
      setBlueprint(updated);
      const nextFiles = generateProjectFiles(
        updated,
        secretsRef.current.appsSupabase,
        workflows,
        dynamicSkills,
        adminConfig.pin
      );
      setGeneratedFiles(nextFiles);
      setWorkers((w) => ({
        ...w,
        codeAi: 'done',
        detail: { ...w.detail, codeAi: `Patched: ${summary.slice(0, 28)}` },
      }));
      appendMessage({
        role: 'system',
        text: `Live Hot-Patch applied (${summary}). Checkpoint saved for 1-second rollback.`,
      });
    },
    [handleStartDesign, pushCheckpoint, workflows, dynamicSkills, adminConfig.pin, appendMessage]
  );

  // 4. 1-Second Checkpoint Rollback
  const handleRollback = useCallback(
    (specific?: Checkpoint) => {
      const target = specific || checkpoints[0];
      if (!target) {
        appendMessage({ role: 'system', text: 'No saved checkpoints available to roll back.' });
        return;
      }
      setBlueprint(target.blueprint);
      setBuildStage(target.stage);
      setGeneratedFiles(target.files);
      setPreviewVisible(true);
      if (!specific) {
        setCheckpoints((prev) => prev.slice(1));
      }
      const msg =
        langRef.current === 'hi'
          ? `चेकपॉइंट "${target.label}" 1 सेकंड में रीस्टोर हो गया सर।`
          : `Restored checkpoint "${target.label}" in 1 second, Sir.`;
      appendMessage({ role: 'jarvis', text: msg });
      voiceRef.current?.speakText(msg, false);
    },
    [checkpoints, appendMessage]
  );

  // 5. Vision Self-Heal QA
  const handleRunVisionQa = useCallback(async () => {
    const bp = blueprintRef.current;
    if (!bp) return;
    setVisionQaBusy(true);
    setWorkers((w) => ({
      ...w,
      image3d: 'active',
      detail: { ...w.detail, image3d: 'Vision QA Inspecting...' },
    }));

    const snapshot = threeRef.current?.captureSnapshot();
    if (!snapshot) {
      setVisionQaNote(
        bp.category === 'game_3d'
          ? '3D canvas still initializing. Try Vision QA again in a moment.'
          : 'Commercial DOM UI verified: responsive layout, zero broken images, active state handlers.'
      );
      setVisionQaBusy(false);
      setWorkers((w) => ({ ...w, image3d: 'done', detail: { ...w.detail, image3d: 'UI Verified' } }));
      return;
    }

    const qa = await runVisionSelfHealQA(secretsRef.current, snapshot, bp.title);
    setVisionQaNote(`${qa.provider}: ${qa.diagnosis}`);
    appendMessage({
      role: 'jarvis',
      text: `Vision QA (${qa.provider}): ${qa.diagnosis}`,
    });
    if (qa.suggestedPatch) {
      handleHotPatch(qa.suggestedPatch);
    }
    setWorkers((w) => ({
      ...w,
      image3d: qa.ok ? 'done' : 'error',
      detail: { ...w.detail, image3d: qa.ok ? 'Vision QA Passed' : 'Missing Vision Key' },
    }));
    setVisionQaBusy(false);
  }, [appendMessage, handleHotPatch]);

  // 6. Gemini Image Generation -> Display A
  const handleGenerateImage = useCallback(
    async (prompt: string) => {
      setWorkers((w) => ({
        ...w,
        image3d: 'active',
        detail: { ...w.detail, image3d: 'Generating Gemini Image...' },
      }));
      const res = await generateStudioImageWithGemini(secretsRef.current, prompt);
      if (res.ok && res.imageUrl) {
        setGeneratedImageUrl(res.imageUrl);
        setPreviewVisible(true);
        setWorkers((w) => ({
          ...w,
          image3d: 'done',
          detail: { ...w.detail, image3d: 'Image Displayed on A' },
        }));
      } else {
        setLastError(res.message);
        setWorkers((w) => ({
          ...w,
          image3d: 'error',
          detail: { ...w.detail, image3d: 'Gemini Key Required' },
        }));
      }
      appendMessage({ role: 'jarvis', text: res.message, imageUrl: res.imageUrl });
      voiceRef.current?.speakText(res.message, false);
    },
    [appendMessage]
  );

  const handleApplyGeneratedImage = useCallback(() => {
    if (!generatedImageUrl || !blueprint) return;
    const next: DesignBlueprint = JSON.parse(JSON.stringify(blueprint));
    if (next.game3d) next.game3d.customBannerDataUrl = generatedImageUrl;
    if (next.commercial) next.commercial.customBannerDataUrl = generatedImageUrl;
    setBlueprint(next);
    setGeneratedImageUrl(null);
    appendMessage({ role: 'system', text: 'Applied generated Gemini image into active Display A preview.' });
  }, [generatedImageUrl, blueprint, appendMessage]);

  // 7. End-to-End OK Export -> GitHub Direct Push (Public APK + Owner Admin Web Link) OR Local ZIP
  const handleOkExport = useCallback(async () => {
    const bp = blueprintRef.current;
    if (!bp || buildStageRef.current < 5) {
      const msg =
        langRef.current === 'hi'
          ? 'OK एक्सपोर्ट स्टेज 5 टेस्ट के बाद अनलॉक होता है सर।'
          : 'Complete Stage 5 testing on Display A first to unlock OK Export, Sir.';
      appendMessage({ role: 'jarvis', text: msg });
      voiceRef.current?.speakText(msg, false);
      return;
    }

    setExportBusy(true);
    setJarvisStatus('working');
    const repoName = `${slugifyProjectName(bp.title)}-${Date.now().toString().slice(-3)}`;
    const files = generateProjectFiles(
      bp,
      secretsRef.current.appsSupabase,
      workflows,
      dynamicSkills,
      adminConfig.pin
    );
    setGeneratedFiles(files);

    const gh = secretsRef.current.github;

    // Fallback: Local ZIP download when GitHub PAT is not yet connected
    if (!gh.connected || !gh.token || !gh.username) {
      await downloadProjectZip(repoName, files);
      const localBuild: VaultBuild = {
        id: `build_${Date.now()}`,
        name: bp.title,
        repoName,
        engine: bp.engine,
        category: bp.category,
        createdAt: new Date().toISOString(),
        stageReached: 5,
        status: 'local_only',
        adminPin: adminConfig.pin,
        files,
        blueprint: bp,
      };
      setVaultBuilds((prev) => [localBuild, ...prev]);
      const msg =
        langRef.current === 'hi'
          ? 'गिटहब कनेक्ट नहीं था, इसलिए पूरा प्रोजेक्ट ZIP में डाउनलोड कर दिया है और वॉल्ट में सेव कर दिया है। ऑटोमैटिक APK और एडमिन वेब लिंक के लिए सीक्रेट्स में गिटहब जोड़ें।'
          : 'GitHub is not connected yet, so I downloaded the complete project ZIP locally and saved it in Vault. Connect GitHub in Secrets for automatic Public APK + Owner Admin Web Links.';
      appendMessage({ role: 'jarvis', text: msg });
      voiceRef.current?.speakText(msg, false);
      setFloatingPanel('vault');
      setExportBusy(false);
      setJarvisStatus('idle');
      return;
    }

    // Real Direct GitHub Push -> Actions APK Build + GitHub Pages Owner Admin Panel
    setWorkers((w) => ({
      ...w,
      githubSupabase: 'active',
      detail: { ...w.detail, githubSupabase: 'Pushing to GitHub...' },
    }));

    const pushRes = await pushProjectToGitHub(
      gh.verifiedLogin || gh.username,
      gh.token,
      repoName,
      files,
      (step) => {
        setWorkers((w) => ({
          ...w,
          githubSupabase: 'active',
          detail: { ...w.detail, githubSupabase: step.slice(0, 32) },
        }));
      }
    );

    const buildRecord: VaultBuild = {
      id: `build_${Date.now()}`,
      name: bp.title,
      repoName,
      engine: bp.engine,
      category: bp.category,
      createdAt: new Date().toISOString(),
      stageReached: 5,
      status: pushRes.ok ? 'actions_running' : 'failed',
      repoUrl: pushRes.repoUrl,
      publicApkUrl: pushRes.publicApkUrl,
      ownerAdminUrl: pushRes.ownerAdminUrl,
      actionsRunUrl: pushRes.actionsRunUrl,
      adminPin: adminConfig.pin,
      errorMessage: pushRes.ok ? undefined : pushRes.message,
      files,
      blueprint: bp,
    };

    setVaultBuilds((prev) => [buildRecord, ...prev]);
    setWorkers((w) => ({
      ...w,
      githubSupabase: pushRes.ok ? 'done' : 'error',
      detail: {
        ...w.detail,
        githubSupabase: pushRes.ok ? 'Actions + Admin Live' : 'GitHub Push Failed',
      },
    }));

    if (!pushRes.ok) setLastError(pushRes.message);

    appendMessage({ role: 'jarvis', text: pushRes.message });
    voiceRef.current?.speakText(pushRes.message, false);
    setFloatingPanel('vault');
    setExportBusy(false);
    setJarvisStatus('idle');
  }, [workflows, dynamicSkills, adminConfig.pin, appendMessage]);

  // Execute JARVIS Tool Calls
  const executeToolCalls = useCallback(
    async (calls: JarvisToolCall[]) => {
      for (const call of calls) {
        const args = call.args || {};
        switch (call.name) {
          case 'hide_preview':
            setPreviewVisible(false);
            setPreviewFullscreen(false);
            break;
          case 'show_preview':
            setPreviewVisible(true);
            break;
          case 'fullscreen_preview':
            setPreviewVisible(true);
            setPreviewFullscreen(args.enabled !== false);
            break;
          case 'open_floating_panel': {
            const p = String(args.panel || 'secrets') as FloatingPanelId;
            if (mode === 'manual') {
              if (p === 'secrets' || p === 'vault' || p === 'admin' || p === 'skills') {
                setManualTab(p);
              } else {
                setFloatingPanel(p);
              }
            } else {
              setFloatingPanel(p);
            }
            break;
          }
          case 'close_panel':
            setFloatingPanel(null);
            break;
          case 'switch_mode':
            setMode(args.mode === 'manual' ? 'manual' : 'jarvis');
            break;
          case 'switch_language': {
            const nextLang: Language = args.language === 'hi' ? 'hi' : 'en';
            setLang(nextLang);
            voiceRef.current?.setLanguage(nextLang);
            break;
          }
          case 'start_design':
            handleStartDesign(String(args.prompt || '3D Highway Sports Car'));
            break;
          case 'start_build':
            handleStartBuild(
              args.prompt ? String(args.prompt) : undefined,
              (args.engine as 'auto' | TargetEngine) || 'auto'
            );
            break;
          case 'patch_live_code':
            handleHotPatch(String(args.instruction || ''));
            break;
          case 'rollback_checkpoint':
            handleRollback();
            break;
          case 'generate_image':
            await handleGenerateImage(String(args.prompt || 'Futuristic studio app banner'));
            break;
          case 'fetch_external_source': {
            const q = String(args.query || '');
            const kind = String(args.kind || 'general');
            setWorkers((w) => ({
              ...w,
              research: 'active',
              detail: { ...w.detail, research: `Searching ${kind}: ${q.slice(0, 18)}` },
            }));
            if (kind === 'skill' && coreToggles.selfDiscoverSkills) {
              const sk = await discoverDynamicSkill(q);
              if (sk) {
                setDynamicSkills((prev) => [sk, ...prev]);
                appendMessage({
                  role: 'system',
                  text: `Self-Discovered Skill registered: ${sk.packageName} (${sk.source}) — ${sk.description}`,
                });
              }
            } else {
              const results = await fetchExternalSource(q, kind);
              const summary = results.length
                ? results.map((r) => `• ${r.title} (${r.source}): ${r.description}`).join('\n')
                : `No live results found for "${q}".`;
              appendMessage({ role: 'system', text: summary });
            }
            setWorkers((w) => ({
              ...w,
              research: 'done',
              detail: { ...w.detail, research: `Found sources for ${q.slice(0, 16)}` },
            }));
            break;
          }
          case 'inspect_and_fix_error': {
            const errTxt = String(args.errorText || lastError || '');
            appendMessage({
              role: 'system',
              text: errTxt
                ? `Diagnosed Error: ${errTxt}. Verify Secrets keys, GitHub PAT repo+workflow scopes, or Supabase SQL tables.`
                : 'No active studio errors detected.',
            });
            break;
          }
          case 'ok_export':
            await handleOkExport();
            break;
          case 'cancel_build':
            clearBuildTimers();
            setBuildStage(0);
            break;
          default:
            break;
        }
      }
    },
    [
      mode,
      handleStartDesign,
      handleStartBuild,
      handleHotPatch,
      handleRollback,
      handleGenerateImage,
      coreToggles.selfDiscoverSkills,
      appendMessage,
      lastError,
      handleOkExport,
      clearBuildTimers,
    ]
  );

  // Unified User Prompt Handler (Voice or Text)
  const handleUserPrompt = useCallback(
    async (text: string) => {
      const clean = text.trim();
      if (!clean) return;

      // Instant mid-call language switch detection even before LLM roundtrip
      if (/speak in hindi|hindi me|हिंदी में बोलो/i.test(clean)) {
        setLang('hi');
        voiceRef.current?.setLanguage('hi');
      } else if (/switch to english|speak in english|अंग्रेजी में बोलो/i.test(clean)) {
        setLang('en');
        voiceRef.current?.setLanguage('en');
      }

      appendMessage({ role: 'user', text: clean });
      setJarvisStatus('thinking');

      const streamingMsgId = `m_stream_${Date.now()}`;
      setMessages((prev) => [
        ...prev,
        {
          id: streamingMsgId,
          role: 'jarvis',
          text: '...',
          timestamp: new Date().toISOString(),
        },
      ]);

      const ctx = {
        language: langRef.current,
        mode,
        previewVisible,
        previewFullscreen,
        activePanel: floatingPanel,
        buildStage: buildStageRef.current,
        hasBlueprint: Boolean(blueprintRef.current),
        blueprintTitle: blueprintRef.current?.title,
        blueprintCategory: blueprintRef.current?.category,
        blueprintEngine: blueprintRef.current?.engine,
        githubConnected: secretsRef.current.github.connected,
        studioSupaConnected: secretsRef.current.studioSupabase.connected,
        appsSupaConnected: secretsRef.current.appsSupabase.connected,
        checkpointCount: checkpoints.length,
        lastError,
      };

      const res = await runJarvisBrain(
        secretsRef.current,
        messagesRef.current,
        clean,
        ctx,
        (partial) => {
          setMessages((prev) =>
            prev.map((m) => (m.id === streamingMsgId ? { ...m, text: partial } : m))
          );
        },
        (sentence) => {
          if (liveVoiceOn || voiceRef.current?.isRunning()) {
            voiceRef.current?.speakSentenceStreamed(sentence);
          }
        }
      );

      setMessages((prev) =>
        prev.map((m) =>
          m.id === streamingMsgId
            ? {
                ...m,
                text: res.text || (res.toolCalls.length ? 'Done, Sir.' : 'Ready, Sir.'),
                providerUsed: res.providerUsed,
                modelUsed: res.modelUsed,
                toolCalls: res.toolCalls.map((tc) => tc.name),
              }
            : m
        )
      );

      if (res.error) setLastError(res.error);

      if (res.toolCalls.length > 0) {
        await executeToolCalls(res.toolCalls);
      }

      setJarvisStatus((prev) => (prev === 'thinking' ? (liveVoiceOn ? 'listening' : 'idle') : prev));
    },
    [
      appendMessage,
      mode,
      previewVisible,
      previewFullscreen,
      floatingPanel,
      checkpoints.length,
      lastError,
      liveVoiceOn,
      executeToolCalls,
    ]
  );

  // Initialize Duplex Live Voice Engine
  useEffect(() => {
    const engine = new JarvisDuplexVoiceEngine(
      {
        onTranscriptInterim: (txt) => setLiveTranscript(txt),
        onTranscriptFinal: (finalText) => {
          setLiveTranscript('');
          handleUserPrompt(finalText);
        },
        onStateChange: (st) => {
          if (st === 'speaking') setJarvisStatus('speaking');
          else if (st === 'listening' || st === 'fallback_whisper') setJarvisStatus('listening');
          else setJarvisStatus('idle');
        },
        onError: (err) => {
          setLastError(err);
          appendMessage({ role: 'system', text: err });
        },
      },
      () => secretsRef.current
    );
    voiceRef.current = engine;

    // Zero-Key First-Open Welcome speech attempt (gracefully handles browser autoplay lock)
    const greeting = hasAnyAIKey(secretsRef.current)
      ? t(langRef.current, 'welcomeReady')
      : t(langRef.current, 'welcomeNoKeys');
    try {
      engine.setLanguage(langRef.current);
      if (typeof window !== 'undefined' && 'speechSynthesis' in window) {
        engine.speakText(greeting, true);
        setGreetingPending(true);
      }
    } catch {
      setGreetingPending(true);
    }

    return () => {
      engine.stopLive();
    };
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, []);

  // Keep engine handler fresh via ref wrapper
  const promptHandlerRef = useRef(handleUserPrompt);
  promptHandlerRef.current = handleUserPrompt;

  const handleToggleLiveVoice = async () => {
    const engine = voiceRef.current;
    if (!engine) return;
    setGreetingPending(false);

    if (liveVoiceOn) {
      engine.stopLive();
      setLiveVoiceOn(false);
      setLiveTranscript('');
      setJarvisStatus('idle');
    } else {
      setLiveVoiceOn(true);
      // Re-bind latest final callback cleanly via engine restart
      engine.stopLive();
      const fresh = new JarvisDuplexVoiceEngine(
        {
          onTranscriptInterim: (txt) => setLiveTranscript(txt),
          onTranscriptFinal: (finalText) => {
            setLiveTranscript('');
            promptHandlerRef.current(finalText);
          },
          onStateChange: (st) => {
            if (st === 'speaking') setJarvisStatus('speaking');
            else if (st === 'listening' || st === 'fallback_whisper') setJarvisStatus('listening');
            else setJarvisStatus('idle');
          },
          onError: (err) => {
            setLastError(err);
            appendMessage({ role: 'system', text: err });
          },
        },
        () => secretsRef.current
      );
      voiceRef.current = fresh;
      await fresh.startLive(lang);
    }
  };

  // Save Secrets + Auto-Route + Spoken Announcement
  const handleSaveSecrets = (next: SecretsState, announceRouting: boolean) => {
    setSecrets(next);
    saveSecretsToLocal(next);
    if (announceRouting) {
      const nextRouting = computeDepartmentRouting(next);
      const announcement = buildRoutingAnnouncement(nextRouting, lang);
      appendMessage({ role: 'jarvis', text: announcement, providerUsed: 'Auto-Router', modelUsed: 'System Map' });
      voiceRef.current?.setLanguage(lang);
      voiceRef.current?.speakText(announcement, true);
    }
  };

  const handleToggleLanguage = (nextLang: Language) => {
    setLang(nextLang);
    voiceRef.current?.setLanguage(nextLang);
  };

  const handleCancelAction = () => {
    clearBuildTimers();
    voiceRef.current?.cancelSpeech();
    if (floatingPanel) {
      setFloatingPanel(null);
    } else {
      setBuildStage(0);
      setGeneratedImageUrl(null);
      setVisionQaNote(null);
    }
  };

  const handleHomeAction = () => {
    clearBuildTimers();
    setFloatingPanel(null);
    setPreviewFullscreen(false);
    setPreviewVisible(true);
    setGeneratedImageUrl(null);
    setMode('jarvis');
  };

  const okEnabled = Boolean(blueprint && buildStage >= 5 && !exportBusy);

  return (
    <div className="min-h-screen bg-[#070b14] text-slate-100 flex flex-col">
      {/* HEADER: Sarfealam Auto-Studio | English | हिंदी | JARVIS | Manual */}
      <header className="sticky top-0 z-30 h-14 px-3 sm:px-5 bg-[#070b14]/95 border-b border-white/10 flex items-center justify-between gap-3">
        {/* Zone 1: Brand Title */}
        <div className="font-display text-sm sm:text-base font-bold tracking-tight text-white whitespace-nowrap shrink-0">
          {t(lang, 'appName')}
        </div>

        {/* Zone 2 & 3: Language Toggle + JARVIS | Manual Switch */}
        <div className="flex items-center gap-2 shrink-0">
          <div className="flex items-center p-0.5 rounded-lg bg-[#0b1120] border border-white/10">
            <button
              type="button"
              onClick={() => handleToggleLanguage('en')}
              className={`px-2.5 py-1 min-h-[30px] rounded-md text-xs font-medium whitespace-nowrap transition-colors ${
                lang === 'en' ? 'bg-cyan-500 text-slate-950 font-semibold' : 'text-slate-400 hover:text-white'
              }`}
            >
              English
            </button>
            <button
              type="button"
              onClick={() => handleToggleLanguage('hi')}
              className={`px-2.5 py-1 min-h-[30px] rounded-md text-xs font-medium whitespace-nowrap transition-colors ${
                lang === 'hi' ? 'bg-cyan-500 text-slate-950 font-semibold' : 'text-slate-400 hover:text-white'
              }`}
            >
              हिंदी
            </button>
          </div>

          <div className="flex items-center p-0.5 rounded-lg bg-[#0b1120] border border-white/10">
            <button
              type="button"
              onClick={() => setMode('jarvis')}
              className={`px-2.5 py-1 min-h-[30px] rounded-md text-xs font-medium whitespace-nowrap transition-colors ${
                mode === 'jarvis' ? 'bg-purple-500 text-white font-semibold' : 'text-slate-400 hover:text-white'
              }`}
            >
              {t(lang, 'jarvisMode')}
            </button>
            <button
              type="button"
              onClick={() => setMode('manual')}
              className={`px-2.5 py-1 min-h-[30px] rounded-md text-xs font-medium whitespace-nowrap transition-colors ${
                mode === 'manual' ? 'bg-purple-500 text-white font-semibold' : 'text-slate-400 hover:text-white'
              }`}
            >
              {t(lang, 'manualMode')}
            </button>
          </div>
        </div>
      </header>

      {/* Optional Zero-Key First-Open Tap-to-Hear Welcome Bar (Mobile WebView autoplay helper) */}
      {greetingPending && !hasAnyAIKey(secrets) && (
        <div className="px-3 sm:px-5 py-2 bg-[#0b1120] border-b border-cyan-500/30 flex items-center justify-between gap-2 text-xs">
          <button
            type="button"
            onClick={() => {
              setGreetingPending(false);
              voiceRef.current?.setLanguage(lang);
              voiceRef.current?.speakText(t(lang, 'welcomeNoKeys'), true);
            }}
            className="flex items-center gap-2 text-cyan-300 hover:text-cyan-200 text-left"
          >
            <Volume2 className="w-4 h-4 shrink-0" />
            <span className="line-clamp-1">{t(lang, 'welcomeNoKeys')}</span>
          </button>
          <div className="flex items-center gap-1.5 shrink-0">
            <button
              type="button"
              onClick={() => {
                setGreetingPending(false);
                if (mode === 'manual') setManualTab('secrets');
                else setFloatingPanel('secrets');
              }}
              className="px-2.5 py-1 rounded-lg bg-cyan-500 text-slate-950 font-semibold whitespace-nowrap"
            >
              Open Secrets
            </button>
            <button
              type="button"
              onClick={() => setGreetingPending(false)}
              className="p-1 text-slate-400 hover:text-white"
              aria-label="Dismiss"
            >
              <X className="w-3.5 h-3.5" />
            </button>
          </div>
        </div>
      )}

      {/* MAIN RESPONSIVE WORKSPACE (Mobile stacked | Desktop 1440px 2-column split) */}
      <main className="flex-1 w-full max-w-[1440px] mx-auto px-3 sm:px-5 pt-3 pb-24">
        <div
          className={`grid gap-3 sm:gap-4 ${
            previewVisible ? 'grid-cols-1 lg:grid-cols-12' : 'grid-cols-1'
          }`}
        >
          {/* DISPLAY A — Full-Display 3D WebGL PBR & Commercial App Viewport */}
          {previewVisible && (
            <div className="lg:col-span-7">
              <DisplayA
                lang={lang}
                blueprint={blueprint}
                buildStage={buildStage}
                isBuilding={isBuilding}
                fullscreen={previewFullscreen}
                generatedImageUrl={generatedImageUrl}
                visionQaBusy={visionQaBusy}
                visionQaNote={visionQaNote}
                threeRef={threeRef}
                onToggleFullscreen={() => setPreviewFullscreen((f) => !f)}
                onApproveDesignAndBuild={() => handleStartBuild()}
                onRunVisionQa={handleRunVisionQa}
                onApplyGeneratedImage={handleApplyGeneratedImage}
                onClearGeneratedImage={() => setGeneratedImageUrl(null)}
                onQuickStartPrompt={(prompt) => handleStartDesign(prompt)}
              />
            </div>
          )}

          {/* JARVIS COMMAND CENTER OR MANUAL 6-TAB WORKSPACE */}
          <div className={previewVisible ? 'lg:col-span-5' : 'max-w-4xl mx-auto w-full'}>
            {mode === 'jarvis' ? (
              <JarvisCommandCenter
                lang={lang}
                jarvisStatus={jarvisStatus}
                liveTranscript={liveTranscript}
                messages={messages}
                workers={workers}
                secrets={secrets}
                routing={routing}
                previewVisible={previewVisible}
                checkpointCount={checkpoints.length}
                onSendPrompt={handleUserPrompt}
                onOpenPanel={(panel) => setFloatingPanel(panel)}
                onTogglePreview={() => setPreviewVisible((v) => !v)}
                onRollback={() => handleRollback()}
              />
            ) : (
              <ManualWorkspace
                lang={lang}
                activeTab={manualTab}
                onChangeTab={setManualTab}
                onSummonJarvis={() => setMode('jarvis')}
                messages={messages}
                blueprint={blueprint}
                buildStage={buildStage}
                isBuilding={isBuilding}
                files={generatedFiles}
                checkpoints={checkpoints}
                onSendPrompt={handleUserPrompt}
                onStartDesign={handleStartDesign}
                onStartBuild={() => handleStartBuild()}
                onHotPatch={handleHotPatch}
                onGenerateImage={handleGenerateImage}
                onRunVisionQa={handleRunVisionQa}
                onRollback={() => handleRollback()}
                builds={vaultBuilds}
                secrets={secrets}
                routing={routing}
                adminConfig={adminConfig}
                coreToggles={coreToggles}
                workflows={workflows}
                dynamicSkills={dynamicSkills}
                onSaveSecrets={handleSaveSecrets}
                onRestoreFromStudioSupabase={restoreFromStudioSupabase}
                onUpdateBuild={(id, patch) =>
                  setVaultBuilds((prev) => prev.map((b) => (b.id === id ? { ...b, ...patch } : b)))
                }
                onRestoreCheckpoint={(cp) => handleRollback(cp)}
                onChangeAdminConfig={setAdminConfig}
                onChangeToggles={setCoreToggles}
                onChangeWorkflows={setWorkflows}
                onAddDynamicSkill={(sk) => setDynamicSkills((prev) => [sk, ...prev])}
                onToggleDynamicSkill={(id) =>
                  setDynamicSkills((prev) =>
                    prev.map((s) => (s.id === id ? { ...s, enabled: !s.enabled } : s))
                  )
                }
              />
            )}
          </div>
        </div>
      </main>

      {/* ON-DEMAND FLOATING MINI-WINDOW DRAWER (Triggered by JARVIS Voice or Quick Bar) */}
      {floatingPanel && (
        <div
          className="fixed inset-0 z-40 bg-black/65 flex items-end sm:items-center justify-center p-0 sm:p-4"
          onClick={() => setFloatingPanel(null)}
        >
          <div
            className="w-full sm:max-w-3xl max-h-[86vh] rounded-t-3xl sm:rounded-2xl bg-[#070b14] border border-white/15 flex flex-col overflow-hidden shadow-2xl"
            onClick={(e) => e.stopPropagation()}
          >
            <div className="px-4 py-3 border-b border-white/10 bg-[#0b1120] flex items-center justify-between">
              <div className="text-sm font-bold text-white capitalize">
                {floatingPanel.replace('_', ' ')}
              </div>
              <button
                type="button"
                onClick={() => setFloatingPanel(null)}
                className="min-h-[36px] min-w-[36px] rounded-lg bg-white/5 hover:bg-white/10 text-slate-300 flex items-center justify-center"
                aria-label="Close panel"
              >
                <X className="w-4 h-4" />
              </button>
            </div>
            <div className="flex-1 overflow-y-auto p-4">
              {floatingPanel === 'secrets' && (
                <SecretsPanel
                  lang={lang}
                  secrets={secrets}
                  routing={routing}
                  onSaveSecrets={handleSaveSecrets}
                  onRestoreFromStudioSupabase={restoreFromStudioSupabase}
                />
              )}
              {floatingPanel === 'vault' && (
                <VaultPanel
                  lang={lang}
                  builds={vaultBuilds}
                  checkpoints={checkpoints}
                  secrets={secrets}
                  onUpdateBuild={(id, patch) =>
                    setVaultBuilds((prev) => prev.map((b) => (b.id === id ? { ...b, ...patch } : b)))
                  }
                  onRestoreCheckpoint={(cp) => {
                    handleRollback(cp);
                    setFloatingPanel(null);
                  }}
                />
              )}
              {floatingPanel === 'admin' && (
                <AdminPanel
                  secrets={secrets}
                  adminConfig={adminConfig}
                  latestBuild={vaultBuilds[0]}
                  onChangeConfig={setAdminConfig}
                />
              )}
              {floatingPanel === 'skills' && (
                <SkillsPanel
                  coreToggles={coreToggles}
                  workflows={workflows}
                  dynamicSkills={dynamicSkills}
                  onChangeToggles={setCoreToggles}
                  onChangeWorkflows={setWorkflows}
                  onAddDynamicSkill={(sk) => setDynamicSkills((prev) => [sk, ...prev])}
                  onToggleDynamicSkill={(id) =>
                    setDynamicSkills((prev) =>
                      prev.map((s) => (s.id === id ? { ...s, enabled: !s.enabled } : s))
                    )
                  }
                />
              )}
              {floatingPanel === 'code_explorer' && <CodeExplorerPanel files={generatedFiles} />}
              {floatingPanel === 'system_map' && (
                <SystemMapPanel
                  routing={routing}
                  secrets={secrets}
                  onOpenSecrets={() => setFloatingPanel('secrets')}
                />
              )}
            </div>
          </div>
        </div>
      )}

      {/* FIXED BOTTOM BAR: Cancel | glowing Live ON/OFF | OK (enabled after Stage 5) | Home */}
      <footer className="fixed bottom-0 left-0 right-0 z-30 bg-[#070b14]/95 border-t border-white/10 px-3 sm:px-5 pt-2 pb-safe">
        <div className="max-w-2xl mx-auto grid grid-cols-4 items-center gap-2">
          <button
            type="button"
            onClick={handleCancelAction}
            className="min-h-[44px] rounded-xl bg-[#0b1120] hover:bg-rose-950/50 border border-white/10 text-xs font-semibold text-slate-200 flex items-center justify-center gap-1.5 transition-colors"
          >
            <XCircle className="w-4 h-4 text-rose-400" />
            <span>{t(lang, 'cancel')}</span>
          </button>

          <button
            type="button"
            onClick={handleToggleLiveVoice}
            className={`min-h-[44px] rounded-xl border text-xs font-bold flex items-center justify-center gap-1.5 transition-all ${
              liveVoiceOn
                ? 'bg-cyan-500 text-slate-950 border-cyan-300 shadow-[0_0_20px_rgba(6,182,212,0.45)]'
                : 'bg-[#0b1120] text-cyan-300 border-cyan-500/40 hover:border-cyan-400'
            }`}
          >
            {liveVoiceOn ? <Mic className="w-4 h-4" /> : <MicOff className="w-4 h-4" />}
            <span className="whitespace-nowrap">
              {liveVoiceOn ? t(lang, 'liveOn') : t(lang, 'liveOff')}
            </span>
          </button>

          <button
            type="button"
            onClick={handleOkExport}
            disabled={!okEnabled}
            className={`min-h-[44px] rounded-xl border text-xs font-bold flex items-center justify-center gap-1.5 transition-colors ${
              okEnabled
                ? 'bg-emerald-500 hover:bg-emerald-400 text-slate-950 border-emerald-300'
                : 'bg-[#0b1120] text-slate-500 border-white/10 cursor-not-allowed'
            }`}
          >
            <CheckCircle2 className="w-4 h-4" />
            <span>{exportBusy ? '...' : t(lang, 'okExport')}</span>
          </button>

          <button
            type="button"
            onClick={handleHomeAction}
            className="min-h-[44px] rounded-xl bg-[#0b1120] hover:bg-white/10 border border-white/10 text-xs font-semibold text-slate-200 flex items-center justify-center gap-1.5 transition-colors"
          >
            <Home className="w-4 h-4 text-purple-400" />
            <span>{t(lang, 'home')}</span>
          </button>
        </div>
      </footer>
    </div>
  );
}
