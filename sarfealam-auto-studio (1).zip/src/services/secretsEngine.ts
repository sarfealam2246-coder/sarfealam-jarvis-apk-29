import {
  AIProviderId,
  APIKeyEntry,
  DepartmentAssignment,
  Language,
  SecretsState,
} from '../types';

const STORAGE_KEY = 'sarfealam_autostudio_secrets_v1';

export function detectProviderFromKey(rawKey: string): {
  provider: AIProviderId | null;
  label: string;
} {
  const key = rawKey.trim();
  if (!key) return { provider: null, label: 'Empty' };
  if (key.startsWith('AIza') || key.startsWith('AQ.')) {
    return { provider: 'gemini', label: 'Google Gemini' };
  }
  if (key.startsWith('gsk_')) {
    return { provider: 'groq', label: 'Groq Cloud' };
  }
  if (key.startsWith('nvapi-')) {
    return { provider: 'nvidia', label: 'NVIDIA NIM' };
  }
  if (key.startsWith('sk-or-v1-') || key.startsWith('sk-or-')) {
    return { provider: 'openrouter', label: 'OpenRouter' };
  }
  if (key.length >= 16) {
    return { provider: 'cohere', label: 'Cohere / Custom' };
  }
  return { provider: null, label: 'Unrecognized (too short)' };
}

export function createDefaultSecrets(): SecretsState {
  const defaultKeys: APIKeyEntry[] = Array.from({ length: 5 }, (_, idx) => ({
    id: `key_${idx + 1}`,
    value: '',
    provider: null,
    providerLabel: 'Empty',
    verified: false,
  }));

  return {
    apiKeys: defaultKeys,
    github: {
      username: '',
      token: '',
      connected: false,
    },
    studioSupabase: {
      url: '',
      anonKey: '',
      connected: false,
    },
    appsSupabase: {
      url: '',
      anonKey: '',
      connected: false,
    },
  };
}

export function loadSecretsFromLocal(): SecretsState {
  try {
    const raw = localStorage.getItem(STORAGE_KEY);
    if (!raw) return createDefaultSecrets();
    const parsed = JSON.parse(raw) as Partial<SecretsState>;
    const defaults = createDefaultSecrets();
    const loadedKeys = Array.isArray(parsed.apiKeys) && parsed.apiKeys.length >= 5
      ? parsed.apiKeys.map((k, idx) => {
          const detected = detectProviderFromKey(k.value || '');
          return {
            id: k.id || `key_${idx + 1}`,
            value: k.value || '',
            provider: detected.provider,
            providerLabel: detected.label,
            verified: Boolean(k.verified && k.value?.trim()),
            lastError: k.lastError,
          };
        })
      : defaults.apiKeys;

    return {
      apiKeys: loadedKeys,
      github: {
        ...defaults.github,
        ...(parsed.github || {}),
        connected: Boolean(parsed.github?.connected && parsed.github?.token && parsed.github?.username),
      },
      studioSupabase: {
        ...defaults.studioSupabase,
        ...(parsed.studioSupabase || {}),
        connected: Boolean(parsed.studioSupabase?.connected && parsed.studioSupabase?.url && parsed.studioSupabase?.anonKey),
      },
      appsSupabase: {
        ...defaults.appsSupabase,
        ...(parsed.appsSupabase || {}),
        connected: Boolean(parsed.appsSupabase?.connected && parsed.appsSupabase?.url && parsed.appsSupabase?.anonKey),
      },
    };
  } catch {
    return createDefaultSecrets();
  }
}

export function saveSecretsToLocal(secrets: SecretsState): void {
  try {
    localStorage.setItem(STORAGE_KEY, JSON.stringify(secrets));
  } catch {
    // Ignore storage quota errors cleanly
  }
}

export function getActiveKeysByProvider(secrets: SecretsState): Record<AIProviderId, APIKeyEntry[]> {
  const map: Record<AIProviderId, APIKeyEntry[]> = {
    gemini: [],
    groq: [],
    nvidia: [],
    openrouter: [],
    cohere: [],
  };
  for (const entry of secrets.apiKeys) {
    const trimmed = entry.value.trim();
    if (!trimmed) continue;
    const { provider } = detectProviderFromKey(trimmed);
    if (provider) {
      map[provider].push({ ...entry, value: trimmed, provider });
    }
  }
  return map;
}

export function hasAnyAIKey(secrets: SecretsState): boolean {
  return secrets.apiKeys.some((k) => Boolean(detectProviderFromKey(k.value).provider));
}

export function computeDepartmentRouting(secrets: SecretsState): DepartmentAssignment[] {
  const byProvider = getActiveKeysByProvider(secrets);
  const pick = (order: Array<{ provider: AIProviderId; model: string }>) => {
    for (const item of order) {
      const key = byProvider[item.provider][0];
      if (key) {
        return {
          provider: item.provider,
          model: item.model,
          keyId: key.id,
          available: true,
        };
      }
    }
    return {
      provider: null as AIProviderId | null,
      model: null as string | null,
      keyId: null as string | null,
      available: false,
    };
  };

  const brain = pick([
    { provider: 'gemini', model: 'gemini-2.5-flash' },
    { provider: 'nvidia', model: 'nvidia/llama-3.3-nemotron-super-49b-v1' },
    { provider: 'groq', model: 'openai/gpt-oss-120b' },
    { provider: 'openrouter', model: 'openrouter/free' },
    { provider: 'cohere', model: 'command-a-03-2025' },
  ]);

  const code = pick([
    { provider: 'nvidia', model: 'qwen/qwen2.5-coder-32b-instruct' },
    { provider: 'gemini', model: 'gemini-2.5-flash' },
    { provider: 'groq', model: 'openai/gpt-oss-120b' },
    { provider: 'openrouter', model: 'openrouter/free' },
    { provider: 'cohere', model: 'command-a-03-2025' },
  ]);

  const fast = pick([
    { provider: 'groq', model: 'openai/gpt-oss-120b' },
    { provider: 'gemini', model: 'gemini-2.5-flash' },
    { provider: 'nvidia', model: 'meta/llama-3.3-70b-instruct' },
    { provider: 'openrouter', model: 'openrouter/free' },
    { provider: 'cohere', model: 'command-a-03-2025' },
  ]);

  const vision = pick([
    { provider: 'gemini', model: 'gemini-2.5-flash (Vision + Image Gen)' },
    { provider: 'nvidia', model: 'nvidia/nemotron-nano-12b-vl' },
    { provider: 'openrouter', model: 'openrouter/free' },
  ]);

  const stt = pick([
    { provider: 'groq', model: 'whisper-large-v3-turbo' },
    { provider: 'nvidia', model: 'nvidia/parakeet-ctc-1.1b' },
  ]);

  const tts = pick([
    { provider: 'nvidia', model: 'nvidia/magpie-tts' },
  ]);

  const reason = pick([
    { provider: 'nvidia', model: 'deepseek-ai/deepseek-r1' },
    { provider: 'gemini', model: 'gemini-2.5-flash' },
    { provider: 'groq', model: 'openai/gpt-oss-120b' },
    { provider: 'openrouter', model: 'openrouter/free' },
    { provider: 'cohere', model: 'command-a-03-2025' },
  ]);

  return [
    {
      department: 'brain',
      label: 'Brain',
      ...brain,
      missingHint: 'Paste any Gemini, NVIDIA, Groq, OpenRouter, or Cohere key.',
    },
    {
      department: 'code',
      label: 'Code',
      ...code,
      missingHint: 'Paste NVIDIA (Qwen 32B Coder) or Gemini/Groq key.',
    },
    {
      department: 'fast',
      label: 'Fast',
      ...fast,
      missingHint: 'Paste Groq or Gemini key for ultra-low latency.',
    },
    {
      department: 'vision',
      label: 'Vision & Image',
      ...vision,
      missingHint: 'Paste Gemini or NVIDIA key for Vision QA & Image Gen.',
    },
    {
      department: 'stt',
      label: 'Listen STT',
      provider: stt.available ? stt.provider : 'native',
      model: stt.available ? stt.model : 'Browser/Android SpeechRecognition',
      keyId: stt.keyId,
      available: true,
      missingHint: 'Add Groq key (gsk_) for Whisper v3 Turbo WebView fallback.',
    },
    {
      department: 'tts',
      label: 'Speak TTS',
      provider: tts.available ? tts.provider : 'native',
      model: tts.available ? tts.model : 'Native SpeechSynthesis (EN/HI)',
      keyId: tts.keyId,
      available: true,
      missingHint: 'Native EN/HI speech active; NVIDIA key enables Magpie TTS.',
    },
    {
      department: 'reason',
      label: 'Reason',
      ...reason,
      missingHint: 'Paste NVIDIA (DeepSeek-R1) or Gemini key.',
    },
  ];
}

export function buildRoutingAnnouncement(
  routing: DepartmentAssignment[],
  lang: Language
): string {
  const code = routing.find((r) => r.department === 'code');
  const vision = routing.find((r) => r.department === 'vision');
  const stt = routing.find((r) => r.department === 'stt');
  const brain = routing.find((r) => r.department === 'brain');

  if (!brain?.available) {
    return lang === 'hi'
      ? 'सर, अभी कोई मान्य AI की सेव नहीं है। कृपया कम से कम एक Gemini, Groq या NVIDIA की डालें।'
      : 'Sir, no valid AI key is saved yet. Please paste at least one Gemini, Groq, NVIDIA, OpenRouter, or Cohere key.';
  }

  const partsEn: string[] = [];
  if (code?.model) partsEn.push(`${code.model} for coding`);
  if (vision?.model) partsEn.push(`${vision.model.split(' ')[0]} for vision and images`);
  if (stt?.provider === 'groq') partsEn.push('Groq Whisper for live voice');

  if (lang === 'hi') {
    return `सर, मैंने आपकी कीज़ डिटेक्ट कर ली हैं! कोडिंग के लिए ${code?.model || 'AI'}, विज़न के लिए ${vision?.model?.split(' ')[0] || 'डिफ़ॉल्ट'}, और लाइव वॉइस के लिए ${stt?.model || 'नेटिव स्पीच'} असाइन कर दिया है। अब बताइए क्या बनाना है?`;
  }

  return `Sir, I have auto-detected your keys and assigned ${partsEn.join(', ')}. System Map is live and ready!`;
}
