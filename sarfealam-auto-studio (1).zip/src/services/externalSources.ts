import { DynamicSkill } from '../types';

export interface ExternalAssetResult {
  title: string;
  source: 'polyhaven' | 'github' | 'wikipedia' | 'pub.dev' | 'npm';
  url: string;
  description: string;
  thumbnail?: string;
}

export async function fetchPolyHavenAssets(
  query: string,
  kind: 'textures' | 'hdris' | 'models' = 'textures'
): Promise<ExternalAssetResult[]> {
  try {
    const res = await fetch(`https://api.polyhaven.com/assets?t=${kind}`);
    if (!res.ok) return [];
    const data = (await res.json()) as Record<string, { name?: string; categories?: string[]; tags?: string[] }>;
    const q = query.toLowerCase().trim();
    const matches = Object.entries(data)
      .filter(([slug, meta]) => {
        if (!q) return true;
        const hay = `${slug} ${meta.name || ''} ${(meta.categories || []).join(' ')} ${(meta.tags || []).join(' ')}`.toLowerCase();
        return q.split(/\s+/).some((word) => word.length > 2 && hay.includes(word));
      })
      .slice(0, 6);

    return matches.map(([slug, meta]) => ({
      title: meta.name || slug,
      source: 'polyhaven',
      url: `https://polyhaven.com/a/${slug}`,
      description: `Poly Haven CC0 ${kind.slice(0, -1)} · ${(meta.categories || []).slice(0, 3).join(', ')}`,
      thumbnail: `https://cdn.polyhaven.com/asset_img/thumbs/${slug}.png?width=256`,
    }));
  } catch {
    return [];
  }
}

export async function fetchGitHub3DOrSkillRepos(
  query: string,
  kind: 'glb' | 'flutter' | 'godot' | 'general' = 'general'
): Promise<ExternalAssetResult[]> {
  const qualifier =
    kind === 'glb'
      ? `${query} glb threejs 3d model`
      : kind === 'flutter'
      ? `${query} flutter package dart`
      : kind === 'godot'
      ? `${query} godot 4 addon`
      : query;

  try {
    const res = await fetch(
      `https://api.github.com/search/repositories?q=${encodeURIComponent(qualifier)}&sort=stars&per_page=5`,
      { headers: { Accept: 'application/vnd.github+json' } }
    );
    if (!res.ok) return [];
    const data = (await res.json()) as {
      items?: Array<{ full_name: string; html_url: string; description: string; stargazers_count: number }>;
    };
    return (data.items || []).map((repo) => ({
      title: repo.full_name,
      source: 'github',
      url: repo.html_url,
      description: `${repo.description || 'Open-source repository'} · ${repo.stargazers_count.toLocaleString()} stars`,
    }));
  } catch {
    return [];
  }
}

export async function fetchWikipediaSummary(query: string): Promise<ExternalAssetResult[]> {
  try {
    const clean = encodeURIComponent(query.trim().replace(/\s+/g, '_'));
    const res = await fetch(`https://en.wikipedia.org/api/rest_v1/page/summary/${clean}`);
    if (!res.ok) return [];
    const data = (await res.json()) as {
      title?: string;
      extract?: string;
      content_urls?: { desktop?: { page?: string } };
    };
    if (!data.title || !data.extract) return [];
    return [
      {
        title: data.title,
        source: 'wikipedia',
        url: data.content_urls?.desktop?.page || `https://en.wikipedia.org/wiki/${clean}`,
        description: data.extract.slice(0, 260),
      },
    ];
  } catch {
    return [];
  }
}

export async function discoverDynamicSkill(query: string): Promise<DynamicSkill | null> {
  const q = query.trim();
  if (!q) return null;

  // 1) Try npm registry (CORS friendly, real live open packages)
  try {
    const npmRes = await fetch(
      `https://registry.npmjs.org/-/v1/search?text=${encodeURIComponent(q)}&size=3`
    );
    if (npmRes.ok) {
      const data = (await npmRes.json()) as {
        objects?: Array<{
          package: { name: string; description?: string; links?: { npm?: string } };
        }>;
      };
      const first = data.objects?.[0]?.package;
      if (first) {
        return {
          id: `skill_${Date.now()}`,
          name: first.name,
          query: q,
          source: 'npm',
          packageName: first.name,
          description: first.description || `Discovered npm capability for "${q}"`,
          url: first.links?.npm || `https://www.npmjs.com/package/${first.name}`,
          enabled: true,
          discoveredAt: new Date().toISOString(),
        };
      }
    }
  } catch {
    // Fall through to GitHub search
  }

  // 2) Fallback to GitHub repository discovery
  const repos = await fetchGitHub3DOrSkillRepos(q, 'general');
  if (repos.length > 0) {
    const top = repos[0];
    return {
      id: `skill_${Date.now()}`,
      name: top.title.split('/')[1] || top.title,
      query: q,
      source: 'github',
      packageName: top.title,
      description: top.description,
      url: top.url,
      enabled: true,
      discoveredAt: new Date().toISOString(),
    };
  }

  return null;
}

export async function fetchExternalSource(
  query: string,
  kind: string
): Promise<ExternalAssetResult[]> {
  const k = kind.toLowerCase();
  if (k.includes('poly') || k.includes('pbr') || k.includes('hdri') || k.includes('texture')) {
    return fetchPolyHavenAssets(query, k.includes('hdri') ? 'hdris' : 'textures');
  }
  if (k.includes('wiki')) {
    return fetchWikipediaSummary(query);
  }
  if (k.includes('glb') || k.includes('3d') || k.includes('model')) {
    const [poly, gh] = await Promise.all([
      fetchPolyHavenAssets(query, 'models'),
      fetchGitHub3DOrSkillRepos(query, 'glb'),
    ]);
    return [...poly.slice(0, 3), ...gh.slice(0, 3)];
  }
  const [gh, wiki] = await Promise.all([
    fetchGitHub3DOrSkillRepos(query, 'general'),
    fetchWikipediaSummary(query),
  ]);
  return [...wiki, ...gh];
}
