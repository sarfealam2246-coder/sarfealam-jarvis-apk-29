import { GeneratedFile } from '../types';

const GH_API = 'https://api.github.com';

function ghHeaders(token: string): HeadersInit {
  return {
    Authorization: `Bearer ${token.trim()}`,
    Accept: 'application/vnd.github+json',
    'Content-Type': 'application/json',
    'X-GitHub-Api-Version': '2022-11-28',
  };
}

function toBase64Utf8(str: string): string {
  const bytes = new TextEncoder().encode(str);
  let binary = '';
  for (let i = 0; i < bytes.length; i++) {
    binary += String.fromCharCode(bytes[i]);
  }
  return btoa(binary);
}

export async function validateGitHubCredentials(
  username: string,
  token: string
): Promise<{ ok: boolean; login?: string; avatarUrl?: string; message: string }> {
  const user = username.trim();
  const pat = token.trim();
  if (!user || !pat) {
    return { ok: false, message: 'Enter both GitHub Username and PAT Token (repo + workflow scopes).' };
  }

  try {
    const res = await fetch(`${GH_API}/user`, {
      method: 'GET',
      headers: ghHeaders(pat),
    });

    const contentType = res.headers.get('content-type') || '';
    if (!contentType.includes('application/json')) {
      return {
        ok: false,
        message: `Unexpected non-JSON response from GitHub (HTTP ${res.status}). Check internet connection.`,
      };
    }

    const data = (await res.json()) as { login?: string; avatar_url?: string; message?: string };
    if (!res.ok || !data.login) {
      return {
        ok: false,
        message: `GitHub rejected token (HTTP ${res.status}): ${data.message || 'Invalid token'}.`,
      };
    }

    if (data.login.toLowerCase() !== user.toLowerCase()) {
      return {
        ok: true,
        login: data.login,
        avatarUrl: data.avatar_url,
        message: `Connected as @${data.login} (token owner overrides "${user}").`,
      };
    }

    return {
      ok: true,
      login: data.login,
      avatarUrl: data.avatar_url,
      message: `Connected directly to GitHub as @${data.login}.`,
    };
  } catch (err) {
    return {
      ok: false,
      message: `GitHub network error: ${err instanceof Error ? err.message : String(err)}`,
    };
  }
}

export interface GitHubPushResult {
  ok: boolean;
  repoUrl?: string;
  publicApkUrl?: string;
  ownerAdminUrl?: string;
  actionsRunUrl?: string;
  message: string;
}

export async function pushProjectToGitHub(
  username: string,
  token: string,
  repoName: string,
  files: GeneratedFile[],
  onProgress?: (step: string) => void
): Promise<GitHubPushResult> {
  const owner = username.trim();
  const pat = token.trim();

  if (!owner || !pat) {
    return { ok: false, message: 'GitHub Username & PAT Token are required.' };
  }

  try {
    onProgress?.(`Checking repository ${owner}/${repoName}...`);
    const repoCheck = await fetch(`${GH_API}/repos/${owner}/${repoName}`, {
      headers: ghHeaders(pat),
    });

    if (repoCheck.status === 404) {
      onProgress?.(`Creating repository ${repoName}...`);
      const createRes = await fetch(`${GH_API}/user/repos`, {
        method: 'POST',
        headers: ghHeaders(pat),
        body: JSON.stringify({
          name: repoName,
          description: 'Generated autonomously by Sarfealam Auto-Studio',
          private: false,
          auto_init: true,
        }),
      });
      if (!createRes.ok) {
        const err = (await createRes.json().catch(() => ({}))) as { message?: string };
        return {
          ok: false,
          message: `Failed to create repo (HTTP ${createRes.status}): ${err.message || 'Check repo scope on PAT'}`,
        };
      }
      // Small delay for GitHub initial commit propagation
      await new Promise((r) => setTimeout(r, 1200));
    } else if (!repoCheck.ok) {
      return { ok: false, message: `GitHub repo lookup error (HTTP ${repoCheck.status}).` };
    }

    // Push files via Contents API sequentially (reliable for initial commits + workflow files)
    for (let i = 0; i < files.length; i++) {
      const f = files[i];
      onProgress?.(`Pushing (${i + 1}/${files.length}): ${f.path}`);
      let existingSha: string | undefined;
      const getRes = await fetch(`${GH_API}/repos/${owner}/${repoName}/contents/${f.path}`, {
        headers: ghHeaders(pat),
      });
      if (getRes.ok) {
        const existing = (await getRes.json()) as { sha?: string };
        existingSha = existing.sha;
      }

      const putRes = await fetch(`${GH_API}/repos/${owner}/${repoName}/contents/${f.path}`, {
        method: 'PUT',
        headers: ghHeaders(pat),
        body: JSON.stringify({
          message: `Sarfealam Auto-Studio: update ${f.path}`,
          content: toBase64Utf8(f.content),
          ...(existingSha ? { sha: existingSha } : {}),
        }),
      });

      if (!putRes.ok) {
        const err = (await putRes.json().catch(() => ({}))) as { message?: string };
        return {
          ok: false,
          message: `Failed pushing ${f.path} (HTTP ${putRes.status}): ${err.message || 'Ensure workflow scope is enabled on your GitHub PAT.'}`,
        };
      }
    }

    // Enable GitHub Pages on main /docs
    onProgress?.('Enabling GitHub Pages for Owner Admin Web Panel...');
    await fetch(`${GH_API}/repos/${owner}/${repoName}/pages`, {
      method: 'POST',
      headers: ghHeaders(pat),
      body: JSON.stringify({
        source: { branch: 'main', path: '/docs' },
      }),
    }).catch(() => {});

    const repoUrl = `https://github.com/${owner}/${repoName}`;
    const publicApkUrl = `https://github.com/${owner}/${repoName}/releases/latest`;
    const ownerAdminUrl = `https://${owner}.github.io/${repoName}/`;
    const actionsRunUrl = `https://github.com/${owner}/${repoName}/actions`;

    return {
      ok: true,
      repoUrl,
      publicApkUrl,
      ownerAdminUrl,
      actionsRunUrl,
      message: `Pushed ${files.length} files to ${owner}/${repoName}. GitHub Actions APK build & Admin Pages deployment triggered.`,
    };
  } catch (err) {
    return {
      ok: false,
      message: `GitHub push failed: ${err instanceof Error ? err.message : String(err)}`,
    };
  }
}

export async function pollGitHubBuildStatus(
  username: string,
  token: string,
  repoName: string
): Promise<{
  status: 'actions_running' | 'apk_ready' | 'failed';
  detail: string;
  apkDownloadUrl?: string;
  runUrl?: string;
}> {
  const owner = username.trim();
  const pat = token.trim();
  if (!owner || !pat) {
    return { status: 'failed', detail: 'Missing GitHub credentials.' };
  }

  try {
    // 1) Check latest release for a real APK asset
    const relRes = await fetch(`${GH_API}/repos/${owner}/${repoName}/releases/latest`, {
      headers: ghHeaders(pat),
    });
    if (relRes.ok) {
      const rel = (await relRes.json()) as {
        html_url?: string;
        assets?: Array<{ name: string; browser_download_url: string }>;
      };
      const apk = rel.assets?.find((a) => a.name.endsWith('.apk'));
      if (apk) {
        return {
          status: 'apk_ready',
          detail: `Verified Release APK: ${apk.name}`,
          apkDownloadUrl: apk.browser_download_url,
        };
      }
    }

    // 2) Check latest Actions workflow run
    const runsRes = await fetch(`${GH_API}/repos/${owner}/${repoName}/actions/runs?per_page=3`, {
      headers: ghHeaders(pat),
    });
    if (runsRes.ok) {
      const data = (await runsRes.json()) as {
        workflow_runs?: Array<{
          name: string;
          status: string;
          conclusion: string | null;
          html_url: string;
        }>;
      };
      const latest = data.workflow_runs?.[0];
      if (latest) {
        if (latest.conclusion === 'failure' || latest.conclusion === 'cancelled') {
          return {
            status: 'failed',
            detail: `Actions run "${latest.name}" ended with ${latest.conclusion}.`,
            runUrl: latest.html_url,
          };
        }
        return {
          status: 'actions_running',
          detail: `GitHub Actions "${latest.name}" is ${latest.status}${latest.conclusion ? ` (${latest.conclusion})` : ''}.`,
          runUrl: latest.html_url,
        };
      }
    }

    return {
      status: 'actions_running',
      detail: 'Workflow queued on GitHub Actions. Check again in 30–60s.',
    };
  } catch (err) {
    return {
      status: 'failed',
      detail: `Polling error: ${err instanceof Error ? err.message : String(err)}`,
    };
  }
}
