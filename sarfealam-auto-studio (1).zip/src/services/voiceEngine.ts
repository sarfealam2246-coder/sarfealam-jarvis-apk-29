import { Language, SecretsState } from '../types';
import { transcribeAudioWithGroqWhisper } from './aiRouter';

interface SpeechRecognitionAlternativeLike {
  transcript: string;
}

interface SpeechRecognitionResultLike {
  isFinal: boolean;
  0: SpeechRecognitionAlternativeLike;
}

interface SpeechRecognitionEventLike {
  resultIndex: number;
  results: {
    length: number;
    [index: number]: SpeechRecognitionResultLike;
  };
}

interface SpeechRecognitionLike {
  continuous: boolean;
  interimResults: boolean;
  lang: string;
  onstart: (() => void) | null;
  onspeechstart: (() => void) | null;
  onresult: ((e: SpeechRecognitionEventLike) => void) | null;
  onerror: ((e: { error?: string }) => void) | null;
  onend: (() => void) | null;
  start: () => void;
  stop: () => void;
  abort: () => void;
}

export interface DuplexVoiceCallbacks {
  onTranscriptInterim: (text: string) => void;
  onTranscriptFinal: (text: string) => void;
  onStateChange: (state: 'idle' | 'listening' | 'speaking' | 'fallback_whisper') => void;
  onError: (msg: string) => void;
}

export class JarvisDuplexVoiceEngine {
  private active = false;
  private lang: Language = 'en';
  private recognition: SpeechRecognitionLike | null = null;
  private isSpeaking = false;
  private speakingGuardUntil = 0;
  private ttsQueue: string[] = [];
  private vadTimer: number | null = null;
  private pendingTranscript = '';
  private callbacks: DuplexVoiceCallbacks;
  private getSecrets: () => SecretsState;

  // AudioContext + MediaRecorder for barge-in detection and Android WebView Groq Whisper fallback
  private mediaStream: MediaStream | null = null;
  private audioCtx: AudioContext | null = null;
  private analyser: AnalyserNode | null = null;
  private bargeInInterval: number | null = null;
  private mediaRecorder: MediaRecorder | null = null;
  private recordedChunks: Blob[] = [];
  private usingWhisperFallback = false;
  private silenceFrames = 0;
  private hasSpeechInBuffer = false;

  constructor(callbacks: DuplexVoiceCallbacks, getSecrets: () => SecretsState) {
    this.callbacks = callbacks;
    this.getSecrets = getSecrets;
  }

  public setLanguage(lang: Language) {
    this.lang = lang;
    if (this.recognition && this.active) {
      this.recognition.lang = lang === 'hi' ? 'hi-IN' : 'en-IN';
      try {
        this.recognition.stop();
      } catch {
        // Will auto-restart in onend with new lang
      }
    }
  }

  public isRunning(): boolean {
    return this.active;
  }

  public speakText(text: string, interruptCurrent = true) {
    if (typeof window === 'undefined' || !('speechSynthesis' in window)) return;
    const clean = text.replace(/[*#`]/g, '').trim();
    if (!clean) return;
    if (interruptCurrent) {
      this.cancelSpeech();
    }
    this.ttsQueue.push(clean);
    if (!this.isSpeaking) {
      this.pumpTtsQueue();
    }
  }

  public speakSentenceStreamed(sentence: string) {
    const clean = sentence.replace(/[*#`]/g, '').trim();
    if (!clean) return;
    this.ttsQueue.push(clean);
    if (!this.isSpeaking) {
      this.pumpTtsQueue();
    }
  }

  public cancelSpeech() {
    this.ttsQueue = [];
    this.isSpeaking = false;
    try {
      window.speechSynthesis?.cancel();
    } catch {
      // Ignore WebView TTS errors
    }
    if (this.active) {
      this.callbacks.onStateChange(this.usingWhisperFallback ? 'fallback_whisper' : 'listening');
    } else {
      this.callbacks.onStateChange('idle');
    }
  }

  private pumpTtsQueue() {
    if (!('speechSynthesis' in window) || this.ttsQueue.length === 0) {
      this.isSpeaking = false;
      this.speakingGuardUntil = Date.now() + 350;
      if (this.active) {
        this.callbacks.onStateChange(this.usingWhisperFallback ? 'fallback_whisper' : 'listening');
      } else {
        this.callbacks.onStateChange('idle');
      }
      return;
    }

    const next = this.ttsQueue.shift()!;
    const utter = new SpeechSynthesisUtterance(next);
    const targetLang = this.lang === 'hi' ? 'hi-IN' : 'en-IN';
    utter.lang = targetLang;
    utter.rate = this.lang === 'hi' ? 1.02 : 1.06;
    utter.pitch = 0.98;

    const voices = window.speechSynthesis.getVoices();
    const matched =
      voices.find((v) => v.lang.toLowerCase().startsWith(this.lang === 'hi' ? 'hi' : 'en-in')) ||
      voices.find((v) => v.lang.toLowerCase().startsWith(this.lang === 'hi' ? 'hi' : 'en'));
    if (matched) utter.voice = matched;

    this.isSpeaking = true;
    this.callbacks.onStateChange('speaking');

    utter.onend = () => {
      this.pumpTtsQueue();
    };
    utter.onerror = () => {
      this.pumpTtsQueue();
    };

    try {
      window.speechSynthesis.speak(utter);
    } catch {
      this.isSpeaking = false;
    }
  }

  public async startLive(lang: Language): Promise<void> {
    this.lang = lang;
    this.active = true;
    this.pendingTranscript = '';

    // Request mic access with echoCancellation + noiseSuppression to eliminate self-echo loops
    try {
      if (navigator.mediaDevices?.getUserMedia) {
        this.mediaStream = await navigator.mediaDevices.getUserMedia({
          audio: {
            echoCancellation: true,
            noiseSuppression: true,
            autoGainControl: true,
          },
        });
        this.setupBargeInMonitor(this.mediaStream);
      }
    } catch (err) {
      this.callbacks.onError(
        `Mic permission issue: ${err instanceof Error ? err.message : 'Check Android RECORD_AUDIO permission'}.`
      );
    }

    const SpeechRecCtor =
      (window as unknown as { SpeechRecognition?: new () => SpeechRecognitionLike }).SpeechRecognition ||
      (window as unknown as { webkitSpeechRecognition?: new () => SpeechRecognitionLike }).webkitSpeechRecognition;

    if (SpeechRecCtor) {
      this.usingWhisperFallback = false;
      this.startWebSpeechRecognition(SpeechRecCtor);
    } else {
      // Android WebView fallback: MediaRecorder + silence VAD -> Groq Whisper
      this.startWhisperFallback();
    }
  }

  private setupBargeInMonitor(stream: MediaStream) {
    try {
      const AudioCtx = window.AudioContext || (window as unknown as { webkitAudioContext: typeof AudioContext }).webkitAudioContext;
      this.audioCtx = new AudioCtx();
      const src = this.audioCtx.createMediaStreamSource(stream);
      this.analyser = this.audioCtx.createAnalyser();
      this.analyser.fftSize = 512;
      src.connect(this.analyser);

      const buf = new Uint8Array(this.analyser.frequencyBinCount);
      let consecutiveLoud = 0;

      this.bargeInInterval = window.setInterval(() => {
        if (!this.analyser || !this.active) return;
        this.analyser.getByteTimeDomainData(buf);
        let sumSq = 0;
        for (let i = 0; i < buf.length; i++) {
          const norm = (buf[i] - 128) / 128;
          sumSq += norm * norm;
        }
        const rms = Math.sqrt(sumSq / buf.length);

        // Barge-In Interrupt: if JARVIS is speaking and user voice crosses threshold
        if (this.isSpeaking) {
          if (rms > 0.12) {
            consecutiveLoud++;
            if (consecutiveLoud >= 3) {
              this.cancelSpeech();
              consecutiveLoud = 0;
            }
          } else {
            consecutiveLoud = 0;
          }
        }

        // Whisper fallback VAD silence detection (~800ms after speech)
        if (this.usingWhisperFallback && this.mediaRecorder?.state === 'recording') {
          if (rms > 0.045) {
            this.hasSpeechInBuffer = true;
            this.silenceFrames = 0;
          } else if (this.hasSpeechInBuffer) {
            this.silenceFrames++;
            if (this.silenceFrames >= 8) {
              this.flushWhisperRecording();
            }
          }
        }
      }, 100);
    } catch {
      // AudioContext unavailable; recognition onspeechstart still handles barge-in
    }
  }

  private startWebSpeechRecognition(Ctor: new () => SpeechRecognitionLike) {
    const rec = new Ctor();
    rec.continuous = true;
    rec.interimResults = true;
    rec.lang = this.lang === 'hi' ? 'hi-IN' : 'en-IN';

    rec.onstart = () => {
      if (!this.isSpeaking) this.callbacks.onStateChange('listening');
    };

    rec.onspeechstart = () => {
      if (this.isSpeaking) {
        this.cancelSpeech();
      }
    };

    rec.onresult = (e: SpeechRecognitionEventLike) => {
      if (this.isSpeaking || Date.now() < this.speakingGuardUntil) return;

      let interim = '';
      let finalChunk = '';
      for (let i = e.resultIndex; i < e.results.length; i++) {
        const res = e.results[i];
        const transcript = res[0]?.transcript || '';
        if (res.isFinal) {
          finalChunk += ` ${transcript}`;
        } else {
          interim += transcript;
        }
      }

      if (finalChunk.trim()) {
        this.pendingTranscript = `${this.pendingTranscript} ${finalChunk}`.trim();
      }
      const display = `${this.pendingTranscript} ${interim}`.trim();
      if (display) {
        this.callbacks.onTranscriptInterim(display);
      }

      // ~800ms Voice Activity Detection auto-send timer
      if (this.vadTimer) window.clearTimeout(this.vadTimer);
      this.vadTimer = window.setTimeout(() => {
        const toSend = (this.pendingTranscript || interim).trim();
        if (toSend.length > 1 && !this.isSpeaking) {
          this.pendingTranscript = '';
          this.callbacks.onTranscriptInterim('');
          this.callbacks.onTranscriptFinal(toSend);
        }
      }, 820);
    };

    rec.onerror = (e) => {
      if (e.error === 'not-allowed' || e.error === 'service-not-allowed') {
        this.callbacks.onError('SpeechRecognition blocked in WebView; switching to Groq Whisper fallback.');
        this.startWhisperFallback();
      }
    };

    rec.onend = () => {
      if (this.active && !this.usingWhisperFallback) {
        window.setTimeout(() => {
          if (this.active && !this.usingWhisperFallback) {
            try {
              rec.lang = this.lang === 'hi' ? 'hi-IN' : 'en-IN';
              rec.start();
            } catch {
              // Ignore already-started exception
            }
          }
        }, 250);
      }
    };

    this.recognition = rec;
    try {
      rec.start();
    } catch {
      this.startWhisperFallback();
    }
  }

  private startWhisperFallback() {
    this.usingWhisperFallback = true;
    this.callbacks.onStateChange('fallback_whisper');
    if (!this.mediaStream || typeof MediaRecorder === 'undefined') {
      this.callbacks.onError(
        'WebView mic capture unavailable. Grant Android RECORD_AUDIO permission or use text input.'
      );
      return;
    }
    this.startNextWhisperSegment();
  }

  private startNextWhisperSegment() {
    if (!this.active || !this.mediaStream) return;
    this.recordedChunks = [];
    this.hasSpeechInBuffer = false;
    this.silenceFrames = 0;

    try {
      const rec = new MediaRecorder(this.mediaStream);
      rec.ondataavailable = (ev) => {
        if (ev.data.size > 0) this.recordedChunks.push(ev.data);
      };
      rec.onstop = async () => {
        if (this.recordedChunks.length > 0 && this.hasSpeechInBuffer) {
          const blob = new Blob(this.recordedChunks, { type: 'audio/webm' });
          this.callbacks.onTranscriptInterim('Transcribing via Groq Whisper...');
          const result = await transcribeAudioWithGroqWhisper(this.getSecrets(), blob, this.lang);
          this.callbacks.onTranscriptInterim('');
          if (result.ok && result.text) {
            this.callbacks.onTranscriptFinal(result.text);
          } else if (result.error) {
            this.callbacks.onError(result.error);
          }
        }
        if (this.active && this.usingWhisperFallback) {
          this.startNextWhisperSegment();
        }
      };
      this.mediaRecorder = rec;
      rec.start(250);
    } catch (err) {
      this.callbacks.onError(`MediaRecorder error: ${err instanceof Error ? err.message : String(err)}`);
    }
  }

  private flushWhisperRecording() {
    if (this.mediaRecorder && this.mediaRecorder.state === 'recording') {
      try {
        this.mediaRecorder.stop();
      } catch {
        // Ignore stop race
      }
    }
  }

  public stopLive() {
    this.active = false;
    this.usingWhisperFallback = false;
    if (this.vadTimer) {
      window.clearTimeout(this.vadTimer);
      this.vadTimer = null;
    }
    if (this.bargeInInterval) {
      window.clearInterval(this.bargeInInterval);
      this.bargeInInterval = null;
    }
    try {
      this.recognition?.abort();
    } catch {
      // Ignore
    }
    this.recognition = null;

    if (this.mediaRecorder && this.mediaRecorder.state !== 'inactive') {
      try {
        this.mediaRecorder.stop();
      } catch {
        // Ignore
      }
    }
    this.mediaRecorder = null;

    if (this.mediaStream) {
      this.mediaStream.getTracks().forEach((track) => track.stop());
      this.mediaStream = null;
    }
    if (this.audioCtx) {
      this.audioCtx.close().catch(() => {});
      this.audioCtx = null;
    }
    this.cancelSpeech();
    this.callbacks.onStateChange('idle');
  }
}
