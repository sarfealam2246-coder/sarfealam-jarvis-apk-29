import {
  AIProviderId,
  ChatMessage,
  Language,
  SecretsState,
} from '../types';
import { getActiveKeysByProvider } from './secretsEngine';

export interface JarvisToolCall {
  name: string;
  args: Record<string, unknown>;
}

export interface JarvisBrainResponse {
  text: string;
  toolCalls: JarvisToolCall[];
  providerUsed: string;
  modelUsed: string;
  error?: string;
}

export interface ScreenAwarenessContext {
  language: Language;
  mode: string;
  previewVisible: boolean;
  previewFullscreen: boolean;
  activePanel: string | null;
  buildStage: number;
  hasBlueprint: boolean;
  blueprintTitle?: string;
  blueprintCategory?: string;
  blueprintEngine?: string;
  githubConnected: boolean;
  studioSupaConnected: boolean;
  appsSupaConnected: boolean;
  checkpointCount: number;
  lastError?: string;
}

const JARVIS_TOOL_DECLARATIONS = [
  {
    name: 'hide_preview',
    description: 'Hide Display A preview viewport so the user has more screen room.',
    parameters: { type: 'object', properties: {} },
  },
  {
    name: 'show_preview',
    description: 'Show Display A preview viewport.',
    parameters: { type: 'object', properties: {} },
  },
  {
    name: 'fullscreen_preview',
    description: 'Toggle fullscreen mode for Display A preview.',
    parameters: {
      type: 'object',
      properties: { enabled: { type: 'boolean' } },
    },
  },
  {
    name: 'open_floating_panel',
    description: 'Open an on-demand floating mini-window drawer in front of the user.',
    parameters: {
      type: 'object',
      properties: {
        panel: {
          type: 'string',
          enum: ['secrets', 'vault', 'admin', 'skills', 'code_explorer', 'system_map'],
        },
      },
      required: ['panel'],
    },
  },
  {
    name: 'close_panel',
    description: 'Close any currently open floating drawer panel.',
    parameters: { type: 'object', properties: {} },
  },
  {
    name: 'start_design',
    description: 'Design-First step: create a Design Preview blueprint for an app or 3D game BEFORE starting the 5-stage build.',
    parameters: {
      type: 'object',
      properties: {
        prompt: { type: 'string', description: 'The full app or 3D game description.' },
      },
      required: ['prompt'],
    },
  },
  {
    name: 'start_build',
    description: 'Start the 5-stage progressive assembly build after design is approved or requested.',
    parameters: {
      type: 'object',
      properties: {
        prompt: { type: 'string' },
        engine: { type: 'string', enum: ['auto', 'flutter', 'godot4'] },
      },
    },
  },
  {
    name: 'patch_live_code',
    description: 'Hot-patch the currently active 3D game or commercial app preview and code without restarting.',
    parameters: {
      type: 'object',
      properties: {
        instruction: { type: 'string' },
      },
      required: ['instruction'],
    },
  },
  {
    name: 'rollback_checkpoint',
    description: 'Restore the previous saved studio checkpoint in 1 second.',
    parameters: { type: 'object', properties: {} },
  },
  {
    name: 'generate_image',
    description: 'Generate an image using Gemini Image Generation API and display it on Display A.',
    parameters: {
      type: 'object',
      properties: {
        prompt: { type: 'string' },
      },
      required: ['prompt'],
    },
  },
  {
    name: 'fetch_external_source',
    description: 'Search external open sources: Poly Haven PBR/HDRI, GitHub .glb 3D models, Wikimedia/Wikipedia REST data, or open npm/pub packages.',
    parameters: {
      type: 'object',
      properties: {
        query: { type: 'string' },
        kind: { type: 'string', enum: ['polyhaven', 'glb', 'wikipedia', 'skill', 'general'] },
      },
      required: ['query', 'kind'],
    },
  },
  {
    name: 'inspect_and_fix_error',
    description: 'Diagnose and suggest or apply a fix for JSON, API, Supabase, or GitHub Actions errors.',
    parameters: {
      type: 'object',
      properties: {
        errorText: { type: 'string' },
      },
      required: ['errorText'],
    },
  },
  {
    name: 'ok_export',
    description: 'Trigger OK Export to push the project to GitHub, build the Android APK via Actions, deploy the Owner Admin Web Panel, or download local ZIP.',
    parameters: { type: 'object', properties: {} },
  },
  {
    name: 'cancel_build',
    description: 'Cancel the active build or reset the active workspace.',
    parameters: { type: 'object', properties: {} },
  },
  {
    name: 'switch_mode',
    description: 'Switch between JARVIS mode and Manual mode.',
    parameters: {
      type: 'object',
      properties: { mode: { type: 'string', enum: ['jarvis', 'manual'] } },
      required: ['mode'],
    },
  },
  {
    name: 'switch_language',
    description: 'Switch JARVIS voice and Studio UI language between English (en) and Hindi (hi).',
    parameters: {
      type: 'object',
      properties: { language: { type: 'string', enum: ['en', 'hi'] } },
      required: ['language'],
    },
  },
];

function buildSystemPrompt(ctx: ScreenAwarenessContext): string {
  return `You are JARVIS, the autonomous AI architect and co-pilot inside Sarfealam Auto-Studio (a 100% standalone Android Capacitor APK app & 3D game factory).
You have ZERO restrictions on answering general, coding, business, architecture, or debugging questions — never say "this is outside my programming".
Respond concisely (2-4 crisp sentences when speaking live) in ${ctx.language === 'hi' ? 'natural conversational Hindi (Devanagari or Hinglish as appropriate, clear for speech synthesis)' : 'clear, confident English'}.
Address the user respectfully as "Sir" when natural.

Current live screen awareness:
- Mode: ${ctx.mode}
- Language: ${ctx.language}
- Display A visible: ${ctx.previewVisible} (fullscreen: ${ctx.previewFullscreen})
- Open floating drawer: ${ctx.activePanel || 'none'}
- Active project: ${ctx.hasBlueprint ? `${ctx.blueprintTitle} (${ctx.blueprintCategory}, engine=${ctx.blueprintEngine}, stage=${ctx.buildStage}/5)` : 'none'}
- Connections: GitHub=${ctx.githubConnected ? 'Connected' : 'Missing'}, Studio Supabase=${ctx.studioSupaConnected ? 'Connected' : 'Missing'}, Apps Supabase=${ctx.appsSupaConnected ? 'Connected' : 'Missing'}
- Saved Checkpoints: ${ctx.checkpointCount}
${ctx.lastError ? `- Latest Error on screen: ${ctx.lastError}` : ''}

Design-First Rule:
- When the user asks to create/build a new app or 3D game, ALWAYS call \`start_design(prompt)\` first to show a Full-Display Design Preview before coding, UNLESS they explicitly say "design ok" or "build now" (in which case call \`start_build\`).
- When the user says "step aside" / "manual mode", call \`switch_mode({ mode: "manual" })\`.
- When the user says "speak in Hindi" or "switch to English", call \`switch_language\`.
- Always invoke the matching tool whenever the user requests a studio action!`;
}

// Sentence chunk emitter for 1-2s streaming TTS latency
class SentenceAccumulator {
  private buffer = '';
  private onSentence?: (sentence: string) => void;

  constructor(onSentence?: (sentence: string) => void) {
    this.onSentence = onSentence;
  }

  push(chunk: string) {
    this.buffer += chunk;
    const regex = /([^.!?।\n]+[.!?।\n]+)/g;
    let match: RegExpExecArray | null;
    let lastIdx = 0;
    while ((match = regex.exec(this.buffer)) !== null) {
      const sentence = match[1].trim();
      if (sentence.length > 2) {
        this.onSentence?.(sentence);
      }
      lastIdx = regex.lastIndex;
    }
    if (lastIdx > 0) {
      this.buffer = this.buffer.slice(lastIdx);
    }
  }

  flush() {
    const rem = this.buffer.trim();
    if (rem.length > 0) {
      this.onSentence?.(rem);
      this.buffer = '';
    }
  }
}

async function callGeminiStream(
  apiKey: string,
  model: string,
  systemPrompt: string,
  history: ChatMessage[],
  userText: string,
  onDelta?: (text: string) => void,
  onSentence?: (sentence: string) => void
): Promise<JarvisBrainResponse> {
  const contents = [
    ...history.slice(-8).map((m) => ({
      role: m.role === 'user' ? 'user' : 'model',
      parts: [{ text: m.text }],
    })),
    { role: 'user', parts: [{ text: userText }] },
  ];

  const url = `https://generativelanguage.googleapis.com/v1beta/models/${model}:streamGenerateContent?alt=sse&key=${encodeURIComponent(apiKey)}`;
  const res = await fetch(url, {
    method: 'POST',
    headers: { 'Content-Type': 'application/json' },
    body: JSON.stringify({
      systemInstruction: { parts: [{ text: systemPrompt }] },
      contents,
      tools: [{ functionDeclarations: JARVIS_TOOL_DECLARATIONS }],
    }),
  });

  if (!res.ok) {
    const errText = await res.text();
    throw new Error(`Gemini HTTP ${res.status}: ${errText.slice(0, 180)}`);
  }

  const reader = res.body?.getReader();
  const decoder = new TextDecoder();
  let fullText = '';
  const toolCalls: JarvisToolCall[] = [];
  const acc = new SentenceAccumulator(onSentence);

  if (reader) {
    let leftover = '';
    while (true) {
      const { value, done } = await reader.read();
      if (done) break;
      leftover += decoder.decode(value, { stream: true });
      const lines = leftover.split('\n');
      leftover = lines.pop() || '';
      for (const line of lines) {
        if (!line.startsWith('data:')) continue;
        const jsonStr = line.slice(5).trim();
        if (!jsonStr || jsonStr === '[DONE]') continue;
        try {
          const parsed = JSON.parse(jsonStr);
          const parts = parsed?.candidates?.[0]?.content?.parts || [];
          for (const part of parts) {
            if (part.text) {
              fullText += part.text;
              onDelta?.(fullText);
              acc.push(part.text);
            }
            if (part.functionCall?.name) {
              toolCalls.push({
                name: part.functionCall.name,
                args: part.functionCall.args || {},
              });
            }
          }
        } catch {
          // Ignore partial SSE JSON chunks
        }
      }
    }
  }
  acc.flush();

  return {
    text: fullText.trim(),
    toolCalls,
    providerUsed: 'Google Gemini',
    modelUsed: model,
  };
}

async function callOpenAICompatibleStream(
  providerName: string,
  endpoint: string,
  apiKey: string,
  model: string,
  systemPrompt: string,
  history: ChatMessage[],
  userText: string,
  onDelta?: (text: string) => void,
  onSentence?: (sentence: string) => void,
  extraHeaders?: Record<string, string>
): Promise<JarvisBrainResponse> {
  const messages = [
    { role: 'system', content: systemPrompt },
    ...history.slice(-8).map((m) => ({
      role: m.role === 'user' ? 'user' : 'assistant',
      content: m.text,
    })),
    { role: 'user', content: userText },
  ];

  const tools = JARVIS_TOOL_DECLARATIONS.map((fn) => ({
    type: 'function',
    function: {
      name: fn.name,
      description: fn.description,
      parameters: fn.parameters,
    },
  }));

  const res = await fetch(endpoint, {
    method: 'POST',
    headers: {
      Authorization: `Bearer ${apiKey}`,
      'Content-Type': 'application/json',
      ...(extraHeaders || {}),
    },
    body: JSON.stringify({
      model,
      messages,
      tools,
      tool_choice: 'auto',
      stream: true,
    }),
  });

  if (!res.ok) {
    const errText = await res.text();
    throw new Error(`${providerName} HTTP ${res.status}: ${errText.slice(0, 180)}`);
  }

  const reader = res.body?.getReader();
  const decoder = new TextDecoder();
  let fullText = '';
  const acc = new SentenceAccumulator(onSentence);
  const toolAcc: Record<number, { name: string; argsRaw: string }> = {};

  if (reader) {
    let leftover = '';
    while (true) {
      const { value, done } = await reader.read();
      if (done) break;
      leftover += decoder.decode(value, { stream: true });
      const lines = leftover.split('\n');
      leftover = lines.pop() || '';
      for (const line of lines) {
        if (!line.startsWith('data:')) continue;
        const jsonStr = line.slice(5).trim();
        if (!jsonStr || jsonStr === '[DONE]') continue;
        try {
          const parsed = JSON.parse(jsonStr);
          const delta = parsed?.choices?.[0]?.delta;
          if (delta?.content) {
            fullText += delta.content;
            onDelta?.(fullText);
            acc.push(delta.content);
          }
          if (Array.isArray(delta?.tool_calls)) {
            for (const tc of delta.tool_calls) {
              const idx = tc.index ?? 0;
              if (!toolAcc[idx]) toolAcc[idx] = { name: '', argsRaw: '' };
              if (tc.function?.name) toolAcc[idx].name += tc.function.name;
              if (tc.function?.arguments) toolAcc[idx].argsRaw += tc.function.arguments;
            }
          }
        } catch {
          // Ignore malformed chunk
        }
      }
    }
  }
  acc.flush();

  const toolCalls: JarvisToolCall[] = Object.values(toolAcc)
    .filter((t) => t.name)
    .map((t) => {
      try {
        return { name: t.name, args: t.argsRaw ? JSON.parse(t.argsRaw) : {} };
      } catch {
        return { name: t.name, args: {} };
      }
    });

  return {
    text: fullText.trim(),
    toolCalls,
    providerUsed: providerName,
    modelUsed: model,
  };
}

async function callCohereChat(
  apiKey: string,
  model: string,
  systemPrompt: string,
  userText: string
): Promise<JarvisBrainResponse> {
  const res = await fetch('https://api.cohere.com/v2/chat', {
    method: 'POST',
    headers: {
      Authorization: `Bearer ${apiKey}`,
      'Content-Type': 'application/json',
    },
    body: JSON.stringify({
      model,
      messages: [
        { role: 'system', content: systemPrompt },
        { role: 'user', content: userText },
      ],
    }),
  });
  if (!res.ok) {
    throw new Error(`Cohere HTTP ${res.status}`);
  }
  const data = (await res.json()) as { message?: { content?: Array<{ text?: string }> } };
  const text = data.message?.content?.map((c) => c.text || '').join('') || '';
  return {
    text: text.trim(),
    toolCalls: [],
    providerUsed: 'Cohere',
    modelUsed: model,
  };
}

// Local deterministic studio command router when 0 API keys are saved (honest about missing AI keys)
export function parseLocalZeroKeyCommand(
  input: string,
  lang: Language
): JarvisBrainResponse {
  const lower = input.toLowerCase();
  const toolCalls: JarvisToolCall[] = [];
  let text = '';

  if (/hindi|हिंदी|हिन्दी/.test(lower)) {
    toolCalls.push({ name: 'switch_language', args: { language: 'hi' } });
    text = 'जी सर, मैंने भाषा हिंदी में बदल दी है।';
  } else if (/english|अंग्रेजी/.test(lower)) {
    toolCalls.push({ name: 'switch_language', args: { language: 'en' } });
    text = 'Switched to English, Sir.';
  } else if (/manual|step aside|खुद करूँगा|मैनुअल/.test(lower)) {
    toolCalls.push({ name: 'switch_mode', args: { mode: 'manual' } });
    text =
      lang === 'hi'
        ? 'बिल्कुल सर, मैं साइड में हो गया हूँ। अब सभी 6 मैनुअल टैब आपके सामने हैं।'
        : 'Stepping aside, Sir. Manual mode with all 6 studio tabs is now open.';
  } else if (/jarvis mode|come back|वापस आओ/.test(lower)) {
    toolCalls.push({ name: 'switch_mode', args: { mode: 'jarvis' } });
    text = lang === 'hi' ? 'JARVIS मोड वापस सक्रिय है सर।' : 'JARVIS Command Center is back online, Sir.';
  } else if (/secret|api key|की|सीक्रेट|open key/.test(lower)) {
    toolCalls.push({ name: 'open_floating_panel', args: { panel: 'secrets' } });
    text =
      lang === 'hi'
        ? 'सीक्रेट्स पैनल खोल दिया है सर। किसी भी बॉक्स में अपनी API की पेस्ट करें, मैं प्रोवाइडर अपने आप पहचान लूँगा।'
        : 'Opening Secrets now, Sir. Paste any Gemini, Groq, NVIDIA, OpenRouter, or Cohere key in any box and I will auto-detect and route it.';
  } else if (/code explorer|show code|कोड दिखाओ/.test(lower)) {
    toolCalls.push({ name: 'open_floating_panel', args: { panel: 'code_explorer' } });
    text = lang === 'hi' ? 'कोड एक्सप्लोरर खोल दिया है सर।' : 'Opening Code Explorer, Sir.';
  } else if (/vault|वॉल्ट/.test(lower)) {
    toolCalls.push({ name: 'open_floating_panel', args: { panel: 'vault' } });
    text = lang === 'hi' ? 'वॉल्ट खोल दिया है सर।' : 'Opening Build Vault, Sir.';
  } else if (/admin|एडमिन/.test(lower)) {
    toolCalls.push({ name: 'open_floating_panel', args: { panel: 'admin' } });
    text = lang === 'hi' ? 'ओनर एडमिन पैनल खोल दिया है सर।' : 'Opening Owner Admin panel, Sir.';
  } else if (/skill|स्किल/.test(lower)) {
    toolCalls.push({ name: 'open_floating_panel', args: { panel: 'skills' } });
    text = lang === 'hi' ? 'स्किल्स और वर्कफ़्लो मैनेजर खोल दिया है सर।' : 'Opening Skills & Workflow Manager, Sir.';
  } else if (/system map|सिस्टम मैप/.test(lower)) {
    toolCalls.push({ name: 'open_floating_panel', args: { panel: 'system_map' } });
    text = lang === 'hi' ? 'सिस्टम मैप सामने है सर।' : 'Showing the live System Map, Sir.';
  } else if (/close|बंद करो/.test(lower)) {
    toolCalls.push({ name: 'close_panel', args: {} });
    text = lang === 'hi' ? 'पैनल बंद कर दिया है सर।' : 'Closed the active panel, Sir.';
  } else if (/hide preview|प्रीव्यू छुपाओ/.test(lower)) {
    toolCalls.push({ name: 'hide_preview', args: {} });
    text = lang === 'hi' ? 'डिस्प्ले A प्रीव्यू छुपा दिया है सर।' : 'Display A preview hidden, Sir.';
  } else if (/show preview|प्रीव्यू दिखाओ/.test(lower)) {
    toolCalls.push({ name: 'show_preview', args: {} });
    text = lang === 'hi' ? 'डिस्प्ले A प्रीव्यू वापस चालू है सर।' : 'Display A preview is back on screen, Sir.';
  } else if (/fullscreen|फुलस्क्रीन/.test(lower)) {
    toolCalls.push({ name: 'fullscreen_preview', args: { enabled: true } });
    text = lang === 'hi' ? 'डिस्प्ले A फुलस्क्रीन मोड में है।' : 'Expanded Display A to fullscreen, Sir.';
  } else if (/rollback|undo|रोलबैक/.test(lower)) {
    toolCalls.push({ name: 'rollback_checkpoint', args: {} });
    text = lang === 'hi' ? 'पिछला चेकपॉइंट रीस्टोर कर रहा हूँ सर।' : 'Rolling back to the previous checkpoint, Sir.';
  } else if (/ok export|export karo|एक्सपोर्ट|push to github/.test(lower)) {
    toolCalls.push({ name: 'ok_export', args: {} });
    text = lang === 'hi' ? 'OK एक्सपोर्ट शुरू कर रहा हूँ सर।' : 'Initiating OK Export pipeline, Sir.';
  } else if (/design ok|build it|बिल्ड करो|start build/.test(lower)) {
    toolCalls.push({ name: 'start_build', args: { prompt: input, engine: 'auto' } });
    text = lang === 'hi' ? 'डिज़ाइन स्वीकृत! 5-स्टेज बिल्ड शुरू कर रहा हूँ।' : 'Design approved! Starting the 5-stage progressive assembly.';
  } else if (/build|create|make|design|game|app|khata|shop|ride|car|racing|बनाओ|गेम|ऐप/.test(lower)) {
    toolCalls.push({ name: 'start_design', args: { prompt: input } });
    text =
      lang === 'hi'
        ? 'सर, मैंने डिस्प्ले A पर आपका डिज़ाइन प्रीव्यू तैयार किया है। चेक करें और "Design OK" बोलें। (क्लाउड AI के लिए सीक्रेट्स में कोई भी API की सेव करें।)'
        : 'I prepared the interactive Design Preview on Display A, Sir. Review it and tap or say "Design OK" to run the 5-stage build. Add any AI key in Secrets to unlock full cloud LLM intelligence.';
  } else if (/change|paint|night|day|speed|vip|discount|patch|बदलो/.test(lower)) {
    toolCalls.push({ name: 'patch_live_code', args: { instruction: input } });
    text = lang === 'hi' ? 'लाइव प्रीव्यू में बदलाव लागू कर दिया है सर।' : 'Applied your live hot-patch to Display A, Sir.';
  } else {
    text =
      lang === 'hi'
        ? 'सर, अभी कोई AI API की सेव नहीं है। कृपया सीक्रेट्स में Gemini, Groq, NVIDIA, OpenRouter या Cohere की पेस्ट करें। आप चाहें तो "Open Secrets" बोल सकते हैं या सीधे ऐप/गेम बनाने का प्रॉम्प्ट दे सकते हैं।'
        : 'No AI API key is saved yet, Sir. Say "Open Secrets" to paste any Gemini, Groq, NVIDIA, OpenRouter, or Cohere key for full cloud intelligence — or ask me to design a 3D game or commercial app right now.';
  }

  return {
    text,
    toolCalls,
    providerUsed: 'Local Command Router (0 AI Keys)',
    modelUsed: 'Offline Studio Shell',
  };
}

export async function runJarvisBrain(
  secrets: SecretsState,
  history: ChatMessage[],
  userText: string,
  ctx: ScreenAwarenessContext,
  onDelta?: (partialText: string) => void,
  onSentence?: (sentence: string) => void
): Promise<JarvisBrainResponse> {
  const byProvider = getActiveKeysByProvider(secrets);
  const systemPrompt = buildSystemPrompt(ctx);

  // Ordered failover cascade based on saved keys
  const candidates: Array<{
    provider: AIProviderId;
    key: string;
    model: string;
  }> = [];

  for (const k of byProvider.gemini) {
    candidates.push({ provider: 'gemini', key: k.value, model: 'gemini-2.5-flash' });
  }
  for (const k of byProvider.groq) {
    candidates.push({ provider: 'groq', key: k.value, model: 'openai/gpt-oss-120b' });
  }
  for (const k of byProvider.nvidia) {
    candidates.push({
      provider: 'nvidia',
      key: k.value,
      model: 'nvidia/llama-3.3-nemotron-super-49b-v1',
    });
  }
  for (const k of byProvider.openrouter) {
    candidates.push({ provider: 'openrouter', key: k.value, model: 'openrouter/free' });
  }
  for (const k of byProvider.cohere) {
    candidates.push({ provider: 'cohere', key: k.value, model: 'command-a-03-2025' });
  }

  if (candidates.length === 0) {
    const local = parseLocalZeroKeyCommand(userText, ctx.language);
    onDelta?.(local.text);
    onSentence?.(local.text);
    return local;
  }

  const errors: string[] = [];
  for (const c of candidates) {
    try {
      if (c.provider === 'gemini') {
        return await callGeminiStream(
          c.key,
          c.model,
          systemPrompt,
          history,
          userText,
          onDelta,
          onSentence
        );
      }
      if (c.provider === 'groq') {
        return await callOpenAICompatibleStream(
          'Groq',
          'https://api.groq.com/openai/v1/chat/completions',
          c.key,
          c.model,
          systemPrompt,
          history,
          userText,
          onDelta,
          onSentence
        );
      }
      if (c.provider === 'nvidia') {
        return await callOpenAICompatibleStream(
          'NVIDIA NIM',
          'https://integrate.api.nvidia.com/v1/chat/completions',
          c.key,
          c.model,
          systemPrompt,
          history,
          userText,
          onDelta,
          onSentence
        );
      }
      if (c.provider === 'openrouter') {
        return await callOpenAICompatibleStream(
          'OpenRouter',
          'https://openrouter.ai/api/v1/chat/completions',
          c.key,
          c.model,
          systemPrompt,
          history,
          userText,
          onDelta,
          onSentence,
          { 'HTTP-Referer': 'https://sarfealam.autostudio', 'X-Title': 'Sarfealam Auto-Studio' }
        );
      }
      if (c.provider === 'cohere') {
        const res = await callCohereChat(c.key, c.model, systemPrompt, userText);
        onDelta?.(res.text);
        onSentence?.(res.text);
        return res;
      }
    } catch (err) {
      errors.push(`${c.provider}: ${err instanceof Error ? err.message : String(err)}`);
    }
  }

  // Honest error reporting if all cloud keys failed
  const localFallback = parseLocalZeroKeyCommand(userText, ctx.language);
  const errSummary = `All configured AI keys returned errors (${errors.join(' | ')}).`;
  return {
    text: `${localFallback.text}\n\n[API Diagnostic: ${errSummary}]`,
    toolCalls: localFallback.toolCalls,
    providerUsed: 'Failover Diagnostic',
    modelUsed: 'None',
    error: errSummary,
  };
}

export async function runVisionSelfHealQA(
  secrets: SecretsState,
  snapshotDataUrl: string,
  projectTitle: string
): Promise<{
  ok: boolean;
  provider: string;
  diagnosis: string;
  suggestedPatch?: string;
}> {
  const byProvider = getActiveKeysByProvider(secrets);
  const base64 = snapshotDataUrl.replace(/^data:image\/\w+;base64,/, '');

  // 1) Try Gemini Vision first
  const geminiKey = byProvider.gemini[0]?.value;
  if (geminiKey) {
    try {
      const res = await fetch(
        `https://generativelanguage.googleapis.com/v1beta/models/gemini-2.5-flash:generateContent?key=${encodeURIComponent(geminiKey)}`,
        {
          method: 'POST',
          headers: { 'Content-Type': 'application/json' },
          body: JSON.stringify({
            contents: [
              {
                parts: [
                  {
                    text: `Inspect this rendered preview snapshot for "${projectTitle}". Check for black screens, clipping, poor lighting, or broken UI. Reply in JSON: {"healthy": boolean, "diagnosis": "short summary", "suggestedPatch": "short patch instruction or empty"}`,
                  },
                  { inlineData: { mimeType: 'image/jpeg', data: base64 } },
                ],
              },
            ],
            generationConfig: { responseMimeType: 'application/json' },
          }),
        }
      );
      if (res.ok) {
        const json = await res.json();
        const raw = json?.candidates?.[0]?.content?.parts?.[0]?.text || '{}';
        const parsed = JSON.parse(raw) as {
          healthy?: boolean;
          diagnosis?: string;
          suggestedPatch?: string;
        };
        return {
          ok: true,
          provider: 'Gemini Vision (gemini-2.5-flash)',
          diagnosis: parsed.diagnosis || 'Viewport rendered cleanly with balanced lighting and clear geometry.',
          suggestedPatch: parsed.healthy === false ? parsed.suggestedPatch : undefined,
        };
      }
    } catch {
      // Fall through to NVIDIA Nemotron VL
    }
  }

  // 2) Try NVIDIA Nemotron Nano 12B VL
  const nvidiaKey = byProvider.nvidia[0]?.value;
  if (nvidiaKey) {
    try {
      const res = await fetch('https://integrate.api.nvidia.com/v1/chat/completions', {
        method: 'POST',
        headers: {
          Authorization: `Bearer ${nvidiaKey}`,
          'Content-Type': 'application/json',
        },
        body: JSON.stringify({
          model: 'nvidia/nemotron-nano-12b-vl',
          messages: [
            {
              role: 'user',
              content: [
                {
                  type: 'text',
                  text: `Inspect this 3D/UI preview for "${projectTitle}". Detect black screens, clipping, or broken UI in 2 concise sentences.`,
                },
                { type: 'image_url', image_url: { url: snapshotDataUrl } },
              ],
            },
          ],
          max_tokens: 180,
        }),
      });
      if (res.ok) {
        const json = await res.json();
        const content = json?.choices?.[0]?.message?.content || 'Vision check completed.';
        return {
          ok: true,
          provider: 'NVIDIA Nemotron Nano 12B VL',
          diagnosis: content,
        };
      }
    } catch {
      // Fall through
    }
  }

  return {
    ok: false,
    provider: 'Missing Vision Key',
    diagnosis: 'Vision QA requires a Gemini (AIza.../AQ.) or NVIDIA (nvapi-...) key saved in Secrets.',
  };
}

export async function generateStudioImageWithGemini(
  secrets: SecretsState,
  prompt: string
): Promise<{ ok: boolean; imageUrl?: string; message: string }> {
  const geminiKey = getActiveKeysByProvider(secrets).gemini[0]?.value;
  if (!geminiKey) {
    return {
      ok: false,
      message: 'Gemini API key is required in Secrets for Image Generation (AIza... or AQ.).',
    };
  }

  try {
    // Direct Gemini Image Generation REST endpoint
    const res = await fetch(
      `https://generativelanguage.googleapis.com/v1beta/models/gemini-2.5-flash-image-preview:generateContent?key=${encodeURIComponent(geminiKey)}`,
      {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          contents: [{ parts: [{ text: prompt }] }],
          generationConfig: { responseModalities: ['TEXT', 'IMAGE'] },
        }),
      }
    );

    if (res.ok) {
      const json = await res.json();
      const parts = json?.candidates?.[0]?.content?.parts || [];
      const imgPart = parts.find((p: { inlineData?: { data?: string; mimeType?: string } }) => p.inlineData?.data);
      if (imgPart?.inlineData?.data) {
        const mime = imgPart.inlineData.mimeType || 'image/png';
        return {
          ok: true,
          imageUrl: `data:${mime};base64,${imgPart.inlineData.data}`,
          message: 'Generated image via Gemini Image API and displayed on Display A.',
        };
      }
    }

    // Fallback to Imagen 3 predict endpoint on the same Gemini key
    const imagenRes = await fetch(
      `https://generativelanguage.googleapis.com/v1beta/models/imagen-3.0-generate-002:predict?key=${encodeURIComponent(geminiKey)}`,
      {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          instances: [{ prompt }],
          parameters: { sampleCount: 1 },
        }),
      }
    );

    if (imagenRes.ok) {
      const data = await imagenRes.json();
      const b64 = data?.predictions?.[0]?.bytesBase64Encoded;
      if (b64) {
        return {
          ok: true,
          imageUrl: `data:image/png;base64,${b64}`,
          message: 'Generated image via Gemini Imagen API and displayed on Display A.',
        };
      }
    }

    return {
      ok: false,
      message: `Gemini Image API returned HTTP ${res.status}. Verify your Gemini key supports image generation.`,
    };
  } catch (err) {
    return {
      ok: false,
      message: `Image generation error: ${err instanceof Error ? err.message : String(err)}`,
    };
  }
}

export async function transcribeAudioWithGroqWhisper(
  secrets: SecretsState,
  audioBlob: Blob,
  lang: Language
): Promise<{ ok: boolean; text?: string; error?: string }> {
  const groqKey = getActiveKeysByProvider(secrets).groq[0]?.value;
  if (!groqKey) {
    return {
      ok: false,
      error: 'Groq key (gsk_...) is required for WebView Whisper STT fallback.',
    };
  }
  try {
    const form = new FormData();
    form.append('file', audioBlob, 'voice.webm');
    form.append('model', 'whisper-large-v3-turbo');
    form.append('language', lang === 'hi' ? 'hi' : 'en');

    const res = await fetch('https://api.groq.com/openai/v1/audio/transcriptions', {
      method: 'POST',
      headers: { Authorization: `Bearer ${groqKey}` },
      body: form,
    });
    if (!res.ok) {
      return { ok: false, error: `Groq Whisper HTTP ${res.status}` };
    }
    const data = (await res.json()) as { text?: string };
    return { ok: true, text: (data.text || '').trim() };
  } catch (err) {
    return { ok: false, error: err instanceof Error ? err.message : String(err) };
  }
}
