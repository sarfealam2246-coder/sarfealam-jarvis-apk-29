import JSZip from 'jszip';
import {
  CommercialAppConfig,
  DesignBlueprint,
  DynamicSkill,
  Game3DConfig,
  GeneratedFile,
  ProjectCategory,
  SupabaseServerConfig,
  TargetEngine,
  WorkflowTemplates,
} from '../types';

export const DEFAULT_WORKFLOW_TEMPLATES: WorkflowTemplates = {
  flutterApkYaml: `name: Build Flutter Android APK
on:
  push:
    branches: [ main ]
  workflow_dispatch:
permissions:
  contents: write
jobs:
  build_apk:
    runs-on: ubuntu-latest
    steps:
      - uses: actions/checkout@v4
      - uses: actions/setup-java@v4
        with:
          distribution: 'temurin'
          java-version: '17'
      - uses: subosito/flutter-action@v2
        with:
          flutter-version: '3.24.0'
          channel: 'stable'
      - name: Initialize Android Runner if missing
        run: |
          if [ ! -d "android" ]; then
            flutter create --platforms=android .
          fi
      - run: flutter pub get
      - run: flutter build apk --release
      - name: Publish Release APK
        uses: softprops/action-gh-release@v2
        with:
          tag_name: v1.0.\${{ github.run_number }}
          name: Release v1.0.\${{ github.run_number }}
          files: build/app/outputs/flutter-apk/app-release.apk
`,
  godotApkYaml: `name: Build Godot 4 Mobile Vulkan APK
on:
  push:
    branches: [ main ]
  workflow_dispatch:
permissions:
  contents: write
jobs:
  export_godot_apk:
    runs-on: ubuntu-latest
    container:
      image: barichello/godot-ci:4.3
    steps:
      - uses: actions/checkout@v4
      - name: Export Android Debug/Release APK
        run: |
          mkdir -p build/android
          godot --headless --verbose --export-debug "Android" build/android/app-release.apk || echo "Configure Android export_presets.cfg keystore for release signing"
      - name: Publish Godot APK to Releases
        if: hashFiles('build/android/app-release.apk') != ''
        uses: softprops/action-gh-release@v2
        with:
          tag_name: v1.0.\${{ github.run_number }}
          name: Godot 4 Release v1.0.\${{ github.run_number }}
          files: build/android/app-release.apk
`,
  deployAdminYaml: `name: Deploy Owner Admin Web Panel
on:
  push:
    branches: [ main ]
  workflow_dispatch:
permissions:
  contents: read
  pages: write
  id-token: write
jobs:
  deploy:
    environment:
      name: github-pages
      url: \${{ steps.deployment.outputs.page_url }}
    runs-on: ubuntu-latest
    steps:
      - uses: actions/checkout@v4
      - uses: actions/configure-pages@v5
      - uses: actions/upload-pages-artifact@v3
        with:
          path: 'docs'
      - id: deployment
        uses: actions/deploy-pages@v4
`,
};

export function classifyPrompt(prompt: string, forcedEngine?: 'auto' | TargetEngine): {
  category: ProjectCategory;
  engine: TargetEngine;
} {
  const p = prompt.toLowerCase();
  const isKhata = /khata|udhar|jama|pos|billing|invoice|accounting|ledger|dukkan|dukan|gst/.test(p);
  const isRide = /ride|taxi|cab|delivery|booking|courier|parcel|service|uber|rapido|driver|route/.test(p);
  const isFinance = /bank|wallet|finance|upi|trading|crypto|fantasy|predict|odds|loan|expense|stock/.test(p);
  const isCardBoard = /teen patti|rummy|poker|chess|ludo|card|board|blackjack|solitaire/.test(p);
  const isEcommerce = /shop|store|commerce|grocery|market|mart|cart|order|product|fashion|food|restaurant|menu/.test(p);
  const is3D = /3d|car|race|racing|gta|drive|driving|army|basecamp|shooter|open world|city|mountain|runner|game|jeep|truck|bike|simulator|highway/.test(p);

  if (isKhata) return { category: 'khata_pos', engine: forcedEngine && forcedEngine !== 'auto' ? forcedEngine : 'flutter' };
  if (isRide) return { category: 'ride_booking', engine: forcedEngine && forcedEngine !== 'auto' ? forcedEngine : 'flutter' };
  if (isFinance) return { category: 'finance_wallet', engine: forcedEngine && forcedEngine !== 'auto' ? forcedEngine : 'flutter' };
  if (isCardBoard) return { category: 'card_board', engine: forcedEngine && forcedEngine !== 'auto' ? forcedEngine : 'flutter' };
  if (isEcommerce) return { category: 'ecommerce', engine: forcedEngine && forcedEngine !== 'auto' ? forcedEngine : 'flutter' };
  if (is3D || forcedEngine === 'godot4') return { category: 'game_3d', engine: forcedEngine && forcedEngine !== 'auto' ? forcedEngine : 'godot4' };

  return {
    category: 'game_3d',
    engine: forcedEngine && forcedEngine !== 'auto' ? forcedEngine : 'godot4',
  };
}

export function slugifyProjectName(title: string): string {
  const clean = title
    .toLowerCase()
    .replace(/[^a-z0-9]+/g, '-')
    .replace(/^-+|-+$/g, '')
    .slice(0, 32);
  return clean || `auto-studio-app-${Date.now().toString().slice(-4)}`;
}

export function createDesignBlueprintFromPrompt(
  prompt: string,
  forcedEngine: 'auto' | TargetEngine = 'auto'
): DesignBlueprint {
  const { category, engine } = classifyPrompt(prompt, forcedEngine);
  const p = prompt.toLowerCase();

  let title = prompt.trim().slice(0, 42);
  if (!title || title.length < 4) {
    title = category === 'game_3d' ? 'Apex Highway 3D' : 'Smart Market Pro';
  } else {
    title = title.replace(/^(build|create|make|design)\s+(me\s+)?(a|an)?\s*/i, '').trim();
    title = title.charAt(0).toUpperCase() + title.slice(1);
    if (title.length > 36) title = title.slice(0, 36).trim();
  }

  if (category === 'game_3d') {
    const isTactical = /army|military|basecamp|tactical|jeep|desert|war|commando/.test(p);
    const isNight = /night|neon|cyber|city|midnight|drift/.test(p);
    const isMountain = /mountain|alpine|hill|rally|snow|offroad/.test(p);

    const game3d: Game3DConfig = {
      theme: isTactical
        ? 'tactical_basecamp'
        : isNight
        ? 'neon_city'
        : isMountain
        ? 'alpine_rally'
        : 'golden_highway',
      vehicleType: isTactical
        ? 'tactical_jeep'
        : isNight
        ? 'cyber_racer'
        : 'sports_coupe',
      primaryColor: isTactical ? '#5b6f47' : isNight ? '#06b6d4' : '#e11d48',
      accentColor: isNight ? '#8b5cf6' : '#f59e0b',
      topSpeed: isTactical ? 135 : 220,
      timeOfDay: isNight ? 'night' : 'golden',
      fogDensity: isNight ? 0.0065 : 0.0038,
    };

    return {
      id: `bp_${Date.now()}`,
      title,
      prompt,
      category,
      engine,
      summary: `Real-time 3D PBR world (${game3d.theme.replace('_', ' ')}) with ACESFilmic lighting, PCFSoftShadowMap, articulated multi-part ${game3d.vehicleType.replace('_', ' ')}, touch-drag steering, and Godot 4 Mobile Vulkan export.`,
      themePalette: [game3d.primaryColor, game3d.accentColor, '#070b14', '#10b981'],
      features: [
        'Golden-hour Sky & Directional Sunlight + FogExp2',
        'Multi-part 3D Vehicle with Headlights & Taillights',
        'On-Canvas Touch-Drag Steering + Virtual Pedals',
        'Apps Supabase Live Remote Speed & Banner Sync',
      ],
      screensOrZones: ['Open Terrain & Roadway', '3rd-Person Chase Camera', 'HUD Telemetry', 'Owner Admin Remote Config'],
      game3d,
      approved: false,
      createdAt: new Date().toISOString(),
    };
  }

  const commercialDefaults: Record<
    Exclude<ProjectCategory, 'game_3d'>,
    {
      tagline: string;
      primaryColor: string;
      accentColor: string;
      bannerText: string;
      features: string[];
      screens: string[];
    }
  > = {
    ecommerce: {
      tagline: 'Express Catalog, Smart Cart & Instant Checkout',
      primaryColor: '#06b6d4',
      accentColor: '#10b981',
      bannerText: 'Flash Deal · Use code SAVE15 for 15% off',
      features: ['Category & Price Filter Grid', 'Product Sheet & Live Cart Math', 'Coupon Engine + Order Status Tracker', 'Apps Supabase Live Banner & Price Sync'],
      screens: ['Catalog Home', 'Product Detail', 'Cart & Coupon', 'Order Tracker'],
    },
    khata_pos: {
      tagline: 'Udhar / Jama Ledger, UPI QR & Printable GST Receipts',
      primaryColor: '#10b981',
      accentColor: '#06b6d4',
      bannerText: 'Zero-Error Digital Khata · Instant UPI QR Settlement',
      features: ['Party Ledger with Automatic Net Balance', 'Udhar (Credit) & Jama (Debit) Forms', 'UPI QR Payment Modal', 'Printable Invoice Receipt Preview'],
      screens: ['Party List', 'Add Entry', 'UPI QR Modal', 'Invoice Receipt'],
    },
    ride_booking: {
      tagline: 'Live Route Estimator, Tier Selector & Driver ETA Tracker',
      primaryColor: '#8b5cf6',
      accentColor: '#06b6d4',
      bannerText: 'Zero Surge Ride & Express Parcel Dispatch',
      features: ['Pickup & Drop Route Planner', 'Interactive Map Card Preview', 'Multi-Tier Fare Calculator', 'Live Driver / Order ETA Tracker'],
      screens: ['Route Planner', 'Tier Selection', 'Live ETA Map', 'Booking Pass'],
    },
    finance_wallet: {
      tagline: 'Smart Wallet Ledger, Live Analytics & VIP Tier Control',
      primaryColor: '#06b6d4',
      accentColor: '#8b5cf6',
      bannerText: 'Instant Settlement Wallet · Live Market Signals',
      features: ['Balance & Transaction Ledger', 'Add / Withdraw Simulation', 'Live Odds & Analytics Cards', 'KYC / OTP Modal + VIP Tier State'],
      screens: ['Wallet Overview', 'Analytics & Odds', 'Add / Withdraw', 'KYC & VIP'],
    },
    card_board: {
      tagline: 'Interactive Felt Table, Live Pot Controls & Turn Timer',
      primaryColor: '#10b981',
      accentColor: '#f59e0b',
      bannerText: 'Championship Table · Live Turn Timer & Scoreboard',
      features: ['Interactive Card Table Felt', 'Multi-Seat Player Layout', 'Deal / Bet / Fold / Show Controls', 'Live Pot & Score State'],
      screens: ['Table Lobby', 'Live Felt Table', 'Turn Controls', 'Scoreboard'],
    },
  };

  const preset = commercialDefaults[category];
  const commercial: CommercialAppConfig = {
    category,
    appName: title,
    tagline: preset.tagline,
    primaryColor: preset.primaryColor,
    accentColor: preset.accentColor,
    currency: '₹',
    bannerText: preset.bannerText,
    vipUnlocked: false,
    discountPercent: 15,
  };

  return {
    id: `bp_${Date.now()}`,
    title,
    prompt,
    category,
    engine,
    summary: `Production mobile-first ${category.replace('_', ' ')} application built for Flutter APK + PIN-locked Owner Admin Web Panel synced via Apps Supabase.`,
    themePalette: [commercial.primaryColor, commercial.accentColor, '#070b14', '#f8fafc'],
    features: preset.features,
    screensOrZones: preset.screens,
    commercial,
    approved: false,
    createdAt: new Date().toISOString(),
  };
}

export function applyLivePatchToBlueprint(
  blueprint: DesignBlueprint,
  instruction: string
): { updated: DesignBlueprint; summary: string } {
  const inst = instruction.toLowerCase();
  const next: DesignBlueprint = JSON.parse(JSON.stringify(blueprint));
  const changes: string[] = [];

  if (next.game3d) {
    if (/night|dark|midnight/.test(inst)) {
      next.game3d.timeOfDay = 'night';
      next.game3d.fogDensity = 0.0068;
      changes.push('switched lighting to Night mode');
    } else if (/golden|sunset|evening/.test(inst)) {
      next.game3d.timeOfDay = 'golden';
      next.game3d.fogDensity = 0.0038;
      changes.push('switched lighting to Golden Hour');
    } else if (/noon|day|bright|morning/.test(inst)) {
      next.game3d.timeOfDay = 'noon';
      next.game3d.fogDensity = 0.0024;
      changes.push('switched lighting to Daylight');
    }

    if (/red|crimson|ferrari/.test(inst)) {
      next.game3d.primaryColor = '#ef4444';
      changes.push('painted vehicle Crimson Red');
    } else if (/blue|cyan|aqua/.test(inst)) {
      next.game3d.primaryColor = '#06b6d4';
      changes.push('painted vehicle Electric Cyan');
    } else if (/green|emerald|army|olive/.test(inst)) {
      next.game3d.primaryColor = '#10b981';
      changes.push('painted vehicle Emerald/Tactical Green');
    } else if (/gold|yellow|amber/.test(inst)) {
      next.game3d.primaryColor = '#f59e0b';
      changes.push('painted vehicle Gold');
    } else if (/purple|violet/.test(inst)) {
      next.game3d.primaryColor = '#8b5cf6';
      changes.push('painted vehicle Electric Purple');
    }

    if (/fast|turbo|speed|boost/.test(inst)) {
      next.game3d.topSpeed = Math.min(360, next.game3d.topSpeed + 60);
      changes.push(`boosted top speed to ${next.game3d.topSpeed} km/h`);
    }
    if (/jeep|army|basecamp|tactical/.test(inst)) {
      next.game3d.theme = 'tactical_basecamp';
      next.game3d.vehicleType = 'tactical_jeep';
      changes.push('switched to Tactical Basecamp + Armored Jeep');
    } else if (/city|cyber|neon/.test(inst)) {
      next.game3d.theme = 'neon_city';
      next.game3d.vehicleType = 'cyber_racer';
      changes.push('switched to Neon City + Cyber Racer');
    } else if (/mountain|alpine|rally/.test(inst)) {
      next.game3d.theme = 'alpine_rally';
      changes.push('switched environment to Alpine Rally');
    }
  }

  if (next.commercial) {
    if (/vip|unlock|pro/.test(inst)) {
      next.commercial.vipUnlocked = true;
      changes.push('unlocked VIP tier state');
    }
    if (/dollar|usd|\$/.test(inst)) {
      next.commercial.currency = '$';
      changes.push('switched currency to USD ($)');
    } else if (/rupee|inr|₹/.test(inst)) {
      next.commercial.currency = '₹';
      changes.push('switched currency to INR (₹)');
    }
    if (/purple|violet/.test(inst)) {
      next.commercial.primaryColor = '#8b5cf6';
      changes.push('updated primary accent to Electric Purple');
    } else if (/emerald|green/.test(inst)) {
      next.commercial.primaryColor = '#10b981';
      changes.push('updated primary accent to Emerald');
    } else if (/amber|gold|orange/.test(inst)) {
      next.commercial.primaryColor = '#f59e0b';
      changes.push('updated primary accent to Amber Gold');
    }
    const discountMatch = inst.match(/(\d{1,2})\s*%/);
    if (discountMatch) {
      next.commercial.discountPercent = Number(discountMatch[1]);
      next.commercial.bannerText = `Live Promo · ${discountMatch[1]}% instant discount active`;
      changes.push(`updated promo discount to ${discountMatch[1]}%`);
    }
  }

  if (changes.length === 0) {
    next.features = [...next.features.slice(0, 5), `Hot-patch: ${instruction.slice(0, 48)}`];
    changes.push(`applied live patch "${instruction.slice(0, 52)}"`);
  }

  return {
    updated: next,
    summary: changes.join(', '),
  };
}

export function generateOwnerAdminHtml(
  blueprint: DesignBlueprint,
  appsSupabase: SupabaseServerConfig,
  adminPin: string
): string {
  const appSlug = slugifyProjectName(blueprint.title);
  const supaUrl = appsSupabase.url?.trim() || 'YOUR_APPS_SUPABASE_URL';
  const supaKey = appsSupabase.anonKey?.trim() || 'YOUR_APPS_SUPABASE_ANON_KEY';

  return `<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="UTF-8" />
  <meta name="viewport" content="width=device-width, initial-scale=1.0" />
  <title>${blueprint.title} — Owner Admin Panel</title>
  <style>
    * { box-sizing: border-box; font-family: system-ui, -apple-system, sans-serif; }
    body { margin: 0; background: #070b14; color: #f8fafc; min-height: 100vh; display: flex; justify-content: center; padding: 20px; }
    .card { width: 100%; max-width: 520px; background: #0f172a; border: 1px solid #1e293b; border-radius: 16px; padding: 24px; }
    h1 { margin: 0 0 6px; font-size: 20px; color: #06b6d4; }
    p.sub { margin: 0 0 20px; font-size: 13px; color: #94a3b8; }
    label { display: block; font-size: 12px; color: #cbd5e1; margin: 14px 0 6px; }
    input, textarea { width: 100%; padding: 11px 12px; border-radius: 10px; border: 1px solid #334155; background: #070b14; color: #f8fafc; font-size: 14px; }
    .row { display: flex; gap: 12px; align-items: center; margin-top: 14px; }
    button { width: 100%; margin-top: 18px; padding: 12px; border: 0; border-radius: 10px; background: #06b6d4; color: #070b14; font-weight: 700; font-size: 14px; cursor: pointer; }
    button:hover { opacity: 0.92; }
    .status { margin-top: 14px; font-size: 13px; color: #10b981; min-height: 20px; }
    .hidden { display: none; }
  </style>
</head>
<body>
  <div class="card">
    <h1>${blueprint.title} · Owner Admin</h1>
    <p class="sub">Live remote control connected to Apps Supabase (slug: <code>${appSlug}</code>)</p>

    <div id="lockScreen">
      <label for="pinInput">Enter Owner PIN</label>
      <input id="pinInput" type="password" inputmode="numeric" placeholder="Enter 4-digit PIN" />
      <button onclick="unlock()">Unlock Admin Panel</button>
      <div id="lockErr" class="status" style="color:#f43f5e"></div>
    </div>

    <div id="adminBody" class="hidden">
      <label>Live Banner Title</label>
      <input id="bannerTitle" value="${blueprint.commercial?.bannerText || `${blueprint.title} Live Event`}" />
      <label>Push Announcement / Notification</label>
      <textarea id="announcement" rows="3" placeholder="Message pushed to all live APK users..."></textarea>
      <div class="row">
        <div style="flex:1">
          <label>Speed / Reward Multiplier</label>
          <input id="speedMultiplier" type="number" step="0.1" value="1.0" />
        </div>
        <div style="flex:1">
          <label>Discount %</label>
          <input id="discountPercent" type="number" value="${blueprint.commercial?.discountPercent ?? 15}" />
        </div>
      </div>
      <div class="row">
        <label style="margin:0;display:flex;gap:8px;align-items:center;">
          <input id="vipUnlocked" type="checkbox" style="width:auto" /> Unlock VIP for All Users
        </label>
      </div>
      <button onclick="publishLive()">Push Live Update to Public APK</button>
      <div id="status" class="status"></div>
    </div>
  </div>

  <script>
    const SUPABASE_URL = ${JSON.stringify(supaUrl)};
    const SUPABASE_ANON_KEY = ${JSON.stringify(supaKey)};
    const APP_SLUG = ${JSON.stringify(appSlug)};
    const EXPECTED_PIN = ${JSON.stringify(adminPin)};

    function unlock() {
      const val = document.getElementById('pinInput').value.trim();
      if (val === EXPECTED_PIN) {
        document.getElementById('lockScreen').classList.add('hidden');
        document.getElementById('adminBody').classList.remove('hidden');
        loadCurrent();
      } else {
        document.getElementById('lockErr').textContent = 'Invalid PIN. Try again.';
      }
    }

    async function loadCurrent() {
      if (!SUPABASE_URL.startsWith('https://')) return;
      try {
        const res = await fetch(SUPABASE_URL + '/rest/v1/apps_config?app_slug=eq.' + encodeURIComponent(APP_SLUG), {
          headers: { apikey: SUPABASE_ANON_KEY, Authorization: 'Bearer ' + SUPABASE_ANON_KEY }
        });
        const rows = await res.json();
        if (rows && rows[0]) {
          document.getElementById('bannerTitle').value = rows[0].banner_title || '';
          document.getElementById('announcement').value = rows[0].announcement || '';
          document.getElementById('speedMultiplier').value = rows[0].speed_multiplier ?? 1.0;
          document.getElementById('discountPercent').value = rows[0].discount_percent ?? 0;
          document.getElementById('vipUnlocked').checked = !!rows[0].vip_unlocked;
        }
      } catch (e) {}
    }

    async function publishLive() {
      const status = document.getElementById('status');
      if (!SUPABASE_URL.startsWith('https://')) {
        status.style.color = '#f59e0b';
        status.textContent = 'Apps Supabase URL was not configured at export time.';
        return;
      }
      status.style.color = '#06b6d4';
      status.textContent = 'Pushing update to Apps Supabase...';
      try {
        const res = await fetch(SUPABASE_URL + '/rest/v1/apps_config?on_conflict=app_slug', {
          method: 'POST',
          headers: {
            apikey: SUPABASE_ANON_KEY,
            Authorization: 'Bearer ' + SUPABASE_ANON_KEY,
            'Content-Type': 'application/json',
            Prefer: 'resolution=merge-duplicates'
          },
          body: JSON.stringify({
            app_slug: APP_SLUG,
            pin: EXPECTED_PIN,
            banner_title: document.getElementById('bannerTitle').value,
            announcement: document.getElementById('announcement').value,
            speed_multiplier: Number(document.getElementById('speedMultiplier').value || 1),
            discount_percent: Number(document.getElementById('discountPercent').value || 0),
            vip_unlocked: document.getElementById('vipUnlocked').checked,
            updated_at: new Date().toISOString()
          })
        });
        if (!res.ok) throw new Error('HTTP ' + res.status);
        status.style.color = '#10b981';
        status.textContent = 'Published live! All active APK installations will sync automatically.';
      } catch (err) {
        status.style.color = '#f43f5e';
        status.textContent = 'Push failed: ' + err.message;
      }
    }
  </script>
</body>
</html>
`;
}

export function generateProjectFiles(
  blueprint: DesignBlueprint,
  appsSupabase: SupabaseServerConfig,
  workflows: WorkflowTemplates,
  dynamicSkills: DynamicSkill[],
  adminPin: string
): GeneratedFile[] {
  const slug = slugifyProjectName(blueprint.title);
  const supaUrl = appsSupabase.url?.trim() || 'https://YOUR-APPS-PROJECT.supabase.co';
  const supaKey = appsSupabase.anonKey?.trim() || 'YOUR_APPS_SUPABASE_ANON_KEY';
  const enabledSkills = dynamicSkills.filter((s) => s.enabled);

  const adminHtml = generateOwnerAdminHtml(blueprint, appsSupabase, adminPin);

  if (blueprint.engine === 'godot4') {
    const g = blueprint.game3d || {
      theme: 'golden_highway',
      vehicleType: 'sports_coupe',
      primaryColor: '#e11d48',
      accentColor: '#f59e0b',
      topSpeed: 220,
      timeOfDay: 'golden',
      fogDensity: 0.0038,
    };

    return [
      {
        path: 'project.godot',
        language: 'ini',
        content: `; Engine configuration file generated by Sarfealam Auto-Studio
config_version=5

[application]
config/name="${blueprint.title}"
run/main_scene="res://scenes/main.tscn"
config/features=PackedStringArray("4.3", "Mobile")

[rendering]
renderer/rendering_method="mobile"
textures/vram_compression/import_etc2_astc=true
`,
      },
      {
        path: 'scripts/apps_supabase_bridge.gd',
        language: 'gdscript',
        content: `extends Node
class_name AppsSupabaseBridge

# Injected strictly from Apps Supabase (isolated from Studio Supabase)
const SUPABASE_URL := "${supaUrl}"
const SUPABASE_ANON_KEY := "${supaKey}"
const APP_SLUG := "${slug}"

signal remote_config_loaded(config: Dictionary)

var http: HTTPRequest

func _ready() -> void:
\thttp = HTTPRequest.new()
\tadd_child(http)
\thttp.request_completed.connect(_on_request_completed)
\tfetch_live_config()

func fetch_live_config() -> void:
\tif not SUPABASE_URL.begins_with("https://"):
\t\treturn
\tvar url := SUPABASE_URL + "/rest/v1/apps_config?app_slug=eq." + APP_SLUG + "&select=*"
\tvar headers := PackedStringArray([
\t\t"apikey: " + SUPABASE_ANON_KEY,
\t\t"Authorization: Bearer " + SUPABASE_ANON_KEY
\t])
\thttp.request(url, headers)

func _on_request_completed(_result: int, response_code: int, _headers: PackedStringArray, body: PackedByteArray) -> void:
\tif response_code != 200:
\t\treturn
\tvar parsed = JSON.parse_string(body.get_string_from_utf8())
\tif typeof(parsed) == TYPE_ARRAY and parsed.size() > 0:
\t\temit_signal("remote_config_loaded", parsed[0])
`,
      },
      {
        path: 'scripts/player_controller.gd',
        language: 'gdscript',
        content: `extends CharacterBody3D

@export var max_speed: float = ${(g.topSpeed / 4.2).toFixed(1)}
@export var steer_sensitivity: float = 2.6
var speed_multiplier: float = 1.0
var touch_steer: float = 0.0
var throttle: float = 0.0

func _ready() -> void:
\tvar bridge = get_node_or_null("/root/Main/AppsSupabaseBridge")
\tif bridge:
\t\tbridge.remote_config_loaded.connect(_on_remote_config)

func _on_remote_config(cfg: Dictionary) -> void:
\tspeed_multiplier = float(cfg.get("speed_multiplier", 1.0))

func _input(event: InputEvent) -> void:
\tif event is InputEventScreenDrag:
\t\ttouch_steer = clamp(touch_steer + event.relative.x * 0.008, -1.0, 1.0)
\t\tthrottle = 1.0

func _physics_process(delta: float) -> void:
\tvar steer := Input.get_axis("ui_right", "ui_left") - touch_steer
\trotate_y(steer * steer_sensitivity * delta)
\tvar forward := -transform.basis.z
\tvar target_vel := forward * (max_speed * speed_multiplier * max(throttle, Input.get_action_strength("ui_up")))
\tvelocity = velocity.lerp(target_vel, delta * 3.5)
\tmove_and_slide()
`,
      },
      {
        path: 'scenes/main.tscn',
        language: 'ini',
        content: `[gd_scene load_steps=4 format=3]

[ext_resource type="Script" path="res://scripts/apps_supabase_bridge.gd" id="1_supa"]
[ext_resource type="Script" path="res://scripts/player_controller.gd" id="2_player"]

[node name="Main" type="Node3D"]

[node name="AppsSupabaseBridge" type="Node" parent="."]
script = ExtResource("1_supa")

[node name="SunLight" type="DirectionalLight3D" parent="."]
transform = Transform3D(0.866, -0.353, 0.353, 0, 0.707, 0.707, -0.5, -0.612, 0.612, 0, 24, 0)
shadow_enabled = true

[node name="PlayerVehicle" type="CharacterBody3D" parent="."]
script = ExtResource("2_player")

[node name="ChaseCamera" type="Camera3D" parent="PlayerVehicle"]
transform = Transform3D(1, 0, 0, 0, 0.94, 0.34, 0, -0.34, 0.94, 0, 4.2, 8.5)
current = true
`,
      },
      {
        path: '.github/workflows/godot-android-apk.yml',
        language: 'yaml',
        content: workflows.godotApkYaml,
      },
      {
        path: '.github/workflows/deploy-admin.yml',
        language: 'yaml',
        content: workflows.deployAdminYaml,
      },
      {
        path: 'docs/index.html',
        language: 'html',
        content: adminHtml,
      },
      {
        path: 'README.md',
        language: 'markdown',
        content: `# ${blueprint.title}\n\nGenerated with Sarfealam Auto-Studio (Godot 4 Mobile Vulkan).\n\n- **Theme**: ${g.theme}\n- **Vehicle/Hero**: ${g.vehicleType}\n- **Apps Supabase Slug**: \`${slug}\`\n- **Dynamic Skills Injected**: ${enabledSkills.map((s) => s.packageName).join(', ') || 'Core Engine'}\n`,
      },
    ];
  }

  // Flutter Commercial App repository
  const c = blueprint.commercial || {
    category: 'ecommerce',
    appName: blueprint.title,
    tagline: 'Commercial Mobile App',
    primaryColor: '#06b6d4',
    accentColor: '#10b981',
    currency: '₹',
    bannerText: 'Live Offer Active',
  };

  return [
    {
      path: 'pubspec.yaml',
      language: 'yaml',
      content: `name: ${slug.replace(/-/g, '_')}
description: "${blueprint.title} built by Sarfealam Auto-Studio"
publish_to: 'none'
version: 1.0.0+1

environment:
  sdk: ">=3.4.0 <4.0.0"

dependencies:
  flutter:
    sdk: flutter
  http: ^1.2.2
${enabledSkills
  .filter((s) => s.source === 'pub.dev')
  .map((s) => `  ${s.packageName}: any`)
  .join('\n')}

flutter:
  uses-material-design: true
`,
    },
    {
      path: 'lib/supabase_config.dart',
      language: 'dart',
      content: `import 'dart:convert';
import 'package:http/http.dart' as http;

/// Strictly separated Apps Supabase configuration for live remote updates.
class AppsSupabaseConfig {
  static const String projectUrl = '${supaUrl}';
  static const String anonKey = '${supaKey}';
  static const String appSlug = '${slug}';

  static Future<Map<String, dynamic>?> fetchLiveConfig() async {
    if (!projectUrl.startsWith('https://')) return null;
    final uri = Uri.parse(
      '\$projectUrl/rest/v1/apps_config?app_slug=eq.\$appSlug&select=*',
    );
    final response = await http.get(
      uri,
      headers: {
        'apikey': anonKey,
        'Authorization': 'Bearer \$anonKey',
      },
    );
    if (response.statusCode == 200) {
      final list = jsonDecode(response.body) as List<dynamic>;
      if (list.isNotEmpty) return Map<String, dynamic>.from(list.first);
    }
    return null;
  }
}
`,
    },
    {
      path: 'lib/main.dart',
      language: 'dart',
      content: `import 'package:flutter/material.dart';
import 'supabase_config.dart';

void main() => runApp(const StudioGeneratedApp());

class StudioGeneratedApp extends StatelessWidget {
  const StudioGeneratedApp({super.key});

  @override
  Widget build(BuildContext context) {
    return MaterialApp(
      debugShowCheckedModeBanner: false,
      title: '${c.appName.replace(/'/g, "\\'")}',
      theme: ThemeData.dark().copyWith(
        scaffoldBackgroundColor: const Color(0xFF070B14),
        colorScheme: const ColorScheme.dark(
          primary: Color(0xFF06B6D4),
          secondary: Color(0xFF10B981),
        ),
      ),
      home: const HomeShell(),
    );
  }
}

class HomeShell extends StatefulWidget {
  const HomeShell({super.key});
  @override
  State<HomeShell> createState() => _HomeShellState();
}

class _HomeShellState extends State<HomeShell> {
  String bannerText = '${c.bannerText.replace(/'/g, "\\'")}';
  String announcement = '';
  bool vipUnlocked = ${c.vipUnlocked ? 'true' : 'false'};

  @override
  void initState() {
    super.initState();
    _loadRemoteConfig();
  }

  Future<void> _loadRemoteConfig() async {
    try {
      final cfg = await AppsSupabaseConfig.fetchLiveConfig();
      if (cfg != null && mounted) {
        setState(() {
          bannerText = (cfg['banner_title'] ?? bannerText).toString();
          announcement = (cfg['announcement'] ?? '').toString();
          vipUnlocked = cfg['vip_unlocked'] == true;
        });
      }
    } catch (_) {}
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        backgroundColor: const Color(0xFF0F172A),
        title: const Text('${c.appName.replace(/'/g, "\\'")}'),
        actions: [
          IconButton(icon: const Icon(Icons.refresh), onPressed: _loadRemoteConfig),
        ],
      ),
      body: ListView(
        padding: const EdgeInsets.all(16),
        children: [
          Container(
            padding: const EdgeInsets.all(16),
            decoration: BoxDecoration(
              color: const Color(0xFF0F172A),
              borderRadius: BorderRadius.circular(14),
              border: Border.all(color: const Color(0xFF06B6D4)),
            ),
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                Text(bannerText, style: const TextStyle(fontSize: 16, fontWeight: FontWeight.bold)),
                if (announcement.isNotEmpty) ...[
                  const SizedBox(height: 8),
                  Text(announcement, style: const TextStyle(color: Colors.white70)),
                ],
                const SizedBox(height: 8),
                Text(vipUnlocked ? 'VIP Tier Active' : 'Standard Tier', style: const TextStyle(color: Color(0xFF10B981))),
              ],
            ),
          ),
        ],
      ),
    );
  }
}
`,
    },
    {
      path: '.github/workflows/flutter-apk.yml',
      language: 'yaml',
      content: workflows.flutterApkYaml,
    },
    {
      path: '.github/workflows/deploy-admin.yml',
      language: 'yaml',
      content: workflows.deployAdminYaml,
    },
    {
      path: 'docs/index.html',
      language: 'html',
      content: adminHtml,
    },
    {
      path: 'README.md',
      language: 'markdown',
      content: `# ${blueprint.title}\n\nGenerated by Sarfealam Auto-Studio (Flutter Android APK + Owner Admin Web Panel).\n\n- **Category**: ${c.category}\n- **Apps Supabase Slug**: \`${slug}\`\n- **Dynamic Skills**: ${enabledSkills.map((s) => s.packageName).join(', ') || 'Core Flutter'}\n`,
    },
  ];
}

export async function downloadProjectZip(repoName: string, files: GeneratedFile[]): Promise<void> {
  const zip = new JSZip();
  for (const file of files) {
    zip.file(file.path, file.content);
  }
  const blob = await zip.generateAsync({ type: 'blob' });
  const url = URL.createObjectURL(blob);
  const a = document.createElement('a');
  a.href = url;
  a.download = `${repoName}.zip`;
  document.body.appendChild(a);
  a.click();
  document.body.removeChild(a);
  URL.revokeObjectURL(url);
}
