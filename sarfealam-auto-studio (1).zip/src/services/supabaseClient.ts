import {
  Checkpoint,
  DynamicSkill,
  Language,
  RemoteAdminConfig,
  SupabaseServerConfig,
  VaultBuild,
} from '../types';

export interface StudioCloudPayload {
  language: Language;
  vaultBuilds: VaultBuild[];
  checkpoints: Checkpoint[];
  dynamicSkills: DynamicSkill[];
  activePrompt?: string;
  updatedAt: string;
}

function normalizeUrl(url: string): string {
  return url.trim().replace(/\/+$/, '');
}

function buildHeaders(anonKey: string, extra?: Record<string, string>): HeadersInit {
  return {
    apikey: anonKey.trim(),
    Authorization: `Bearer ${anonKey.trim()}`,
    'Content-Type': 'application/json',
    ...extra,
  };
}

export async function testSupabaseConnection(
  config: SupabaseServerConfig,
  expectedTable: 'studio_state' | 'apps_config'
): Promise<{ ok: boolean; message: string; tableReady: boolean }> {
  const baseUrl = normalizeUrl(config.url);
  const key = config.anonKey.trim();
  if (!baseUrl || !key) {
    return {
      ok: false,
      message: 'Missing Project URL or Anon/Publishable Key.',
      tableReady: false,
    };
  }
  if (!/^https:\/\/.+\.supabase\.co$/i.test(baseUrl) && !baseUrl.startsWith('https://')) {
    return {
      ok: false,
      message: 'Project URL must start with https:// (e.g. https://xxxx.supabase.co).',
      tableReady: false,
    };
  }

  try {
    const res = await fetch(`${baseUrl}/rest/v1/${expectedTable}?select=*&limit=1`, {
      method: 'GET',
      headers: buildHeaders(key),
    });

    if (res.ok) {
      return {
        ok: true,
        tableReady: true,
        message: `Connected directly to ${expectedTable} (HTTP ${res.status}).`,
      };
    }

    const bodyText = await res.text();
    if (res.status === 404 || bodyText.includes('does not exist') || bodyText.includes('PGRST205')) {
      return {
        ok: true,
        tableReady: false,
        message: `Supabase reachable, but table "${expectedTable}" is not created yet. Copy & run the SQL schema below in Supabase SQL Editor.`,
      };
    }

    if (res.status === 401 || res.status === 403) {
      return {
        ok: false,
        tableReady: false,
        message: `Authentication rejected (HTTP ${res.status}). Verify your Anon/Publishable Key and RLS policies.`,
      };
    }

    return {
      ok: false,
      tableReady: false,
      message: `Supabase returned HTTP ${res.status}: ${bodyText.slice(0, 140)}`,
    };
  } catch (err) {
    return {
      ok: false,
      tableReady: false,
      message: `Network error reaching Supabase: ${err instanceof Error ? err.message : String(err)}`,
    };
  }
}

export async function syncStudioStateToSupabase(
  config: SupabaseServerConfig,
  payload: StudioCloudPayload
): Promise<{ ok: boolean; error?: string }> {
  if (!config.connected || !config.url || !config.anonKey) {
    return { ok: false, error: 'Studio Supabase not connected.' };
  }
  const baseUrl = normalizeUrl(config.url);
  try {
    const res = await fetch(`${baseUrl}/rest/v1/studio_state?on_conflict=id`, {
      method: 'POST',
      headers: buildHeaders(config.anonKey, {
        Prefer: 'resolution=merge-duplicates,return=minimal',
      }),
      body: JSON.stringify({
        id: 'primary_studio',
        language: payload.language,
        vault_builds: payload.vaultBuilds,
        checkpoints: payload.checkpoints.slice(0, 10),
        dynamic_skills: payload.dynamicSkills,
        active_job: payload.activePrompt || '',
        updated_at: payload.updatedAt,
      }),
    });
    if (!res.ok) {
      const txt = await res.text();
      return { ok: false, error: `HTTP ${res.status}: ${txt.slice(0, 120)}` };
    }
    return { ok: true };
  } catch (err) {
    return { ok: false, error: err instanceof Error ? err.message : String(err) };
  }
}

export async function restoreStudioStateFromSupabase(
  config: SupabaseServerConfig
): Promise<{ ok: boolean; data?: StudioCloudPayload; error?: string }> {
  if (!config.connected || !config.url || !config.anonKey) {
    return { ok: false, error: 'Studio Supabase not connected.' };
  }
  const baseUrl = normalizeUrl(config.url);
  try {
    const res = await fetch(`${baseUrl}/rest/v1/studio_state?id=eq.primary_studio&select=*`, {
      method: 'GET',
      headers: buildHeaders(config.anonKey),
    });
    if (!res.ok) {
      return { ok: false, error: `HTTP ${res.status}` };
    }
    const rows = (await res.json()) as Array<Record<string, unknown>>;
    if (!rows.length) {
      return { ok: true, data: undefined };
    }
    const row = rows[0];
    return {
      ok: true,
      data: {
        language: (row.language === 'hi' ? 'hi' : 'en') as Language,
        vaultBuilds: Array.isArray(row.vault_builds) ? (row.vault_builds as VaultBuild[]) : [],
        checkpoints: Array.isArray(row.checkpoints) ? (row.checkpoints as Checkpoint[]) : [],
        dynamicSkills: Array.isArray(row.dynamic_skills) ? (row.dynamic_skills as DynamicSkill[]) : [],
        activePrompt: typeof row.active_job === 'string' ? row.active_job : '',
        updatedAt: typeof row.updated_at === 'string' ? row.updated_at : new Date().toISOString(),
      },
    };
  } catch (err) {
    return { ok: false, error: err instanceof Error ? err.message : String(err) };
  }
}

export async function pushAppsRemoteConfig(
  config: SupabaseServerConfig,
  adminConfig: RemoteAdminConfig
): Promise<{ ok: boolean; message: string }> {
  if (!config.connected || !config.url || !config.anonKey) {
    return { ok: false, message: 'Apps Supabase not connected. Configure it in Secrets first.' };
  }
  const baseUrl = normalizeUrl(config.url);
  try {
    const res = await fetch(`${baseUrl}/rest/v1/apps_config?on_conflict=app_slug`, {
      method: 'POST',
      headers: buildHeaders(config.anonKey, {
        Prefer: 'resolution=merge-duplicates,return=representation',
      }),
      body: JSON.stringify({
        app_slug: adminConfig.appSlug,
        pin: adminConfig.pin,
        banner_title: adminConfig.bannerTitle,
        announcement: adminConfig.announcement,
        vip_unlocked: adminConfig.vipUnlocked,
        speed_multiplier: adminConfig.speedMultiplier,
        discount_percent: adminConfig.discountPercent,
        maintenance_mode: adminConfig.maintenanceMode,
        updated_at: new Date().toISOString(),
      }),
    });
    if (!res.ok) {
      const txt = await res.text();
      return { ok: false, message: `Apps Supabase HTTP ${res.status}: ${txt.slice(0, 140)}` };
    }
    return { ok: true, message: 'Live config pushed to Apps Supabase. Published APKs will reflect changes immediately.' };
  } catch (err) {
    return { ok: false, message: err instanceof Error ? err.message : String(err) };
  }
}

export async function fetchAppsRemoteConfig(
  config: SupabaseServerConfig,
  appSlug: string
): Promise<{ ok: boolean; data?: Partial<RemoteAdminConfig>; message?: string }> {
  if (!config.connected || !config.url || !config.anonKey) {
    return { ok: false, message: 'Apps Supabase not connected.' };
  }
  const baseUrl = normalizeUrl(config.url);
  try {
    const res = await fetch(
      `${baseUrl}/rest/v1/apps_config?app_slug=eq.${encodeURIComponent(appSlug)}&select=*`,
      {
        method: 'GET',
        headers: buildHeaders(config.anonKey),
      }
    );
    if (!res.ok) return { ok: false, message: `HTTP ${res.status}` };
    const rows = (await res.json()) as Array<Record<string, unknown>>;
    if (!rows.length) return { ok: true };
    const r = rows[0];
    return {
      ok: true,
      data: {
        appSlug: String(r.app_slug || appSlug),
        pin: String(r.pin || '1234'),
        bannerTitle: String(r.banner_title || ''),
        announcement: String(r.announcement || ''),
        vipUnlocked: Boolean(r.vip_unlocked),
        speedMultiplier: Number(r.speed_multiplier || 1),
        discountPercent: Number(r.discount_percent || 0),
        maintenanceMode: Boolean(r.maintenance_mode),
        updatedAt: String(r.updated_at || ''),
      },
    };
  } catch (err) {
    return { ok: false, message: err instanceof Error ? err.message : String(err) };
  }
}

export const STUDIO_SUPABASE_SQL = `-- Run in STUDIO SUPABASE SQL Editor (Studio records only)
create table if not exists public.studio_state (
  id text primary key,
  language text default 'en',
  vault_builds jsonb default '[]'::jsonb,
  checkpoints jsonb default '[]'::jsonb,
  dynamic_skills jsonb default '[]'::jsonb,
  active_job text default '',
  updated_at timestamptz default now()
);
alter table public.studio_state enable row level security;
create policy "studio_anon_all" on public.studio_state for all using (true) with check (true);`;

export const APPS_SUPABASE_SQL = `-- Run in APPS SUPABASE SQL Editor (Exported APKs + Owner Admin Web Panel)
create table if not exists public.apps_config (
  app_slug text primary key,
  pin text default '1234',
  banner_title text default 'Welcome',
  announcement text default '',
  vip_unlocked boolean default false,
  speed_multiplier numeric default 1.0,
  discount_percent integer default 0,
  maintenance_mode boolean default false,
  updated_at timestamptz default now()
);
alter table public.apps_config enable row level security;
create policy "apps_config_public" on public.apps_config for all using (true) with check (true);`;
