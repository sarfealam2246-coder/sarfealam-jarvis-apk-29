import { useState } from 'react';
import {
  Code2,
  Cpu,
  Download,
  ExternalLink,
  FolderArchive,
  RefreshCw,
  RotateCcw,
  Search,
  Shield,
  Sliders,
} from 'lucide-react';
import {
  Checkpoint,
  CoreSkillToggles,
  DepartmentAssignment,
  DynamicSkill,
  GeneratedFile,
  Language,
  RemoteAdminConfig,
  SecretsState,
  VaultBuild,
  WorkflowTemplates,
} from '../types';
import { t } from '../services/i18n';
import { downloadProjectZip } from '../services/projectGenerator';
import { pollGitHubBuildStatus } from '../services/githubExporter';
import { pushAppsRemoteConfig } from '../services/supabaseClient';
import { discoverDynamicSkill } from '../services/externalSources';

/* ============================================================================
 * 1. VAULT PANEL (Dual Links: Public APK + Owner Admin Web Link + Checkpoints)
 * ============================================================================ */
export function VaultPanel({
  lang,
  builds,
  checkpoints,
  secrets,
  onUpdateBuild,
  onRestoreCheckpoint,
}: {
  lang: Language;
  builds: VaultBuild[];
  checkpoints: Checkpoint[];
  secrets: SecretsState;
  onUpdateBuild: (id: string, patch: Partial<VaultBuild>) => void;
  onRestoreCheckpoint: (cp: Checkpoint) => void;
}) {
  const [pollingId, setPollingId] = useState<string | null>(null);
  const [pollNote, setPollNote] = useState<Record<string, string>>({});

  const handlePoll = async (b: VaultBuild) => {
    if (!secrets.github.connected) {
      setPollNote((p) => ({ ...p, [b.id]: 'Connect GitHub in Secrets first to poll real Actions status.' }));
      return;
    }
    setPollingId(b.id);
    const res = await pollGitHubBuildStatus(
      secrets.github.verifiedLogin || secrets.github.username,
      secrets.github.token,
      b.repoName
    );
    onUpdateBuild(b.id, {
      status: res.status,
      publicApkUrl: res.apkDownloadUrl || b.publicApkUrl,
      actionsRunUrl: res.runUrl || b.actionsRunUrl,
    });
    setPollNote((p) => ({ ...p, [b.id]: res.detail }));
    setPollingId(null);
  };

  return (
    <div className="space-y-5 pb-6">
      <div className="space-y-3">
        <div className="flex items-center justify-between">
          <div className="flex items-center gap-2 text-sm font-bold text-white">
            <FolderArchive className="w-4 h-4 text-cyan-400" />
            <span>Exported Builds & Dual Links</span>
          </div>
          <span className="text-xs text-slate-400 font-mono tabular-nums">{builds.length} builds</span>
        </div>

        {builds.length === 0 ? (
          <div className="p-6 rounded-2xl bg-[#0b1120] border border-white/10 text-center space-y-1">
            <div className="text-sm font-semibold text-slate-200">No Exported Builds Yet</div>
            <div className="text-xs text-slate-400">
              Complete Stage 5 on Display A and tap OK to publish Public APK + Owner Admin links or download a local ZIP.
            </div>
          </div>
        ) : (
          builds.map((b) => (
            <div key={b.id} className="p-4 rounded-2xl bg-[#0b1120] border border-white/10 space-y-3">
              <div className="flex items-start justify-between gap-2">
                <div>
                  <div className="text-sm font-bold text-white">{b.name}</div>
                  <div className="text-[11px] text-slate-400">
                    {b.engine === 'godot4' ? 'Godot 4 Vulkan' : 'Flutter APK'} · PIN: <span className="font-mono text-cyan-300">{b.adminPin}</span> · {new Date(b.createdAt).toLocaleString()}
                  </div>
                </div>
                <span
                  className={`text-xs font-semibold ${
                    b.status === 'apk_ready'
                      ? 'text-emerald-400'
                      : b.status === 'failed'
                      ? 'text-rose-400'
                      : 'text-amber-300'
                  }`}
                >
                  {b.status === 'apk_ready'
                    ? 'APK Verified'
                    : b.status === 'actions_running'
                    ? 'Building on Actions'
                    : b.status === 'local_only'
                    ? 'Local ZIP Only'
                    : b.status === 'failed'
                    ? 'Build Failed'
                    : 'Pushing...'}
                </span>
              </div>

              {/* Dual Clickable Links when pushed to GitHub */}
              {b.publicApkUrl && b.ownerAdminUrl ? (
                <div className="grid grid-cols-1 sm:grid-cols-2 gap-2">
                  <a
                    href={b.publicApkUrl}
                    target="_blank"
                    rel="noreferrer"
                    className="p-2.5 rounded-xl bg-emerald-500/15 border border-emerald-400/40 text-xs font-semibold text-emerald-200 flex items-center justify-between gap-2 hover:bg-emerald-500/20"
                  >
                    <span className="truncate">{t(lang, 'publicApkLink')}</span>
                    <ExternalLink className="w-3.5 h-3.5 shrink-0" />
                  </a>
                  <a
                    href={b.ownerAdminUrl}
                    target="_blank"
                    rel="noreferrer"
                    className="p-2.5 rounded-xl bg-purple-500/15 border border-purple-400/40 text-xs font-semibold text-purple-200 flex items-center justify-between gap-2 hover:bg-purple-500/20"
                  >
                    <span className="truncate">{t(lang, 'ownerAdminLink')}</span>
                    <ExternalLink className="w-3.5 h-3.5 shrink-0" />
                  </a>
                </div>
              ) : (
                <div className="text-xs text-slate-400">
                  GitHub was not connected during export. Connect GitHub in Secrets for automatic Public APK & Owner Admin Pages links.
                </div>
              )}

              <div className="flex flex-wrap items-center gap-2">
                {b.repoUrl && (
                  <button
                    type="button"
                    onClick={() => handlePoll(b)}
                    disabled={pollingId === b.id}
                    className="px-3 py-1.5 min-h-[36px] rounded-lg bg-[#070b14] border border-white/10 text-xs text-cyan-300 flex items-center gap-1.5"
                  >
                    <RefreshCw className={`w-3.5 h-3.5 ${pollingId === b.id ? 'animate-spin' : ''}`} />
                    <span>Poll GitHub Actions / APK</span>
                  </button>
                )}
                <button
                  type="button"
                  onClick={() => downloadProjectZip(b.repoName, b.files)}
                  className="px-3 py-1.5 min-h-[36px] rounded-lg bg-[#070b14] border border-white/10 text-xs text-slate-200 flex items-center gap-1.5"
                >
                  <Download className="w-3.5 h-3.5" />
                  <span>{t(lang, 'downloadZip')}</span>
                </button>
              </div>

              {pollNote[b.id] && <div className="text-xs text-cyan-300">{pollNote[b.id]}</div>}
              {b.errorMessage && <div className="text-xs text-rose-400">{b.errorMessage}</div>}
            </div>
          ))
        )}
      </div>

      {/* Saved 1-Second Rollback Checkpoints */}
      <div className="space-y-2.5">
        <div className="text-sm font-bold text-white">Saved Checkpoints (1-Second Rollback)</div>
        {checkpoints.length === 0 ? (
          <div className="text-xs text-slate-500">Checkpoints are captured automatically before every build and live hot-patch.</div>
        ) : (
          <div className="space-y-2">
            {checkpoints.map((cp) => (
              <div
                key={cp.id}
                className="p-3 rounded-xl bg-[#0b1120] border border-white/10 flex items-center justify-between gap-2"
              >
                <div className="min-w-0">
                  <div className="text-xs font-semibold text-white truncate">{cp.label}</div>
                  <div className="text-[11px] text-slate-400">
                    Stage {cp.stage}/5 · {new Date(cp.timestamp).toLocaleTimeString()}
                  </div>
                </div>
                <button
                  type="button"
                  onClick={() => onRestoreCheckpoint(cp)}
                  className="px-3 py-1.5 min-h-[36px] rounded-lg bg-purple-500/20 border border-purple-400/40 text-xs font-semibold text-purple-200 flex items-center gap-1 shrink-0"
                >
                  <RotateCcw className="w-3.5 h-3.5" />
                  <span>Restore</span>
                </button>
              </div>
            ))}
          </div>
        )}
      </div>
    </div>
  );
}

/* ============================================================================
 * 2. OWNER ADMIN LIVE REMOTE CONFIG PANEL (Apps Supabase)
 * ============================================================================ */
export function AdminPanel({
  secrets,
  adminConfig,
  latestBuild,
  onChangeConfig,
}: {
  secrets: SecretsState;
  adminConfig: RemoteAdminConfig;
  latestBuild?: VaultBuild;
  onChangeConfig: (next: RemoteAdminConfig) => void;
}) {
  const [pushBusy, setPushBusy] = useState(false);
  const [pushMsg, setPushMsg] = useState<string | null>(null);

  const handlePush = async () => {
    setPushBusy(true);
    setPushMsg('Pushing live remote config to Apps Supabase...');
    const res = await pushAppsRemoteConfig(secrets.appsSupabase, adminConfig);
    setPushMsg(res.message);
    setPushBusy(false);
  };

  return (
    <div className="space-y-4 pb-6">
      <div className="p-4 rounded-2xl bg-[#0b1120] border border-white/10 space-y-3">
        <div className="flex items-center justify-between gap-2">
          <div className="flex items-center gap-2">
            <Shield className="w-4 h-4 text-purple-400" />
            <h3 className="text-sm font-bold text-white">Owner Admin Remote Control</h3>
          </div>
          <span className={`text-xs ${secrets.appsSupabase.connected ? 'text-emerald-400' : 'text-amber-300'}`}>
            {secrets.appsSupabase.connected ? 'Apps Supabase Live' : 'Apps Supabase Missing'}
          </span>
        </div>

        <p className="text-xs text-slate-400">
          Updates pushed here write directly to <code className="text-purple-300">Apps Supabase (apps_config)</code> so published APKs reflect live banners, VIP unlocks, speed, or discounts without rebuilding.
        </p>

        {latestBuild?.ownerAdminUrl && (
          <a
            href={latestBuild.ownerAdminUrl}
            target="_blank"
            rel="noreferrer"
            className="flex items-center justify-between p-3 rounded-xl bg-purple-500/15 border border-purple-400/40 text-xs font-semibold text-purple-200"
          >
            <span>Open Deployed Owner Admin Web Link ({latestBuild.name})</span>
            <ExternalLink className="w-4 h-4 shrink-0" />
          </a>
        )}

        <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
          <div className="space-y-1">
            <label className="text-[11px] text-slate-300">App Slug</label>
            <input
              value={adminConfig.appSlug}
              onChange={(e) => onChangeConfig({ ...adminConfig, appSlug: e.target.value })}
              className="w-full min-h-[40px] px-3 rounded-xl bg-[#070b14] border border-white/10 text-xs font-mono text-white"
            />
          </div>
          <div className="space-y-1">
            <label className="text-[11px] text-slate-300">Owner Web Panel PIN</label>
            <input
              value={adminConfig.pin}
              onChange={(e) => onChangeConfig({ ...adminConfig, pin: e.target.value })}
              className="w-full min-h-[40px] px-3 rounded-xl bg-[#070b14] border border-white/10 text-xs font-mono text-white"
            />
          </div>
        </div>

        <div className="space-y-1">
          <label className="text-[11px] text-slate-300">Live App Banner Headline</label>
          <input
            value={adminConfig.bannerTitle}
            onChange={(e) => onChangeConfig({ ...adminConfig, bannerTitle: e.target.value })}
            className="w-full min-h-[40px] px-3 rounded-xl bg-[#070b14] border border-white/10 text-xs text-white"
          />
        </div>

        <div className="space-y-1">
          <label className="text-[11px] text-slate-300">Push Announcement / Live Notification</label>
          <textarea
            rows={2}
            value={adminConfig.announcement}
            onChange={(e) => onChangeConfig({ ...adminConfig, announcement: e.target.value })}
            placeholder="Message broadcast to all live APK users..."
            className="w-full p-3 rounded-xl bg-[#070b14] border border-white/10 text-xs text-white"
          />
        </div>

        <div className="grid grid-cols-2 gap-3">
          <div className="space-y-1">
            <label className="text-[11px] text-slate-300">Speed / Reward Multiplier</label>
            <input
              type="number"
              step="0.1"
              value={adminConfig.speedMultiplier}
              onChange={(e) => onChangeConfig({ ...adminConfig, speedMultiplier: Number(e.target.value || 1) })}
              className="w-full min-h-[40px] px-3 rounded-xl bg-[#070b14] border border-white/10 text-xs font-mono text-white"
            />
          </div>
          <div className="space-y-1">
            <label className="text-[11px] text-slate-300">Promo Discount %</label>
            <input
              type="number"
              value={adminConfig.discountPercent}
              onChange={(e) => onChangeConfig({ ...adminConfig, discountPercent: Number(e.target.value || 0) })}
              className="w-full min-h-[40px] px-3 rounded-xl bg-[#070b14] border border-white/10 text-xs font-mono text-white"
            />
          </div>
        </div>

        <label className="flex items-center gap-2 text-xs text-slate-200 cursor-pointer pt-1">
          <input
            type="checkbox"
            checked={adminConfig.vipUnlocked}
            onChange={(e) => onChangeConfig({ ...adminConfig, vipUnlocked: e.target.checked })}
            className="w-4 h-4 accent-cyan-400"
          />
          <span>Unlock VIP Tier remotely for all APK users</span>
        </label>

        <button
          type="button"
          onClick={handlePush}
          disabled={pushBusy}
          className="w-full min-h-[44px] rounded-xl bg-purple-500 hover:bg-purple-400 text-white text-xs font-bold transition-colors disabled:opacity-50"
        >
          {pushBusy ? 'Pushing Live...' : 'Push Live Remote Config to Apps Supabase'}
        </button>

        {pushMsg && <div className="text-xs text-cyan-300">{pushMsg}</div>}
      </div>
    </div>
  );
}

/* ============================================================================
 * 3. SKILLS & WORKFLOW YAML TEMPLATE MANAGER (Self-Discovering Skill Loop)
 * ============================================================================ */
export function SkillsPanel({
  coreToggles,
  workflows,
  dynamicSkills,
  onChangeToggles,
  onChangeWorkflows,
  onAddDynamicSkill,
  onToggleDynamicSkill,
}: {
  coreToggles: CoreSkillToggles;
  workflows: WorkflowTemplates;
  dynamicSkills: DynamicSkill[];
  onChangeToggles: (next: CoreSkillToggles) => void;
  onChangeWorkflows: (next: WorkflowTemplates) => void;
  onAddDynamicSkill: (skill: DynamicSkill) => void;
  onToggleDynamicSkill: (id: string) => void;
}) {
  const [searchQuery, setSearchQuery] = useState('');
  const [searching, setSearching] = useState(false);
  const [searchMsg, setSearchMsg] = useState<string | null>(null);
  const [yamlTab, setYamlTab] = useState<'flutter' | 'godot'>('flutter');

  const handleDiscover = async () => {
    if (!searchQuery.trim()) return;
    setSearching(true);
    setSearchMsg('Searching live open sources (npm / GitHub)...');
    const skill = await discoverDynamicSkill(searchQuery);
    if (skill) {
      onAddDynamicSkill(skill);
      setSearchMsg(`Discovered & registered "${skill.packageName}" into Studio Skills.`);
      setSearchQuery('');
    } else {
      setSearchMsg('No matching open package found. Try a broader capability keyword.');
    }
    setSearching(false);
  };

  return (
    <div className="space-y-5 pb-6">
      {/* Compact Core Capability Switches */}
      <div className="p-4 rounded-2xl bg-[#0b1120] border border-white/10 space-y-3">
        <div className="flex items-center gap-2 text-sm font-bold text-white">
          <Sliders className="w-4 h-4 text-cyan-400" />
          <span>Core Engine Switches</span>
        </div>
        <div className="grid grid-cols-1 sm:grid-cols-2 gap-2 text-xs">
          {(
            [
              ['visionSelfHeal', 'Vision Self-Heal QA'],
              ['autoCheckpoint', 'Auto Checkpoint Before Patch'],
              ['polyHavenAssets', 'Poly Haven PBR / HDRI Lookup'],
              ['selfDiscoverSkills', 'Self-Discovering Skill Loop'],
              ['dualSupabaseInject', 'Auto-Inject Apps Supabase on Export'],
            ] as const
          ).map(([key, label]) => (
            <label
              key={key}
              className="flex items-center justify-between p-2.5 rounded-xl bg-[#070b14] border border-white/10 cursor-pointer"
            >
              <span className="text-slate-200">{label}</span>
              <input
                type="checkbox"
                checked={coreToggles[key]}
                onChange={(e) => onChangeToggles({ ...coreToggles, [key]: e.target.checked })}
                className="w-4 h-4 accent-cyan-400"
              />
            </label>
          ))}
        </div>
      </div>

      {/* Self-Discovering Skill Loop */}
      <div className="p-4 rounded-2xl bg-[#0b1120] border border-white/10 space-y-3">
        <div className="text-sm font-bold text-white">Self-Discovering Dynamic Skills</div>
        <p className="text-xs text-slate-400">
          Need Bluetooth Thermal Printing, QR/PDF Invoices, Weather API, or Custom 3D Shaders? Search live open packages to register a new dynamic skill automatically.
        </p>
        <div className="flex gap-2">
          <input
            value={searchQuery}
            onChange={(e) => setSearchQuery(e.target.value)}
            placeholder="e.g. bluetooth thermal printer, pdf invoice, weather"
            className="flex-1 min-h-[42px] px-3 rounded-xl bg-[#070b14] border border-white/10 text-xs text-white focus:outline-none"
          />
          <button
            type="button"
            onClick={handleDiscover}
            disabled={searching}
            className="px-4 min-h-[42px] rounded-xl bg-cyan-500 text-slate-950 text-xs font-bold flex items-center gap-1.5 shrink-0"
          >
            <Search className="w-3.5 h-3.5" />
            <span>{searching ? 'Searching...' : 'Discover'}</span>
          </button>
        </div>
        {searchMsg && <div className="text-xs text-cyan-300">{searchMsg}</div>}

        {dynamicSkills.length > 0 && (
          <div className="space-y-1.5 pt-1">
            {dynamicSkills.map((sk) => (
              <div
                key={sk.id}
                className="p-2.5 rounded-xl bg-[#070b14] border border-white/10 flex items-center justify-between gap-2"
              >
                <div className="min-w-0">
                  <div className="text-xs font-semibold text-white truncate">
                    {sk.packageName} · <span className="text-cyan-400">{sk.source}</span>
                  </div>
                  <div className="text-[11px] text-slate-400 truncate">{sk.description}</div>
                </div>
                <input
                  type="checkbox"
                  checked={sk.enabled}
                  onChange={() => onToggleDynamicSkill(sk.id)}
                  className="w-4 h-4 accent-emerald-400 shrink-0"
                />
              </div>
            ))}
          </div>
        )}
      </div>

      {/* Workflow YAML Template Manager */}
      <div className="p-4 rounded-2xl bg-[#0b1120] border border-white/10 space-y-3">
        <div className="flex items-center justify-between gap-2">
          <div className="text-sm font-bold text-white">GitHub Actions YAML Templates</div>
          <div className="flex gap-1 bg-[#070b14] p-1 rounded-lg border border-white/10">
            <button
              type="button"
              onClick={() => setYamlTab('flutter')}
              className={`px-2.5 py-1 rounded-md text-xs font-medium ${
                yamlTab === 'flutter' ? 'bg-cyan-500 text-slate-950' : 'text-slate-400'
              }`}
            >
              Flutter APK
            </button>
            <button
              type="button"
              onClick={() => setYamlTab('godot')}
              className={`px-2.5 py-1 rounded-md text-xs font-medium ${
                yamlTab === 'godot' ? 'bg-cyan-500 text-slate-950' : 'text-slate-400'
              }`}
            >
              Godot 4 APK
            </button>
          </div>
        </div>
        <textarea
          rows={10}
          value={yamlTab === 'flutter' ? workflows.flutterApkYaml : workflows.godotApkYaml}
          onChange={(e) =>
            onChangeWorkflows(
              yamlTab === 'flutter'
                ? { ...workflows, flutterApkYaml: e.target.value }
                : { ...workflows, godotApkYaml: e.target.value }
            )
          }
          className="w-full p-3 rounded-xl bg-[#070b14] border border-white/10 text-[11px] font-mono text-cyan-200 focus:outline-none"
        />
      </div>
    </div>
  );
}

/* ============================================================================
 * 4. CODE EXPLORER PANEL (Multi-file Repository Tree + Viewer)
 * ============================================================================ */
export function CodeExplorerPanel({ files }: { files: GeneratedFile[] }) {
  const [selectedPath, setSelectedPath] = useState(files[0]?.path || '');
  const active = files.find((f) => f.path === selectedPath) || files[0];

  if (files.length === 0) {
    return (
      <div className="p-6 rounded-2xl bg-[#0b1120] border border-white/10 text-center text-xs text-slate-400">
        No generated files yet. Start a Design Preview & Build to inspect generated Flutter, Godot 4, GitHub Actions, and Owner Admin source files.
      </div>
    );
  }

  return (
    <div className="space-y-3 pb-6">
      <div className="flex items-center gap-2 text-sm font-bold text-white">
        <Code2 className="w-4 h-4 text-cyan-400" />
        <span>Generated Repository ({files.length} files)</span>
      </div>
      <div className="flex flex-wrap gap-1.5">
        {files.map((f) => (
          <button
            key={f.path}
            type="button"
            onClick={() => setSelectedPath(f.path)}
            className={`px-2.5 py-1.5 rounded-lg text-xs font-mono border ${
              active?.path === f.path
                ? 'bg-cyan-500/20 border-cyan-400/50 text-cyan-200'
                : 'bg-[#0b1120] border-white/10 text-slate-400 hover:text-white'
            }`}
          >
            {f.path}
          </button>
        ))}
      </div>
      {active && (
        <pre className="p-3.5 rounded-xl bg-[#070b14] border border-white/10 text-[11px] font-mono text-slate-200 overflow-x-auto max-h-[420px]">
          {active.content}
        </pre>
      )}
    </div>
  );
}

/* ============================================================================
 * 5. SYSTEM MAP PANEL (Honest Department Routing & Infrastructure Status)
 * ============================================================================ */
export function SystemMapPanel({
  routing,
  secrets,
  onOpenSecrets,
}: {
  routing: DepartmentAssignment[];
  secrets: SecretsState;
  onOpenSecrets: () => void;
}) {
  return (
    <div className="space-y-4 pb-6">
      <div className="flex items-center justify-between">
        <div className="flex items-center gap-2 text-sm font-bold text-white">
          <Cpu className="w-4 h-4 text-cyan-400" />
          <span>Live AI Department & Infrastructure Map</span>
        </div>
        <button
          type="button"
          onClick={onOpenSecrets}
          className="px-3 py-1.5 rounded-lg bg-cyan-500/20 border border-cyan-400/40 text-xs font-semibold text-cyan-200"
        >
          Manage Keys
        </button>
      </div>

      <div className="grid grid-cols-1 sm:grid-cols-2 gap-2.5">
        {routing.map((dept) => (
          <div key={dept.department} className="p-3 rounded-xl bg-[#0b1120] border border-white/10 space-y-1">
            <div className="flex items-center justify-between text-xs">
              <span className="font-bold text-white">{dept.label}</span>
              <span className={dept.available ? 'text-emerald-400 font-medium' : 'text-amber-300'}>
                {dept.available ? dept.provider?.toUpperCase() : 'Missing Key'}
              </span>
            </div>
            <div className="text-xs font-mono text-cyan-300 truncate">
              {dept.available ? dept.model : dept.missingHint}
            </div>
          </div>
        ))}
      </div>

      <div className="p-4 rounded-2xl bg-[#0b1120] border border-white/10 space-y-2 text-xs">
        <div className="font-bold text-white">Zero-Server Direct Connections</div>
        <div className="flex justify-between">
          <span className="text-slate-400">GitHub REST API</span>
          <span className={secrets.github.connected ? 'text-emerald-400' : 'text-slate-500'}>
            {secrets.github.connected ? `Connected (@${secrets.github.verifiedLogin})` : 'Missing Username + PAT'}
          </span>
        </div>
        <div className="flex justify-between">
          <span className="text-slate-400">Studio Supabase (Studio Records)</span>
          <span className={secrets.studioSupabase.connected ? 'text-emerald-400' : 'text-slate-500'}>
            {secrets.studioSupabase.connected ? 'Connected & Auto-Syncing' : 'Local Storage Only'}
          </span>
        </div>
        <div className="flex justify-between">
          <span className="text-slate-400">Apps Supabase (Exported APKs + Admin)</span>
          <span className={secrets.appsSupabase.connected ? 'text-emerald-400' : 'text-slate-500'}>
            {secrets.appsSupabase.connected ? 'Ready for Injection' : 'Not Configured'}
          </span>
        </div>
      </div>
    </div>
  );
}
