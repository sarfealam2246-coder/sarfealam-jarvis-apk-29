import { useEffect, useRef } from 'react';
import * as THREE from 'three';
import { RoomEnvironment } from 'three/addons/environments/RoomEnvironment.js';
import { JarvisStatus } from '../types';

interface JarvisHologramProps {
  status: JarvisStatus;
  className?: string;
}

function detectSoftwareWebGL(): boolean {
  try {
    const gl = document.createElement('canvas').getContext('webgl2');
    if (!gl) return true;
    const ext = gl.getExtension('WEBGL_debug_renderer_info');
    const param = ext ? ext.UNMASKED_RENDERER_WEBGL : gl.RENDERER;
    const gpu = String(gl.getParameter(param));
    gl.getExtension('WEBGL_lose_context')?.loseContext();
    return /SwiftShader|llvmpipe|softpipe|Software|Basic Render/i.test(gpu);
  } catch {
    return true;
  }
}

export function JarvisHologram({ status, className = '' }: JarvisHologramProps) {
  const containerRef = useRef<HTMLDivElement | null>(null);
  const statusRef = useRef<JarvisStatus>(status);
  statusRef.current = status;

  useEffect(() => {
    const container = containerRef.current;
    if (!container) return;

    const isSoftwareGl = detectSoftwareWebGL();
    const width = Math.max(container.clientWidth, 128);
    const height = Math.max(container.clientHeight, 128);

    const scene = new THREE.Scene();
    const camera = new THREE.PerspectiveCamera(42, width / height, 0.1, 100);
    camera.position.set(0, 0.15, 4.4);

    let renderer: THREE.WebGLRenderer;
    try {
      renderer = new THREE.WebGLRenderer({
        antialias: !isSoftwareGl,
        alpha: true,
        powerPreference: 'high-performance',
      });
    } catch {
      return;
    }

    renderer.setSize(width, height);
    renderer.setPixelRatio(isSoftwareGl ? 1 : Math.min(window.devicePixelRatio, 2));
    renderer.outputColorSpace = THREE.SRGBColorSpace;
    renderer.toneMapping = THREE.ACESFilmicToneMapping;
    renderer.toneMappingExposure = 1.15;
    container.innerHTML = '';
    container.appendChild(renderer.domElement);

    const pmrem = new THREE.PMREMGenerator(renderer);
    const envTex = pmrem.fromScene(new RoomEnvironment(), 0.04).texture;
    scene.environment = envTex;
    pmrem.dispose();

    // Lighting rig
    const keyLight = new THREE.DirectionalLight(0x38bdf8, 2.2);
    keyLight.position.set(3, 4, 4);
    scene.add(keyLight);

    const rimLight = new THREE.DirectionalLight(0x8b5cf6, 1.6);
    rimLight.position.set(-4, -2, -3);
    scene.add(rimLight);

    const hemi = new THREE.HemisphereLight(0x06b6d4, 0x0f172a, 0.9);
    scene.add(hemi);

    // Composite JARVIS Hologram Assembly
    const rig = new THREE.Group();
    scene.add(rig);

    const coreGeo = new THREE.IcosahedronGeometry(0.68, 2);
    const coreMat = new THREE.MeshPhysicalMaterial({
      color: 0x06b6d4,
      emissive: 0x0891b2,
      emissiveIntensity: 0.7,
      metalness: 0.85,
      roughness: 0.18,
      clearcoat: 1.0,
    });
    const coreMesh = new THREE.Mesh(coreGeo, coreMat);
    rig.add(coreMesh);

    const shellGeo = new THREE.IcosahedronGeometry(0.96, 1);
    const shellMat = new THREE.MeshBasicMaterial({
      color: 0x38bdf8,
      wireframe: true,
      transparent: true,
      opacity: 0.42,
    });
    const shellMesh = new THREE.Mesh(shellGeo, shellMat);
    rig.add(shellMesh);

    const ringGeo1 = new THREE.TorusGeometry(1.24, 0.025, 16, 64);
    const ringMat1 = new THREE.MeshStandardMaterial({
      color: 0x06b6d4,
      emissive: 0x06b6d4,
      emissiveIntensity: 0.65,
      metalness: 0.9,
      roughness: 0.15,
    });
    const ring1 = new THREE.Mesh(ringGeo1, ringMat1);
    ring1.rotation.x = Math.PI / 2.6;
    rig.add(ring1);

    const ringGeo2 = new THREE.TorusGeometry(1.48, 0.018, 12, 64);
    const ringMat2 = new THREE.MeshStandardMaterial({
      color: 0x8b5cf6,
      emissive: 0x8b5cf6,
      emissiveIntensity: 0.55,
      metalness: 0.85,
      roughness: 0.2,
    });
    const ring2 = new THREE.Mesh(ringGeo2, ringMat2);
    ring2.rotation.y = Math.PI / 3;
    rig.add(ring2);

    // Orbital particle ring
    const particleCount = 72;
    const posArr = new Float32Array(particleCount * 3);
    for (let i = 0; i < particleCount; i++) {
      const a = (i / particleCount) * Math.PI * 2;
      const r = 1.6 + (i % 3) * 0.12;
      posArr[i * 3] = Math.cos(a) * r;
      posArr[i * 3 + 1] = Math.sin(a * 3) * 0.25;
      posArr[i * 3 + 2] = Math.sin(a) * r;
    }
    const ptsGeo = new THREE.BufferGeometry();
    ptsGeo.setAttribute('position', new THREE.BufferAttribute(posArr, 3));
    const ptsMat = new THREE.PointsMaterial({
      color: 0x22d3ee,
      size: 0.05,
      transparent: true,
      opacity: 0.85,
    });
    const particles = new THREE.Points(ptsGeo, ptsMat);
    rig.add(particles);

    const colorCyan = new THREE.Color(0x06b6d4);
    const colorEmerald = new THREE.Color(0x10b981);
    const colorPurple = new THREE.Color(0x8b5cf6);
    const colorAmber = new THREE.Color(0xf59e0b);
    const targetColor = new THREE.Color(0x06b6d4);

    let disposed = false;
    let frameId = 0;
    const clock = new THREE.Clock();

    const afterDraw = (cb: () => void) => {
      const gl = renderer.getContext() as WebGL2RenderingContext;
      const sync = gl.fenceSync?.(gl.SYNC_GPU_COMMANDS_COMPLETE, 0);
      gl.flush();
      const poll = () => {
        if (disposed) return;
        const state = sync && gl.getSyncParameter(sync, gl.SYNC_STATUS);
        if (state === gl.UNSIGNALED) {
          frameId = window.setTimeout(poll, 5);
        } else {
          if (sync) gl.deleteSync(sync);
          frameId = window.setTimeout(cb, 80);
        }
      };
      frameId = window.setTimeout(poll, 5);
    };

    const tick = () => {
      if (disposed) return;
      const delta = Math.min(clock.getDelta(), 0.1);
      const elapsed = clock.getElapsedTime();
      const st = statusRef.current;

      let speed = 0.65;
      let scaleTarget = 1.0;

      if (st === 'listening') {
        targetColor.copy(colorEmerald);
        speed = 1.15;
        scaleTarget = 1.05 + Math.sin(elapsed * 5) * 0.04;
      } else if (st === 'thinking') {
        targetColor.copy(colorPurple);
        speed = 2.1;
        scaleTarget = 0.96 + Math.sin(elapsed * 7) * 0.05;
      } else if (st === 'working') {
        targetColor.copy(colorAmber);
        speed = 2.6;
        scaleTarget = 1.04 + Math.sin(elapsed * 8) * 0.05;
      } else if (st === 'speaking') {
        targetColor.copy(colorCyan);
        speed = 1.6;
        scaleTarget = 1.0 + Math.abs(Math.sin(elapsed * 9.5)) * 0.14;
      } else {
        targetColor.copy(colorCyan);
        speed = 0.6;
        scaleTarget = 1.0 + Math.sin(elapsed * 2) * 0.025;
      }

      coreMat.color.lerp(targetColor, Math.min(1, delta * 5));
      coreMat.emissive.lerp(targetColor, Math.min(1, delta * 5));
      shellMat.color.lerp(targetColor, Math.min(1, delta * 5));

      const s = THREE.MathUtils.damp(coreMesh.scale.x, scaleTarget, 8, delta);
      coreMesh.scale.setScalar(s);

      coreMesh.rotation.y += delta * 0.8 * speed;
      coreMesh.rotation.x += delta * 0.4 * speed;
      shellMesh.rotation.y -= delta * 0.55 * speed;
      shellMesh.rotation.z += delta * 0.3 * speed;

      ring1.rotation.z += delta * 1.1 * speed;
      ring1.rotation.x = Math.PI / 2.6 + Math.sin(elapsed * 1.4) * 0.25;
      ring2.rotation.y -= delta * 0.9 * speed;
      ring2.rotation.x += delta * 0.4 * speed;
      particles.rotation.y += delta * 0.45 * speed;

      renderer.render(scene, camera);
      if (isSoftwareGl) {
        afterDraw(tick);
      } else {
        frameId = requestAnimationFrame(tick);
      }
    };

    const onResize = () => {
      if (!container || disposed) return;
      const w = Math.max(container.clientWidth, 100);
      const h = Math.max(container.clientHeight, 100);
      camera.aspect = w / h;
      camera.updateProjectionMatrix();
      renderer.setSize(w, h);
    };

    const ro = new ResizeObserver(onResize);
    ro.observe(container);
    tick();

    return () => {
      disposed = true;
      cancelAnimationFrame(frameId);
      clearTimeout(frameId);
      ro.disconnect();
      coreGeo.dispose();
      coreMat.dispose();
      shellGeo.dispose();
      shellMat.dispose();
      ringGeo1.dispose();
      ringMat1.dispose();
      ringGeo2.dispose();
      ringMat2.dispose();
      ptsGeo.dispose();
      ptsMat.dispose();
      envTex.dispose();
      renderer.dispose();
    };
  }, []);

  return (
    <div
      ref={containerRef}
      className={`relative w-full h-full select-none ${className}`}
      aria-label="JARVIS 3D Hologram Avatar"
    />
  );
}
