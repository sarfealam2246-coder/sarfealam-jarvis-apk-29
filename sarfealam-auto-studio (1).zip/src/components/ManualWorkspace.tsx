import { FormEvent, useState } from 'react';
import {
  Bot,
  Eye,
  Hammer,
  Image as ImageIcon,
  RotateCcw,
  Send,
  Sparkles,
  Wrench,
} from 'lucide-react';
import {
  ChatMessage,
  Checkpoint,
  CoreSkillToggles,
  DepartmentAssignment,
  DesignBlueprint,
  DynamicSkill,
  GeneratedFile,
  Language,
  ManualTab,
  RemoteAdminConfig,
  SecretsState,
  TargetEngine,
  VaultBuild,
  WorkflowTemplates,
} from '../types';
import { t } from '../services/i18n';
import { SecretsPanel } from './SecretsPanel';
import {
  AdminPanel,
  CodeExplorerPanel,
  SkillsPanel,
  VaultPanel,
} from './StudioPanels';

interface ManualWorkspaceProps {
  lang: Language;
  activeTab: ManualTab;
  onChangeTab: (tab: ManualTab) => void;
  onSummonJarvis: () => void;
  // Co-Pilot & Build
  messages: ChatMessage[];
  blueprint: DesignBlueprint | null;
  buildStage: number;
  isBuilding: boolean;
  files: GeneratedFile[];
  checkpoints: Checkpoint[];
  onSendPrompt: (text: string) => void;
  onStartDesign: (prompt: string, engine: 'auto' | TargetEngine) => void;
  onStartBuild: () => void;
  onHotPatch: (instruction: string) => void;
  onGenerateImage: (prompt: string) => void;
  onRunVisionQa: () => void;
  onRollback: () => void;
  // Vault / Admin / Skills / Secrets
  builds: VaultBuild[];
  secrets: SecretsState;
  routing: DepartmentAssignment[];
  adminConfig: RemoteAdminConfig;
  coreToggles: CoreSkillToggles;
  workflows: WorkflowTemplates;
  dynamicSkills: DynamicSkill[];
  onSaveSecrets: (next: SecretsState, announce: boolean) => void;
  onRestoreFromStudioSupabase: () => void;
  onUpdateBuild: (id: string, patch: Partial<VaultBuild>) => void;
  onRestoreCheckpoint: (cp: Checkpoint) => void;
  onChangeAdminConfig: (next: RemoteAdminConfig) => void;
  onChangeToggles: (next: CoreSkillToggles) => void;
  onChangeWorkflows: (next: WorkflowTemplates) => void;
  onAddDynamicSkill: (sk: DynamicSkill) => void;
  onToggleDynamicSkill: (id: string) => void;
}

export function ManualWorkspace(props: ManualWorkspaceProps) {
  const { lang, activeTab, onChangeTab, onSummonJarvis } = props;
  const [chatInput, setChatInput] = useState('');
  const [buildPrompt, setBuildPrompt] = useState(props.blueprint?.prompt || '');
  const [engineChoice, setEngineChoice] = useState<'auto' | TargetEngine>('auto');
  const [patchInput, setPatchInput] = useState('');
  const [imagePrompt, setImagePrompt] = useState('');

  const tabs: Array<{ id: ManualTab; label: string }> = [
    { id: 'copilot', label: t(lang, 'tabCopilot') },
    { id: 'build', label: t(lang, 'tabBuild') },
    { id: 'vault', label: t(lang, 'tabVault') },
    { id: 'admin', label: t(lang, 'tabAdmin') },
    { id: 'skills', label: t(lang, 'tabSkills') },
    { id: 'secrets', label: t(lang, 'tabSecrets') },
  ];

  const handleChatSubmit = (e: FormEvent) => {
    e.preventDefault();
    if (!chatInput.trim()) return;
    props.onSendPrompt(chatInput.trim());
    setChatInput('');
  };

  return (
    <section className="rounded-2xl bg-[#0b1120] border border-white/10 flex flex-col overflow-hidden lg:h-[calc(100vh-148px)]">
      {/* 6 Clean Manual Tabs */}
      <div className="flex items-center gap-1 p-2 bg-[#070b14] border-b border-white/10 overflow-x-auto">
        {tabs.map((tab) => (
          <button
            key={tab.id}
            type="button"
            onClick={() => onChangeTab(tab.id)}
            className={`px-3 py-2 min-h-[38px] rounded-xl text-xs font-semibold whitespace-nowrap shrink-0 transition-colors ${
              activeTab === tab.id
                ? 'bg-cyan-500 text-slate-950'
                : 'text-slate-400 hover:text-white hover:bg-white/5'
            }`}
          >
            {tab.label}
          </button>
        ))}
      </div>

      {/* Active Tab Content */}
      <div className="flex-1 overflow-y-auto p-3 sm:p-4">
        {activeTab === 'copilot' && (
          <div className="flex flex-col h-full min-h-[320px] gap-3">
            <div className="flex-1 overflow-y-auto space-y-2 pr-1">
              {props.messages.map((m) => (
                <div
                  key={m.id}
                  className={`p-3 rounded-xl text-xs leading-relaxed ${
                    m.role === 'user'
                      ? 'bg-cyan-500/15 border border-cyan-500/30 text-white ml-6'
                      : 'bg-[#070b14] border border-white/10 text-slate-200 mr-4'
                  }`}
                >
                  <div className="text-[10px] text-slate-400 mb-0.5 flex justify-between">
                    <span>{m.role === 'user' ? 'You' : 'Co-Pilot'}</span>
                    {m.modelUsed && <span className="font-mono">{m.modelUsed}</span>}
                  </div>
                  <div className="whitespace-pre-wrap">{m.text}</div>
                </div>
              ))}
            </div>
            <form onSubmit={handleChatSubmit} className="flex gap-2 pt-2 border-t border-white/10">
              <input
                value={chatInput}
                onChange={(e) => setChatInput(e.target.value)}
                placeholder={t(lang, 'askPlaceholder')}
                className="flex-1 min-h-[44px] px-3 rounded-xl bg-[#070b14] border border-white/10 text-xs text-white focus:outline-none"
              />
              <button
                type="submit"
                className="px-4 min-h-[44px] rounded-xl bg-cyan-500 text-slate-950 text-xs font-bold flex items-center gap-1"
              >
                <Send className="w-3.5 h-3.5" />
                <span>{t(lang, 'send')}</span>
              </button>
            </form>
          </div>
        )}

        {activeTab === 'build' && (
          <div className="space-y-4 pb-6">
            <div className="p-4 rounded-2xl bg-[#070b14] border border-white/10 space-y-3">
              <div className="flex items-center gap-2 text-sm font-bold text-white">
                <Hammer className="w-4 h-4 text-cyan-400" />
                <span>Manual Design & 5-Stage Factory</span>
              </div>

              <div className="space-y-1">
                <label className="text-[11px] text-slate-300">App or 3D Game Specification</label>
                <textarea
                  rows={3}
                  value={buildPrompt}
                  onChange={(e) => setBuildPrompt(e.target.value)}
                  placeholder="Describe your 3D PBR game, e-commerce store, Khata POS, ride booking, or card table..."
                  className="w-full p-3 rounded-xl bg-[#0b1120] border border-white/10 text-xs text-white focus:outline-none focus:border-cyan-400/60"
                />
              </div>

              <div className="grid grid-cols-1 sm:grid-cols-2 gap-2.5">
                <div className="space-y-1">
                  <label className="text-[11px] text-slate-300">Target Export Engine</label>
                  <select
                    value={engineChoice}
                    onChange={(e) => setEngineChoice(e.target.value as 'auto' | TargetEngine)}
                    className="w-full min-h-[42px] px-3 rounded-xl bg-[#0b1120] border border-white/10 text-xs text-white focus:outline-none"
                  >
                    <option value="auto">Auto-Select (Flutter Apps / Godot 4 3D)</option>
                    <option value="godot4">Godot 4 Mobile Vulkan (3D Games)</option>
                    <option value="flutter">Flutter Android APK (Commercial Apps)</option>
                  </select>
                </div>

                <div className="flex items-end gap-2">
                  <button
                    type="button"
                    onClick={() => props.onStartDesign(buildPrompt || '3D Golden Highway Sports Car Racer', engineChoice)}
                    className="flex-1 min-h-[42px] px-3 rounded-xl bg-cyan-500 text-slate-950 text-xs font-bold"
                  >
                    1. Design Preview
                  </button>
                  <button
                    type="button"
                    onClick={props.onStartBuild}
                    disabled={!props.blueprint || props.isBuilding}
                    className="flex-1 min-h-[42px] px-3 rounded-xl bg-emerald-500 text-slate-950 text-xs font-bold disabled:opacity-40"
                  >
                    2. Build (5 Stages)
                  </button>
                </div>
              </div>
            </div>

            {/* Live Hot-Patcher + Vision QA + Rollback */}
            <div className="p-4 rounded-2xl bg-[#070b14] border border-white/10 space-y-3">
              <div className="flex items-center gap-2 text-sm font-bold text-white">
                <Wrench className="w-4 h-4 text-purple-400" />
                <span>Live Hot-Patch & Vision Self-Heal</span>
              </div>
              <div className="flex gap-2">
                <input
                  value={patchInput}
                  onChange={(e) => setPatchInput(e.target.value)}
                  placeholder="e.g. switch to night neon city, paint car cyan, boost speed, unlock VIP, 25% discount"
                  className="flex-1 min-h-[42px] px-3 rounded-xl bg-[#0b1120] border border-white/10 text-xs text-white focus:outline-none"
                />
                <button
                  type="button"
                  onClick={() => {
                    if (patchInput.trim()) {
                      props.onHotPatch(patchInput.trim());
                      setPatchInput('');
                    }
                  }}
                  className="px-4 min-h-[42px] rounded-xl bg-purple-500 text-white text-xs font-bold shrink-0"
                >
                  Hot-Patch
                </button>
              </div>
              <div className="flex flex-wrap gap-2">
                <button
                  type="button"
                  onClick={props.onRunVisionQa}
                  className="px-3 py-2 min-h-[38px] rounded-xl bg-[#0b1120] border border-purple-400/40 text-xs text-purple-200 flex items-center gap-1.5"
                >
                  <Eye className="w-3.5 h-3.5" />
                  <span>Run Vision QA Snapshot</span>
                </button>
                <button
                  type="button"
                  onClick={props.onRollback}
                  disabled={props.checkpoints.length === 0}
                  className="px-3 py-2 min-h-[38px] rounded-xl bg-[#0b1120] border border-white/10 text-xs text-slate-200 flex items-center gap-1.5 disabled:opacity-40"
                >
                  <RotateCcw className="w-3.5 h-3.5" />
                  <span>1s Rollback ({props.checkpoints.length})</span>
                </button>
              </div>
            </div>

            {/* Gemini Image Generator */}
            <div className="p-4 rounded-2xl bg-[#070b14] border border-white/10 space-y-2.5">
              <div className="flex items-center gap-2 text-sm font-bold text-white">
                <ImageIcon className="w-4 h-4 text-emerald-400" />
                <span>Gemini Image Generator (Icon / Banner / Texture)</span>
              </div>
              <div className="flex gap-2">
                <input
                  value={imagePrompt}
                  onChange={(e) => setImagePrompt(e.target.value)}
                  placeholder="Describe an app icon, store banner, or racing billboard texture..."
                  className="flex-1 min-h-[42px] px-3 rounded-xl bg-[#0b1120] border border-white/10 text-xs text-white focus:outline-none"
                />
                <button
                  type="button"
                  onClick={() => {
                    if (imagePrompt.trim()) {
                      props.onGenerateImage(imagePrompt.trim());
                      setImagePrompt('');
                    }
                  }}
                  className="px-4 min-h-[42px] rounded-xl bg-emerald-500 text-slate-950 text-xs font-bold flex items-center gap-1 shrink-0"
                >
                  <Sparkles className="w-3.5 h-3.5" />
                  <span>Generate</span>
                </button>
              </div>
            </div>

            {/* Live Generated Code Preview */}
            <CodeExplorerPanel files={props.files} />
          </div>
        )}

        {activeTab === 'vault' && (
          <VaultPanel
            lang={lang}
            builds={props.builds}
            checkpoints={props.checkpoints}
            secrets={props.secrets}
            onUpdateBuild={props.onUpdateBuild}
            onRestoreCheckpoint={props.onRestoreCheckpoint}
          />
        )}

        {activeTab === 'admin' && (
          <AdminPanel
            secrets={props.secrets}
            adminConfig={props.adminConfig}
            latestBuild={props.builds[0]}
            onChangeConfig={props.onChangeAdminConfig}
          />
        )}

        {activeTab === 'skills' && (
          <SkillsPanel
            coreToggles={props.coreToggles}
            workflows={props.workflows}
            dynamicSkills={props.dynamicSkills}
            onChangeToggles={props.onChangeToggles}
            onChangeWorkflows={props.onChangeWorkflows}
            onAddDynamicSkill={props.onAddDynamicSkill}
            onToggleDynamicSkill={props.onToggleDynamicSkill}
          />
        )}

        {activeTab === 'secrets' && (
          <SecretsPanel
            lang={lang}
            secrets={props.secrets}
            routing={props.routing}
            onSaveSecrets={props.onSaveSecrets}
            onRestoreFromStudioSupabase={props.onRestoreFromStudioSupabase}
          />
        )}
      </div>

      {/* Collapsed JARVIS Corner Pill in Manual Mode */}
      <button
        type="button"
        onClick={onSummonJarvis}
        className="fixed bottom-20 right-4 z-30 px-3.5 py-2 min-h-[42px] rounded-full bg-[#0b1120] border border-cyan-400/60 shadow-lg shadow-cyan-950/60 text-xs font-semibold text-cyan-200 hover:bg-cyan-950/60 flex items-center gap-2 transition-colors"
      >
        <Bot className="w-4 h-4 text-cyan-400" />
        <span>{t(lang, 'jarvisCollapsedPill')}</span>
      </button>
    </section>
  );
}
