import { forwardRef, useEffect, useImperativeHandle, useRef, useState } from 'react';
import * as THREE from 'three';
import { OrbitControls } from 'three/addons/controls/OrbitControls.js';
import { RoomEnvironment } from 'three/addons/environments/RoomEnvironment.js';
import { Sky } from 'three/addons/objects/Sky.js';
import { Game3DConfig } from '../types';

export interface ThreeGameViewportHandle {
  captureSnapshot: () => string | null;
}

interface ThreeGameViewportProps {
  config: Game3DConfig;
  buildStage: number; // 1..5 progressive assembly
  title: string;
}

function detectSoftwareWebGL(): boolean {
  try {
    const gl = document.createElement('canvas').getContext('webgl2');
    if (!gl) return true;
    const ext = gl.getExtension('WEBGL_debug_renderer_info');
    const param = ext ? ext.UNMASKED_RENDERER_WEBGL : gl.RENDERER;
    const gpu = String(gl.getParameter(param));
    gl.getExtension('WEBGL_lose_context')?.loseContext();
    return /SwiftShader|llvmpipe|softpipe|Software|Basic Render/i.test(gpu);
  } catch {
    return true;
  }
}

function createAsphaltTexture(maxAniso: number, isNight: boolean): THREE.CanvasTexture {
  const canvas = document.createElement('canvas');
  canvas.width = 512;
  canvas.height = 512;
  const ctx = canvas.getContext('2d')!;
  ctx.fillStyle = isNight ? '#151923' : '#252932';
  ctx.fillRect(0, 0, 512, 512);

  // Subtle asphalt grain
  for (let i = 0; i < 6500; i++) {
    const x = Math.random() * 512;
    const y = Math.random() * 512;
    const v = 22 + Math.floor(Math.random() * 28);
    ctx.fillStyle = `rgb(${v},${v + 2},${v + 6})`;
    ctx.fillRect(x, y, 2, 2);
  }

  // Shoulder stripes
  ctx.fillStyle = isNight ? '#06b6d4' : '#f8fafc';
  ctx.fillRect(28, 0, 8, 512);
  ctx.fillRect(476, 0, 8, 512);

  // Center dashed lane dividers
  ctx.fillStyle = '#f59e0b';
  for (let y = 16; y < 512; y += 96) {
    ctx.fillRect(251, y, 10, 52);
  }

  const tex = new THREE.CanvasTexture(canvas);
  tex.colorSpace = THREE.SRGBColorSpace;
  tex.wrapS = THREE.RepeatWrapping;
  tex.wrapT = THREE.RepeatWrapping;
  tex.repeat.set(1, 32);
  tex.anisotropy = maxAniso;
  return tex;
}

function createTerrainTexture(theme: Game3DConfig['theme'], maxAniso: number): THREE.CanvasTexture {
  const canvas = document.createElement('canvas');
  canvas.width = 256;
  canvas.height = 256;
  const ctx = canvas.getContext('2d')!;
  const base =
    theme === 'tactical_basecamp'
      ? '#4b4534'
      : theme === 'neon_city'
      ? '#121826'
      : theme === 'alpine_rally'
      ? '#344c3d'
      : '#3b4b31';
  ctx.fillStyle = base;
  ctx.fillRect(0, 0, 256, 256);

  for (let i = 0; i < 3200; i++) {
    const x = Math.random() * 256;
    const y = Math.random() * 256;
    ctx.fillStyle = i % 2 === 0 ? 'rgba(255,255,255,0.045)' : 'rgba(0,0,0,0.08)';
    ctx.fillRect(x, y, 3, 3);
  }

  const tex = new THREE.CanvasTexture(canvas);
  tex.colorSpace = THREE.SRGBColorSpace;
  tex.wrapS = THREE.RepeatWrapping;
  tex.wrapT = THREE.RepeatWrapping;
  tex.repeat.set(42, 42);
  tex.anisotropy = maxAniso;
  return tex;
}

function createContactShadowTexture(): THREE.CanvasTexture {
  const canvas = document.createElement('canvas');
  canvas.width = 128;
  canvas.height = 128;
  const ctx = canvas.getContext('2d')!;
  const grad = ctx.createRadialGradient(64, 64, 12, 64, 64, 60);
  grad.addColorStop(0, 'rgba(0,0,0,0.68)');
  grad.addColorStop(0.65, 'rgba(0,0,0,0.28)');
  grad.addColorStop(1, 'rgba(0,0,0,0)');
  ctx.fillStyle = grad;
  ctx.fillRect(0, 0, 128, 128);
  const tex = new THREE.CanvasTexture(canvas);
  return tex;
}

function buildCompositeVehicle(config: Game3DConfig): {
  group: THREE.Group;
  wheels: THREE.Mesh[];
  bodyMat: THREE.MeshPhysicalMaterial;
  tailLightMat: THREE.MeshStandardMaterial;
} {
  const group = new THREE.Group();
  const wheels: THREE.Mesh[] = [];
  const isJeep = config.vehicleType === 'tactical_jeep';

  const bodyMat = new THREE.MeshPhysicalMaterial({
    color: new THREE.Color(config.primaryColor),
    metalness: isJeep ? 0.35 : 0.82,
    roughness: isJeep ? 0.55 : 0.18,
    clearcoat: isJeep ? 0.15 : 1.0,
    clearcoatRoughness: 0.12,
  });

  const trimMat = new THREE.MeshStandardMaterial({
    color: 0x111827,
    metalness: 0.4,
    roughness: 0.72,
  });

  const glassMat = new THREE.MeshPhysicalMaterial({
    color: 0x0f172a,
    metalness: 0.9,
    roughness: 0.08,
    clearcoat: 1.0,
  });

  const chromeMat = new THREE.MeshStandardMaterial({
    color: 0xe2e8f0,
    metalness: 0.96,
    roughness: 0.12,
  });

  const headLightMat = new THREE.MeshStandardMaterial({
    color: 0xffffff,
    emissive: 0xfff7ed,
    emissiveIntensity: 2.8,
  });

  const tailLightMat = new THREE.MeshStandardMaterial({
    color: 0xef4444,
    emissive: 0xef4444,
    emissiveIntensity: 1.8,
  });

  const tireMat = new THREE.MeshStandardMaterial({
    color: 0x18181b,
    metalness: 0.08,
    roughness: 0.88,
  });

  // 1. Lower Chassis / Floorpan
  const chassis = new THREE.Mesh(
    new THREE.BoxGeometry(2.08, 0.36, isJeep ? 4.45 : 4.75),
    trimMat
  );
  chassis.position.set(0, 0.46, 0);
  chassis.castShadow = true;
  chassis.receiveShadow = true;
  group.add(chassis);

  // 2. Sculpted Main Body
  const mainBody = new THREE.Mesh(
    new THREE.BoxGeometry(2.02, isJeep ? 0.68 : 0.52, isJeep ? 4.35 : 4.65),
    bodyMat
  );
  mainBody.position.set(0, isJeep ? 0.92 : 0.78, 0);
  mainBody.castShadow = true;
  mainBody.receiveShadow = true;
  group.add(mainBody);

  // 3. Cabin / Roof Silhouette
  const cabin = new THREE.Mesh(
    new THREE.BoxGeometry(1.74, isJeep ? 0.78 : 0.54, isJeep ? 2.35 : 2.15),
    bodyMat
  );
  cabin.position.set(0, isJeep ? 1.56 : 1.24, isJeep ? 0.18 : 0.15);
  cabin.castShadow = true;
  group.add(cabin);

  // 4. Windshield + Rear Glass
  const windshield = new THREE.Mesh(
    new THREE.BoxGeometry(1.66, isJeep ? 0.6 : 0.42, 2.22),
    glassMat
  );
  windshield.position.set(0, isJeep ? 1.52 : 1.22, isJeep ? 0.18 : 0.15);
  group.add(windshield);

  // 5. Front Hood Intake / Accent Strip
  const accentMat = new THREE.MeshStandardMaterial({
    color: new THREE.Color(config.accentColor),
    metalness: 0.6,
    roughness: 0.3,
  });
  const hoodStripe = new THREE.Mesh(new THREE.BoxGeometry(0.46, 0.05, 1.55), accentMat);
  hoodStripe.position.set(0, isJeep ? 1.28 : 1.06, -1.25);
  group.add(hoodStripe);

  // 6. Front & Rear Bumpers / Diffuser
  const frontBumper = new THREE.Mesh(new THREE.BoxGeometry(2.12, 0.24, 0.28), trimMat);
  frontBumper.position.set(0, 0.44, -2.32);
  group.add(frontBumper);

  const rearDiffuser = new THREE.Mesh(new THREE.BoxGeometry(2.08, 0.28, 0.3), trimMat);
  rearDiffuser.position.set(0, 0.44, 2.32);
  group.add(rearDiffuser);

  // 7. Rear Aero Wing (Sports/Cyber) or Roll Cage / Spare Tire (Jeep)
  if (isJeep) {
    const spareTire = new THREE.Mesh(new THREE.CylinderGeometry(0.42, 0.42, 0.24, 20), tireMat);
    spareTire.rotation.x = Math.PI / 2;
    spareTire.position.set(0, 1.08, 2.28);
    group.add(spareTire);
  } else {
    const wingBlade = new THREE.Mesh(new THREE.BoxGeometry(1.94, 0.07, 0.34), trimMat);
    wingBlade.position.set(0, 1.38, 2.08);
    wingBlade.castShadow = true;
    group.add(wingBlade);

    for (const x of [-0.62, 0.62]) {
      const pylon = new THREE.Mesh(new THREE.BoxGeometry(0.08, 0.34, 0.22), trimMat);
      pylon.position.set(x, 1.18, 2.08);
      group.add(pylon);
    }
  }

  // 8. Dual Headlights & Taillights
  for (const x of [-0.68, 0.68]) {
    const hl = new THREE.Mesh(new THREE.BoxGeometry(0.42, 0.14, 0.1), headLightMat);
    hl.position.set(x, isJeep ? 0.96 : 0.84, -2.31);
    group.add(hl);

    const tl = new THREE.Mesh(new THREE.BoxGeometry(0.48, 0.14, 0.1), tailLightMat);
    tl.position.set(x, isJeep ? 0.96 : 0.86, 2.31);
    group.add(tl);
  }

  // 9. Twin Exhaust Pipes
  for (const x of [-0.46, 0.46]) {
    const pipe = new THREE.Mesh(new THREE.CylinderGeometry(0.07, 0.07, 0.24, 12), chromeMat);
    pipe.rotation.x = Math.PI / 2;
    pipe.position.set(x, 0.36, 2.44);
    group.add(pipe);
  }

  // 10. Four Composite Wheels (Tire + Metallic Rim) grounded cleanly at Y=0
  const wheelRadius = isJeep ? 0.46 : 0.38;
  const wheelGeo = new THREE.CylinderGeometry(wheelRadius, wheelRadius, 0.3, 24);
  wheelGeo.rotateZ(Math.PI / 2);
  const rimGeo = new THREE.CylinderGeometry(wheelRadius * 0.6, wheelRadius * 0.6, 0.32, 16);
  rimGeo.rotateZ(Math.PI / 2);

  const wheelPositions: Array<[number, number, number]> = [
    [-1.04, wheelRadius, -1.42],
    [1.04, wheelRadius, -1.42],
    [-1.04, wheelRadius, 1.42],
    [1.04, wheelRadius, 1.42],
  ];

  for (const [wx, wy, wz] of wheelPositions) {
    const wheelMesh = new THREE.Mesh(wheelGeo, tireMat);
    wheelMesh.position.set(wx, wy, wz);
    wheelMesh.castShadow = true;
    const rim = new THREE.Mesh(rimGeo, chromeMat);
    wheelMesh.add(rim);
    group.add(wheelMesh);
    wheels.push(wheelMesh);
  }

  // 11. Soft Contact Shadow Plane grounded at Y=0.03
  const contactShadow = new THREE.Mesh(
    new THREE.PlaneGeometry(3.2, 5.8),
    new THREE.MeshBasicMaterial({
      map: createContactShadowTexture(),
      transparent: true,
      depthWrite: false,
      opacity: 0.72,
    })
  );
  contactShadow.rotation.x = -Math.PI / 2;
  contactShadow.position.y = 0.03;
  group.add(contactShadow);

  return { group, wheels, bodyMat, tailLightMat };
}

export const ThreeGameViewport = forwardRef<ThreeGameViewportHandle, ThreeGameViewportProps>(
  function ThreeGameViewport({ config, buildStage, title }, ref) {
    const mountRef = useRef<HTMLDivElement | null>(null);
    const rendererRef = useRef<THREE.WebGLRenderer | null>(null);
    const sceneRef = useRef<THREE.Scene | null>(null);
    const cameraRef = useRef<THREE.PerspectiveCamera | null>(null);

    const [speedKmh, setSpeedKmh] = useState(0);
    const [cameraMode, setCameraMode] = useState<'chase' | 'orbit'>('chase');
    const [steerVisual, setSteerVisual] = useState(0);

    // Controls refs (mutated by touch-drag, virtual pedals, and keyboard without React re-renders)
    const inputRef = useRef({
      steer: 0, // -1..1
      gas: false,
      brake: false,
      dragging: false,
      dragStartX: 0,
      cameraMode: 'chase' as 'chase' | 'orbit',
    });
    inputRef.current.cameraMode = cameraMode;

    const configRef = useRef(config);
    configRef.current = config;

    const stageRef = useRef(buildStage);
    stageRef.current = buildStage;

    useImperativeHandle(ref, () => ({
      captureSnapshot: () => {
        const renderer = rendererRef.current;
        const scene = sceneRef.current;
        const camera = cameraRef.current;
        if (!renderer || !scene || !camera) return null;
        try {
          renderer.render(scene, camera);
          return renderer.domElement.toDataURL('image/jpeg', 0.8);
        } catch {
          return null;
        }
      },
    }));

    useEffect(() => {
      const container = mountRef.current;
      if (!container) return;

      const isSoftwareGl = detectSoftwareWebGL();
      const width = Math.max(container.clientWidth, 320);
      const height = Math.max(container.clientHeight, 260);

      const scene = new THREE.Scene();
      sceneRef.current = scene;

      const isNight = config.timeOfDay === 'night';
      const fogColor = isNight ? 0x090e1a : config.timeOfDay === 'noon' ? 0x9ec5e8 : 0xd99b66;
      scene.background = new THREE.Color(fogColor);
      scene.fog = new THREE.FogExp2(fogColor, config.fogDensity || 0.0038);

      const camera = new THREE.PerspectiveCamera(60, width / height, 0.1, 600);
      camera.position.set(0, 4.4, 9.2);
      cameraRef.current = camera;

      let renderer: THREE.WebGLRenderer;
      try {
        renderer = new THREE.WebGLRenderer({
          antialias: !isSoftwareGl,
          powerPreference: 'high-performance',
          preserveDrawingBuffer: true,
        });
      } catch {
        return;
      }
      rendererRef.current = renderer;

      renderer.setSize(width, height);
      renderer.setPixelRatio(isSoftwareGl ? 1 : Math.min(window.devicePixelRatio, 2));
      renderer.outputColorSpace = THREE.SRGBColorSpace;
      renderer.toneMapping = THREE.ACESFilmicToneMapping;
      renderer.toneMappingExposure = isNight ? 0.95 : 1.08;
      renderer.shadowMap.enabled = !isSoftwareGl;
      renderer.shadowMap.type = THREE.PCFSoftShadowMap;

      container.innerHTML = '';
      container.appendChild(renderer.domElement);

      // Studio / outdoor environment reflection map
      const pmrem = new THREE.PMREMGenerator(renderer);
      const envTex = pmrem.fromScene(new RoomEnvironment(), 0.04).texture;
      scene.environment = envTex;
      pmrem.dispose();

      // Golden-hour Sky shader
      const sky = new Sky();
      sky.scale.setScalar(4500);
      scene.add(sky);
      const skyUniforms = sky.material.uniforms;
      skyUniforms['turbidity'].value = isNight ? 2 : 8;
      skyUniforms['rayleigh'].value = isNight ? 0.2 : config.timeOfDay === 'golden' ? 2.6 : 1.1;
      skyUniforms['mieCoefficient'].value = 0.005;
      skyUniforms['mieDirectionalG'].value = 0.82;
      const sunVec = new THREE.Vector3();
      const elevation = isNight ? -3 : config.timeOfDay === 'golden' ? 8 : 42;
      const phi = THREE.MathUtils.degToRad(90 - elevation);
      const theta = THREE.MathUtils.degToRad(155);
      sunVec.setFromSphericalCoords(1, phi, theta);
      skyUniforms['sunPosition'].value.copy(sunVec);

      // Balanced 3-point outdoor lighting
      const sunLight = new THREE.DirectionalLight(
        isNight ? 0x60a5fa : config.timeOfDay === 'golden' ? 0xffd2a1 : 0xfffbeb,
        isNight ? 0.85 : 2.4
      );
      sunLight.position.set(sunVec.x * 60, Math.max(18, sunVec.y * 60), sunVec.z * 60);
      sunLight.castShadow = !isSoftwareGl;
      sunLight.shadow.mapSize.set(1024, 1024);
      sunLight.shadow.camera.near = 1;
      sunLight.shadow.camera.far = 160;
      sunLight.shadow.camera.left = -35;
      sunLight.shadow.camera.right = 35;
      sunLight.shadow.camera.top = 35;
      sunLight.shadow.camera.bottom = -35;
      sunLight.shadow.bias = -0.0005;
      sunLight.shadow.normalBias = 0.02;
      scene.add(sunLight);

      const hemiLight = new THREE.HemisphereLight(
        isNight ? 0x1e3a5f : 0x87ceeb,
        isNight ? 0x090d16 : 0x4b3f2f,
        isNight ? 0.65 : 0.85
      );
      scene.add(hemiLight);

      // OrbitControls (used in Orbit inspect mode)
      const controls = new OrbitControls(camera, renderer.domElement);
      controls.enableDamping = !isSoftwareGl;
      controls.dampingFactor = 0.08;
      controls.maxPolarAngle = Math.PI / 2 - 0.06;
      controls.minDistance = 4.5;
      controls.maxDistance = 24;
      controls.enabled = inputRef.current.cameraMode === 'orbit';

      const maxAniso = renderer.capabilities.getMaxAnisotropy();

      // Stage 1+ World Group: Ground Terrain + Textured Asphalt Road
      const worldGroup = new THREE.Group();
      scene.add(worldGroup);

      const terrainTex = createTerrainTexture(config.theme, maxAniso);
      const terrainGeo = new THREE.PlaneGeometry(420, 420);
      terrainGeo.rotateX(-Math.PI / 2);
      const terrainMat = new THREE.MeshStandardMaterial({
        map: terrainTex,
        roughness: 0.92,
        metalness: 0.04,
      });
      const terrain = new THREE.Mesh(terrainGeo, terrainMat);
      terrain.receiveShadow = true;
      worldGroup.add(terrain);

      const roadTex = createAsphaltTexture(maxAniso, isNight);
      const roadGeo = new THREE.PlaneGeometry(13.5, 420);
      roadGeo.rotateX(-Math.PI / 2);
      const roadMat = new THREE.MeshStandardMaterial({
        map: roadTex,
        roughness: 0.78,
        metalness: 0.12,
      });
      const road = new THREE.Mesh(roadGeo, roadMat);
      road.position.y = 0.02; // Offset >= 0.02 to prevent Z-fighting
      road.receiveShadow = true;
      worldGroup.add(road);

      // Stage 2+ Scenery Group: Mountains, Buildings / Basecamp Watchtowers, Trees via InstancedMesh
      const sceneryGroup = new THREE.Group();
      scene.add(sceneryGroup);

      const dummy = new THREE.Object3D();
      const colorTmp = new THREE.Color();

      // Distant Mountain Peaks
      const mountainGeo = new THREE.ConeGeometry(24, 38, 6);
      mountainGeo.translate(0, 19, 0);
      const mountainMat = new THREE.MeshStandardMaterial({
        color: isNight ? 0x1e293b : config.theme === 'tactical_basecamp' ? 0x6b5c43 : 0x3b4d5e,
        roughness: 0.95,
        metalness: 0.05,
        flatShading: true,
      });
      const mountainCount = 26;
      const mountains = new THREE.InstancedMesh(mountainGeo, mountainMat, mountainCount);
      for (let i = 0; i < mountainCount; i++) {
        const side = i % 2 === 0 ? -1 : 1;
        const x = side * (62 + (i % 5) * 24);
        const z = -190 + i * 16;
        const sx = 0.8 + (i % 4) * 0.35;
        const sy = 0.65 + (i % 5) * 0.32;
        dummy.position.set(x, 0, z);
        dummy.scale.set(sx, sy, sx);
        dummy.rotation.y = i * 0.9;
        dummy.updateMatrix();
        mountains.setMatrixAt(i, dummy.matrix);
      }
      mountains.computeBoundingSphere();
      sceneryGroup.add(mountains);

      // Roadside Architecture (Skyscrapers / Basecamp Watchtowers / Pine Trees)
      if (config.theme === 'neon_city' || config.theme === 'tactical_basecamp') {
        const bldgGeo = new THREE.BoxGeometry(7, 1, 7);
        bldgGeo.translate(0, 0.5, 0);
        const bldgMat = new THREE.MeshStandardMaterial({
          color: config.theme === 'neon_city' ? 0x1e293b : 0x57534e,
          metalness: config.theme === 'neon_city' ? 0.65 : 0.2,
          roughness: config.theme === 'neon_city' ? 0.3 : 0.82,
        });
        const count = 38;
        const bldgs = new THREE.InstancedMesh(bldgGeo, bldgMat, count);
        bldgs.castShadow = !isSoftwareGl;
        bldgs.receiveShadow = true;
        for (let i = 0; i < count; i++) {
          const side = i % 2 === 0 ? -1 : 1;
          const x = side * (13.5 + (i % 3) * 9.5);
          const z = -180 + Math.floor(i / 2) * 20;
          const h = config.theme === 'neon_city' ? 12 + (i % 6) * 8 : 6 + (i % 4) * 3.5;
          dummy.position.set(x, 0, z);
          dummy.scale.set(1 + (i % 2) * 0.4, h, 1 + (i % 3) * 0.3);
          dummy.rotation.y = 0;
          dummy.updateMatrix();
          bldgs.setMatrixAt(i, dummy.matrix);
          colorTmp.set(
            config.theme === 'neon_city'
              ? i % 3 === 0
                ? 0x164e63
                : 0x1e293b
              : i % 2 === 0
              ? 0x57534e
              : 0x44403c
          );
          bldgs.setColorAt(i, colorTmp);
        }
        bldgs.computeBoundingSphere();
        sceneryGroup.add(bldgs);
      }

      // Instanced Roadside Trees (Trunks + Crowns)
      const treeCount = 44;
      const trunkGeo = new THREE.CylinderGeometry(0.24, 0.34, 2.2, 8);
      trunkGeo.translate(0, 1.1, 0);
      const trunkMat = new THREE.MeshStandardMaterial({ color: 0x4a3525, roughness: 0.9 });
      const crownGeo = new THREE.ConeGeometry(1.65, 4.4, 7);
      crownGeo.translate(0, 4.0, 0);
      const crownMat = new THREE.MeshStandardMaterial({
        color: isNight ? 0x134e4a : 0x2d5a27,
        roughness: 0.85,
      });

      const trunks = new THREE.InstancedMesh(trunkGeo, trunkMat, treeCount);
      const crowns = new THREE.InstancedMesh(crownGeo, crownMat, treeCount);
      crowns.castShadow = !isSoftwareGl;

      for (let i = 0; i < treeCount; i++) {
        const side = i % 2 === 0 ? -1 : 1;
        const x = side * (9.8 + (i % 4) * 3.2);
        const z = -190 + i * 9.2;
        const sc = 0.85 + (i % 4) * 0.14;
        dummy.position.set(x, 0, z);
        dummy.scale.set(sc, sc, sc);
        dummy.rotation.y = i * 1.1;
        dummy.updateMatrix();
        trunks.setMatrixAt(i, dummy.matrix);
        crowns.setMatrixAt(i, dummy.matrix);
        colorTmp.setHSL(0.32 + (i % 3) * 0.02, 0.42, isNight ? 0.16 : 0.26 + (i % 4) * 0.03);
        crowns.setColorAt(i, colorTmp);
      }
      trunks.computeBoundingSphere();
      crowns.computeBoundingSphere();
      sceneryGroup.add(trunks, crowns);

      // Stage 3+ Hero Vehicle Group
      const { group: vehicle, wheels, tailLightMat } = buildCompositeVehicle(config);
      vehicle.position.set(0, 0, 0);
      scene.add(vehicle);

      // Optional Custom Generated Banner Archway on Road if Gemini Image was applied
      let bannerMesh: THREE.Mesh | null = null;
      if (config.customBannerDataUrl) {
        const img = new Image();
        img.crossOrigin = 'anonymous';
        img.onload = () => {
          const bTex = new THREE.Texture(img);
          bTex.colorSpace = THREE.SRGBColorSpace;
          bTex.needsUpdate = true;
          const bMat = new THREE.MeshStandardMaterial({ map: bTex, roughness: 0.3 });
          bannerMesh = new THREE.Mesh(new THREE.BoxGeometry(11, 3.2, 0.3), bMat);
          bannerMesh.position.set(0, 5.4, -28);
          sceneryGroup.add(bannerMesh);
        };
        img.src = config.customBannerDataUrl;
      }

      // Keyboard controls support alongside mobile touch-drag
      const keysDown = new Set<string>();
      const onKeyDown = (e: KeyboardEvent) => keysDown.add(e.key.toLowerCase());
      const onKeyUp = (e: KeyboardEvent) => keysDown.delete(e.key.toLowerCase());
      window.addEventListener('keydown', onKeyDown);
      window.addEventListener('keyup', onKeyUp);

      // Physics + Animation loop state (Zero GC allocations inside loop)
      let currentSpeed = 16; // gentle idle cruise demo speed so scene feels alive
      let headingX = 0;
      let roadScroll = 0;
      let hudAccumulator = 0;
      let disposed = false;
      let frameId = 0;
      const clock = new THREE.Clock();
      const _camTargetPos = new THREE.Vector3();
      const _lookAtTarget = new THREE.Vector3();

      const afterDraw = (cb: () => void) => {
        const gl = renderer.getContext() as WebGL2RenderingContext;
        const sync = gl.fenceSync?.(gl.SYNC_GPU_COMMANDS_COMPLETE, 0);
        gl.flush();
        const poll = () => {
          if (disposed) return;
          const state = sync && gl.getSyncParameter(sync, gl.SYNC_STATUS);
          if (state === gl.UNSIGNALED) {
            frameId = window.setTimeout(poll, 5);
          } else {
            if (sync) gl.deleteSync(sync);
            frameId = window.setTimeout(cb, 80);
          }
        };
        frameId = window.setTimeout(poll, 5);
      };

      const tick = () => {
        if (disposed) return;
        const delta = Math.min(clock.getDelta(), 0.08);
        const st = stageRef.current;

        // Progressive 5-stage visibility
        sceneryGroup.visible = st >= 2;
        vehicle.visible = st >= 3;

        const maxMs = (configRef.current.topSpeed || 200) / 3.6;
        let steerInput = inputRef.current.steer;
        if (keysDown.has('a') || keysDown.has('arrowleft')) steerInput = -0.9;
        if (keysDown.has('d') || keysDown.has('arrowright')) steerInput = 0.9;

        const gasPressed = inputRef.current.gas || keysDown.has('w') || keysDown.has('arrowup');
        const brakePressed = inputRef.current.brake || keysDown.has('s') || keysDown.has('arrowdown');

        if (gasPressed) {
          currentSpeed = THREE.MathUtils.damp(currentSpeed, maxMs, 1.9, delta);
        } else if (brakePressed) {
          currentSpeed = THREE.MathUtils.damp(currentSpeed, 0, 5.0, delta);
        } else {
          // Smooth cruise inertia
          currentSpeed = THREE.MathUtils.damp(currentSpeed, st >= 4 ? 22 : 12, 0.9, delta);
        }

        tailLightMat.emissiveIntensity = brakePressed ? 4.5 : 1.5;

        // Lateral steering & body lean
        const lateralDelta = steerInput * Math.min(currentSpeed * 0.22, 11) * delta;
        headingX = THREE.MathUtils.clamp(headingX + lateralDelta, -4.6, 4.6);
        vehicle.position.x = THREE.MathUtils.damp(vehicle.position.x, headingX, 10, delta);
        vehicle.rotation.y = THREE.MathUtils.damp(vehicle.rotation.y, -steerInput * 0.22, 10, delta);
        vehicle.rotation.z = THREE.MathUtils.damp(vehicle.rotation.z, steerInput * 0.055, 8, delta);

        // Scroll road texture & loop scenery cleanly
        roadScroll += currentSpeed * delta;
        roadTex.offset.y = -(roadScroll * 0.08) % 1;
        sceneryGroup.position.z = (roadScroll * 0.95) % 40;

        // Spin wheels physically
        const wheelSpin = currentSpeed * delta * 2.2;
        for (let i = 0; i < wheels.length; i++) {
          wheels[i].rotation.x -= wheelSpin;
        }

        // Camera choreography
        if (inputRef.current.cameraMode === 'orbit') {
          controls.enabled = true;
          controls.target.set(vehicle.position.x, 1.1, vehicle.position.z);
          controls.update();
        } else {
          controls.enabled = false;
          const speedFactor = THREE.MathUtils.clamp(currentSpeed / maxMs, 0, 1);
          camera.fov = THREE.MathUtils.damp(camera.fov, 58 + speedFactor * 14, 5, delta);
          camera.updateProjectionMatrix();

          _camTargetPos.set(
            vehicle.position.x * 0.72,
            3.6 + speedFactor * 0.45,
            7.8 + speedFactor * 1.4
          );
          camera.position.lerp(_camTargetPos, 1 - Math.exp(-6.5 * delta));
          _lookAtTarget.set(vehicle.position.x, 1.15, -14);
          camera.lookAt(_lookAtTarget);
        }

        hudAccumulator += delta;
        if (hudAccumulator > 0.12) {
          hudAccumulator = 0;
          setSpeedKmh(Math.round(currentSpeed * 3.6));
        }

        renderer.render(scene, camera);
        if (isSoftwareGl) {
          afterDraw(tick);
        } else {
          frameId = requestAnimationFrame(tick);
        }
      };

      const onResize = () => {
        if (!container || disposed) return;
        const w = Math.max(container.clientWidth, 240);
        const h = Math.max(container.clientHeight, 200);
        camera.aspect = w / h;
        camera.updateProjectionMatrix();
        renderer.setSize(w, h);
      };

      const ro = new ResizeObserver(onResize);
      ro.observe(container);
      tick();

      return () => {
        disposed = true;
        cancelAnimationFrame(frameId);
        clearTimeout(frameId);
        ro.disconnect();
        window.removeEventListener('keydown', onKeyDown);
        window.removeEventListener('keyup', onKeyUp);
        controls.dispose();
        terrainGeo.dispose();
        terrainMat.dispose();
        terrainTex.dispose();
        roadGeo.dispose();
        roadMat.dispose();
        roadTex.dispose();
        mountainGeo.dispose();
        mountainMat.dispose();
        trunkGeo.dispose();
        trunkMat.dispose();
        crownGeo.dispose();
        crownMat.dispose();
        envTex.dispose();
        renderer.dispose();
        rendererRef.current = null;
        sceneRef.current = null;
        cameraRef.current = null;
      };
    }, [
      config.theme,
      config.vehicleType,
      config.primaryColor,
      config.accentColor,
      config.timeOfDay,
      config.fogDensity,
      config.customBannerDataUrl,
    ]);

    // Direct On-Canvas Touch-Drag Steering handlers
    const handlePointerDown = (e: React.PointerEvent<HTMLDivElement>) => {
      if (cameraMode === 'orbit') return;
      inputRef.current.dragging = true;
      inputRef.current.dragStartX = e.clientX;
      e.currentTarget.setPointerCapture(e.pointerId);
    };

    const handlePointerMove = (e: React.PointerEvent<HTMLDivElement>) => {
      if (!inputRef.current.dragging || cameraMode === 'orbit') return;
      const dx = e.clientX - inputRef.current.dragStartX;
      const clamped = Math.max(-1, Math.min(1, dx / 75));
      inputRef.current.steer = clamped;
      setSteerVisual(clamped);
    };

    const handlePointerUp = () => {
      inputRef.current.dragging = false;
      inputRef.current.steer = 0;
      setSteerVisual(0);
    };

    return (
      <div className="relative w-full h-full overflow-hidden bg-[#070b14] select-none touch-none">
        {/* Isolated WebGL Canvas Mount */}
        <div
          ref={mountRef}
          onPointerDown={handlePointerDown}
          onPointerMove={handlePointerMove}
          onPointerUp={handlePointerUp}
          onPointerCancel={handlePointerUp}
          className="w-full h-full cursor-grab active:cursor-grabbing"
        />

        {/* Minimal Transparent HUD Overlay (No backdrop-blur over WebGL) */}
        <div className="pointer-events-none absolute top-3 left-3 right-3 flex items-start justify-between gap-2 z-10">
          <div className="px-3 py-1.5 rounded-lg bg-[#070b14]/80 border border-white/10">
            <div className="text-xs font-semibold text-white truncate max-w-[180px]">{title}</div>
            <div className="text-[11px] text-slate-300 font-mono tabular-nums">
              {speedKmh} km/h · Stage {buildStage}/5
            </div>
          </div>

          <button
            type="button"
            onClick={() => setCameraMode((m) => (m === 'chase' ? 'orbit' : 'chase'))}
            className="pointer-events-auto px-2.5 py-1.5 min-h-[36px] rounded-lg bg-[#070b14]/85 border border-white/15 text-[11px] font-medium text-cyan-300 hover:text-white transition-colors whitespace-nowrap"
          >
            {cameraMode === 'chase' ? 'Chase Cam' : '360° Orbit'}
          </button>
        </div>

        {/* Subtle On-Canvas Virtual Joystick & Corner Pedal Overlays (Stage 4+) */}
        {buildStage >= 4 && cameraMode === 'chase' && (
          <>
            {/* Bottom-Left Subtle Touch-Drag Steering Indicator */}
            <div className="pointer-events-none absolute bottom-3 left-3 z-10 flex items-center gap-2">
              <div className="w-20 h-20 rounded-full border border-white/20 bg-[#070b14]/45 flex items-center justify-center relative">
                <div
                  className="w-8 h-8 rounded-full bg-cyan-400/70 border border-cyan-200 transition-transform duration-75"
                  style={{ transform: `translateX(${steerVisual * 22}px)` }}
                />
                <span className="absolute -bottom-5 text-[10px] text-slate-300 whitespace-nowrap">
                  Drag to Steer
                </span>
              </div>
            </div>

            {/* Bottom-Right Corner Transparent Brake / Gas Pedals */}
            <div className="absolute bottom-3 right-3 z-10 flex items-end gap-2">
              <button
                type="button"
                onPointerDown={(e) => {
                  e.stopPropagation();
                  inputRef.current.brake = true;
                }}
                onPointerUp={(e) => {
                  e.stopPropagation();
                  inputRef.current.brake = false;
                }}
                onPointerLeave={() => {
                  inputRef.current.brake = false;
                }}
                className="w-14 h-12 rounded-xl bg-rose-500/30 active:bg-rose-500/60 border border-rose-400/40 text-xs font-semibold text-white select-none"
              >
                BRAKE
              </button>
              <button
                type="button"
                onPointerDown={(e) => {
                  e.stopPropagation();
                  inputRef.current.gas = true;
                }}
                onPointerUp={(e) => {
                  e.stopPropagation();
                  inputRef.current.gas = false;
                }}
                onPointerLeave={() => {
                  inputRef.current.gas = false;
                }}
                className="w-14 h-16 rounded-xl bg-emerald-500/35 active:bg-emerald-500/65 border border-emerald-400/50 text-xs font-semibold text-white select-none"
              >
                GAS
              </button>
            </div>
          </>
        )}
      </div>
    );
  }
);
