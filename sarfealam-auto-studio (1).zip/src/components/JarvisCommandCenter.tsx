import { FormEvent, useRef, useState } from 'react';
import {
  Code2,
  Cpu,
  Database,
  Eye,
  EyeOff,
  FolderArchive,
  Globe,
  Image as ImageIcon,
  KeyRound,
  RotateCcw,
  Send,
  Shield,
  Sliders,
} from 'lucide-react';
import {
  ChatMessage,
  DepartmentAssignment,
  FloatingPanelId,
  JarvisStatus,
  Language,
  SecretsState,
  WorkerNodeState,
} from '../types';
import { t } from '../services/i18n';
import { hasAnyAIKey } from '../services/secretsEngine';
import { JarvisHologram } from './JarvisHologram';

interface JarvisCommandCenterProps {
  lang: Language;
  jarvisStatus: JarvisStatus;
  liveTranscript: string;
  messages: ChatMessage[];
  workers: WorkerNodeState;
  secrets: SecretsState;
  routing: DepartmentAssignment[];
  previewVisible: boolean;
  checkpointCount: number;
  onSendPrompt: (text: string) => void;
  onOpenPanel: (panel: FloatingPanelId) => void;
  onTogglePreview: () => void;
  onRollback: () => void;
}

export function JarvisCommandCenter({
  lang,
  jarvisStatus,
  liveTranscript,
  messages,
  workers,
  secrets,
  routing,
  previewVisible,
  checkpointCount,
  onSendPrompt,
  onOpenPanel,
  onTogglePreview,
  onRollback,
}: JarvisCommandCenterProps) {
  const [input, setInput] = useState('');
  const listRef = useRef<HTMLDivElement | null>(null);
  const aiReady = hasAnyAIKey(secrets);
  const brainDept = routing.find((r) => r.department === 'brain');
  const codeDept = routing.find((r) => r.department === 'code');

  const handleSubmit = (e: FormEvent) => {
    e.preventDefault();
    const trimmed = input.trim();
    if (!trimmed) return;
    setInput('');
    onSendPrompt(trimmed);
  };

  const nodeColor = (st: 'idle' | 'active' | 'done' | 'error') => {
    if (st === 'active') return 'border-cyan-400/70 bg-cyan-950/40 text-cyan-200';
    if (st === 'done') return 'border-emerald-400/50 bg-emerald-950/30 text-emerald-200';
    if (st === 'error') return 'border-rose-400/50 bg-rose-950/30 text-rose-200';
    return 'border-white/10 bg-[#0b1120] text-slate-300';
  };

  const lineClass = (st: 'idle' | 'active' | 'done' | 'error') =>
    st === 'active' ? 'pipeline-energy-line' : 'pipeline-energy-line-idle';

  return (
    <section className="rounded-2xl bg-[#0b1120] border border-white/10 p-3 sm:p-4 flex flex-col gap-3 lg:h-[calc(100vh-148px)]">
      {/* JARVIS 3D Hologram Hub + 4 Connected Live Worker Nodes */}
      <div className="relative rounded-xl bg-[#070b14] border border-white/10 p-3 overflow-hidden">
        {/* Calm Animated SVG Energy Pipeline Lines connecting Center Hologram to 4 Worker Nodes */}
        <svg
          className="pointer-events-none absolute inset-0 w-full h-full"
          viewBox="0 0 400 180"
          preserveAspectRatio="none"
          aria-hidden="true"
        >
          {/* Top-Left: Research & Web */}
          <path
            d="M 200 90 C 150 90, 130 45, 75 45"
            fill="none"
            stroke={workers.research === 'active' ? '#06b6d4' : '#1e293b'}
            strokeWidth={workers.research === 'active' ? '2.2' : '1.4'}
            className={lineClass(workers.research)}
          />
          {/* Top-Right: Code AI */}
          <path
            d="M 200 90 C 250 90, 270 45, 325 45"
            fill="none"
            stroke={workers.codeAi === 'active' ? '#8b5cf6' : '#1e293b'}
            strokeWidth={workers.codeAi === 'active' ? '2.2' : '1.4'}
            className={lineClass(workers.codeAi)}
          />
          {/* Bottom-Left: Image & 3D Gen */}
          <path
            d="M 200 90 C 150 90, 130 135, 75 135"
            fill="none"
            stroke={workers.image3d === 'active' ? '#06b6d4' : '#1e293b'}
            strokeWidth={workers.image3d === 'active' ? '2.2' : '1.4'}
            className={lineClass(workers.image3d)}
          />
          {/* Bottom-Right: GitHub + Supabase */}
          <path
            d="M 200 90 C 250 90, 270 135, 325 135"
            fill="none"
            stroke={workers.githubSupabase === 'active' ? '#10b981' : '#1e293b'}
            strokeWidth={workers.githubSupabase === 'active' ? '2.2' : '1.4'}
            className={lineClass(workers.githubSupabase)}
          />
        </svg>

        <div className="relative z-10 grid grid-cols-3 items-center gap-2">
          {/* Left 2 Worker Nodes */}
          <div className="space-y-2">
            <div className={`p-2 rounded-xl border transition-colors ${nodeColor(workers.research)}`}>
              <div className="flex items-center gap-1.5 text-[11px] font-semibold">
                <Globe className="w-3.5 h-3.5 text-cyan-400 shrink-0" />
                <span className="truncate">{t(lang, 'nodeResearch')}</span>
              </div>
              <div className="text-[10px] text-slate-400 truncate mt-0.5">{workers.detail.research}</div>
            </div>

            <div className={`p-2 rounded-xl border transition-colors ${nodeColor(workers.image3d)}`}>
              <div className="flex items-center gap-1.5 text-[11px] font-semibold">
                <ImageIcon className="w-3.5 h-3.5 text-cyan-400 shrink-0" />
                <span className="truncate">{t(lang, 'nodeImage3d')}</span>
              </div>
              <div className="text-[10px] text-slate-400 truncate mt-0.5">{workers.detail.image3d}</div>
            </div>
          </div>

          {/* Center Three.js 3D Hologram JARVIS Avatar */}
          <div className="flex flex-col items-center justify-center">
            <div className="w-28 h-28 sm:w-32 sm:h-32">
              <JarvisHologram status={jarvisStatus} />
            </div>
            <div className="text-[11px] font-medium text-cyan-300 capitalize -mt-1">
              JARVIS · {jarvisStatus}
            </div>
          </div>

          {/* Right 2 Worker Nodes */}
          <div className="space-y-2">
            <div className={`p-2 rounded-xl border transition-colors ${nodeColor(workers.codeAi)}`}>
              <div className="flex items-center gap-1.5 text-[11px] font-semibold">
                <Code2 className="w-3.5 h-3.5 text-purple-400 shrink-0" />
                <span className="truncate">{t(lang, 'nodeCode')}</span>
              </div>
              <div className="text-[10px] text-slate-400 truncate mt-0.5">{workers.detail.codeAi}</div>
            </div>

            <div className={`p-2 rounded-xl border transition-colors ${nodeColor(workers.githubSupabase)}`}>
              <div className="flex items-center gap-1.5 text-[11px] font-semibold">
                <Database className="w-3.5 h-3.5 text-emerald-400 shrink-0" />
                <span className="truncate">{t(lang, 'nodeGitSupa')}</span>
              </div>
              <div className="text-[10px] text-slate-400 truncate mt-0.5">{workers.detail.githubSupabase}</div>
            </div>
          </div>
        </div>
      </div>

      {/* Honest System Readiness Line (Zero Fake Connected Claims) */}
      <div className="flex flex-wrap items-center justify-between gap-x-3 gap-y-1 px-1 text-[11px] text-slate-400">
        <div className="flex flex-wrap items-center gap-x-2 gap-y-0.5">
          <span className={aiReady ? 'text-emerald-400' : 'text-amber-300'}>
            {aiReady ? `AI: ${brainDept?.model} / ${codeDept?.model}` : 'AI: 0 Keys (Open Secrets)'}
          </span>
          <span aria-hidden="true">·</span>
          <span className={secrets.github.connected ? 'text-emerald-400' : 'text-slate-500'}>
            {secrets.github.connected ? `GitHub: @${secrets.github.verifiedLogin || secrets.github.username}` : 'GitHub: Not linked'}
          </span>
          <span aria-hidden="true">·</span>
          <span className={secrets.studioSupabase.connected ? 'text-cyan-400' : 'text-slate-500'}>
            {secrets.studioSupabase.connected ? 'Studio DB: Synced' : 'Studio DB: Local only'}
          </span>
          <span aria-hidden="true">·</span>
          <span className={secrets.appsSupabase.connected ? 'text-purple-300' : 'text-slate-500'}>
            {secrets.appsSupabase.connected ? 'Apps DB: Ready' : 'Apps DB: Missing'}
          </span>
        </div>
      </div>

      {/* On-Demand Floating Mini-Window Trigger Strip */}
      <div className="flex items-center gap-1.5 overflow-x-auto pb-0.5">
        <button
          type="button"
          onClick={() => onOpenPanel('secrets')}
          className={`px-3 py-1.5 min-h-[36px] rounded-lg border text-xs font-medium flex items-center gap-1.5 whitespace-nowrap shrink-0 transition-colors ${
            !aiReady
              ? 'bg-cyan-500/20 border-cyan-400/50 text-cyan-200'
              : 'bg-[#070b14] border-white/10 text-slate-300 hover:text-white'
          }`}
        >
          <KeyRound className="w-3.5 h-3.5" />
          <span>{t(lang, 'openSecrets')}</span>
        </button>
        <button
          type="button"
          onClick={() => onOpenPanel('code_explorer')}
          className="px-3 py-1.5 min-h-[36px] rounded-lg bg-[#070b14] border border-white/10 text-xs font-medium text-slate-300 hover:text-white flex items-center gap-1.5 whitespace-nowrap shrink-0"
        >
          <Code2 className="w-3.5 h-3.5" />
          <span>{t(lang, 'codeExplorer')}</span>
        </button>
        <button
          type="button"
          onClick={() => onOpenPanel('vault')}
          className="px-3 py-1.5 min-h-[36px] rounded-lg bg-[#070b14] border border-white/10 text-xs font-medium text-slate-300 hover:text-white flex items-center gap-1.5 whitespace-nowrap shrink-0"
        >
          <FolderArchive className="w-3.5 h-3.5" />
          <span>{t(lang, 'tabVault')}</span>
        </button>
        <button
          type="button"
          onClick={() => onOpenPanel('admin')}
          className="px-3 py-1.5 min-h-[36px] rounded-lg bg-[#070b14] border border-white/10 text-xs font-medium text-slate-300 hover:text-white flex items-center gap-1.5 whitespace-nowrap shrink-0"
        >
          <Shield className="w-3.5 h-3.5" />
          <span>{t(lang, 'tabAdmin')}</span>
        </button>
        <button
          type="button"
          onClick={() => onOpenPanel('system_map')}
          className="px-3 py-1.5 min-h-[36px] rounded-lg bg-[#070b14] border border-white/10 text-xs font-medium text-slate-300 hover:text-white flex items-center gap-1.5 whitespace-nowrap shrink-0"
        >
          <Cpu className="w-3.5 h-3.5" />
          <span>{t(lang, 'systemMap')}</span>
        </button>
        <button
          type="button"
          onClick={() => onOpenPanel('skills')}
          className="px-3 py-1.5 min-h-[36px] rounded-lg bg-[#070b14] border border-white/10 text-xs font-medium text-slate-300 hover:text-white flex items-center gap-1.5 whitespace-nowrap shrink-0"
        >
          <Sliders className="w-3.5 h-3.5" />
          <span>{t(lang, 'tabSkills')}</span>
        </button>
        <button
          type="button"
          onClick={onTogglePreview}
          className="px-3 py-1.5 min-h-[36px] rounded-lg bg-[#070b14] border border-white/10 text-xs font-medium text-slate-300 hover:text-white flex items-center gap-1.5 whitespace-nowrap shrink-0"
        >
          {previewVisible ? <EyeOff className="w-3.5 h-3.5" /> : <Eye className="w-3.5 h-3.5" />}
          <span>{previewVisible ? t(lang, 'hidePreview') : t(lang, 'showPreview')}</span>
        </button>
        {checkpointCount > 0 && (
          <button
            type="button"
            onClick={onRollback}
            className="px-3 py-1.5 min-h-[36px] rounded-lg bg-purple-500/15 border border-purple-400/40 text-xs font-medium text-purple-200 flex items-center gap-1.5 whitespace-nowrap shrink-0"
          >
            <RotateCcw className="w-3.5 h-3.5" />
            <span>{t(lang, 'rollback')}</span>
          </button>
        )}
      </div>

      {/* Live Transcript & JARVIS Conversation Stream */}
      <div
        ref={listRef}
        className="flex-1 min-h-[140px] max-h-[260px] lg:max-h-none overflow-y-auto space-y-2 pr-1"
      >
        {messages.slice(-14).map((msg) => (
          <div
            key={msg.id}
            className={`p-2.5 rounded-xl text-xs leading-relaxed ${
              msg.role === 'user'
                ? 'bg-cyan-500/15 border border-cyan-500/30 text-slate-100 ml-6'
                : msg.role === 'system'
                ? 'bg-white/[0.03] border border-white/10 text-slate-400'
                : 'bg-[#070b14] border border-white/10 text-slate-200 mr-4'
            }`}
          >
            <div className="flex items-center justify-between gap-2 mb-0.5 text-[10px] text-slate-400">
              <span className="font-semibold text-slate-300">
                {msg.role === 'user' ? 'You' : msg.role === 'jarvis' ? 'JARVIS' : 'Studio'}
              </span>
              {msg.modelUsed && (
                <span className="truncate font-mono text-slate-500">
                  {msg.providerUsed} · {msg.modelUsed}
                </span>
              )}
            </div>
            <div className="whitespace-pre-wrap">{msg.text}</div>
            {msg.toolCalls && msg.toolCalls.length > 0 && (
              <div className="mt-1.5 text-[10px] font-mono text-cyan-400">
                Executed: {msg.toolCalls.join(' · ')}
              </div>
            )}
          </div>
        ))}

        {liveTranscript && (
          <div className="p-2.5 rounded-xl bg-emerald-500/10 border border-emerald-400/30 text-xs text-emerald-200 ml-6">
            <span className="text-[10px] text-emerald-400 block">Live Hearing...</span>
            {liveTranscript}
          </div>
        )}
      </div>

      {/* Direct Command Input */}
      <form onSubmit={handleSubmit} className="flex items-center gap-2 pt-1 border-t border-white/10">
        <input
          value={input}
          onChange={(e) => setInput(e.target.value)}
          placeholder={t(lang, 'askPlaceholder')}
          className="flex-1 min-h-[44px] px-3.5 rounded-xl bg-[#070b14] border border-white/10 focus:border-cyan-400/60 text-xs sm:text-sm text-white placeholder:text-slate-500 focus:outline-none"
        />
        <button
          type="submit"
          className="min-h-[44px] px-4 rounded-xl bg-cyan-500 hover:bg-cyan-400 text-slate-950 font-semibold text-xs flex items-center gap-1.5 shrink-0 transition-colors"
        >
          <Send className="w-4 h-4" />
          <span>{t(lang, 'send')}</span>
        </button>
      </form>
    </section>
  );
}
