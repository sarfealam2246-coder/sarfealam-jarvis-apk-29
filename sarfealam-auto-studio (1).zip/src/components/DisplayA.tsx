import { RefObject } from 'react';
import {
  CheckCircle2,
  Eye,
  Image as ImageIcon,
  Layers,
  Maximize2,
  Minimize2,
  Sparkles,
} from 'lucide-react';
import { DesignBlueprint, Language } from '../types';
import { t } from '../services/i18n';
import { ThreeGameViewport, ThreeGameViewportHandle } from './ThreeGameViewport';
import { CommercialAppPreview } from './CommercialAppPreview';

interface DisplayAProps {
  lang: Language;
  blueprint: DesignBlueprint | null;
  buildStage: number;
  isBuilding: boolean;
  fullscreen: boolean;
  generatedImageUrl: string | null;
  visionQaBusy: boolean;
  visionQaNote: string | null;
  threeRef: RefObject<ThreeGameViewportHandle | null>;
  onToggleFullscreen: () => void;
  onApproveDesignAndBuild: () => void;
  onRunVisionQa: () => void;
  onApplyGeneratedImage: () => void;
  onClearGeneratedImage: () => void;
  onQuickStartPrompt: (prompt: string) => void;
}

const STAGE_KEYS = ['stage1', 'stage2', 'stage3', 'stage4', 'stage5'] as const;

export function DisplayA({
  lang,
  blueprint,
  buildStage,
  isBuilding,
  fullscreen,
  generatedImageUrl,
  visionQaBusy,
  visionQaNote,
  threeRef,
  onToggleFullscreen,
  onApproveDesignAndBuild,
  onRunVisionQa,
  onApplyGeneratedImage,
  onClearGeneratedImage,
  onQuickStartPrompt,
}: DisplayAProps) {
  const showDesignCard = Boolean(blueprint && !blueprint.approved && buildStage === 0);

  return (
    <section
      className={`relative w-full overflow-hidden border border-white/10 bg-[#0b1120] flex flex-col ${
        fullscreen
          ? 'fixed inset-0 z-50 rounded-none border-0'
          : 'rounded-2xl h-[360px] sm:h-[420px] lg:h-[calc(100vh-148px)]'
      }`}
    >
      {/* Edge-to-Edge Viewport Area */}
      <div className="relative flex-1 w-full h-full overflow-hidden">
        {/* 1) Generated Image Preview Overlay */}
        {generatedImageUrl ? (
          <div className="w-full h-full flex flex-col bg-[#070b14]">
            <div className="flex-1 relative overflow-hidden flex items-center justify-center p-3">
              <img
                src={generatedImageUrl}
                alt="Gemini Generated Studio Asset"
                referrerPolicy="no-referrer"
                className="max-w-full max-h-full rounded-xl object-contain border border-white/10"
              />
            </div>
            <div className="p-3 bg-[#0b1120] border-t border-white/10 flex items-center justify-between gap-2">
              <div className="flex items-center gap-2 text-xs text-cyan-300">
                <ImageIcon className="w-4 h-4 shrink-0" />
                <span>Gemini Image Ready</span>
              </div>
              <div className="flex items-center gap-2">
                <button
                  type="button"
                  onClick={onApplyGeneratedImage}
                  className="px-3 py-1.5 min-h-[36px] rounded-lg bg-emerald-500 text-slate-950 text-xs font-semibold whitespace-nowrap"
                >
                  Apply as Banner / Texture
                </button>
                <button
                  type="button"
                  onClick={onClearGeneratedImage}
                  className="px-3 py-1.5 min-h-[36px] rounded-lg bg-white/10 text-xs text-slate-200 whitespace-nowrap"
                >
                  Back to Preview
                </button>
              </div>
            </div>
          </div>
        ) : showDesignCard && blueprint ? (
          /* 2) Design-First Blueprint Preview (Before 5-Stage Coding) */
          <div className="w-full h-full overflow-y-auto p-4 sm:p-6 bg-gradient-to-br from-[#0b1120] via-[#070b14] to-[#0f172a] flex flex-col justify-between gap-4">
            <div className="space-y-4">
              <div className="flex items-start justify-between gap-3">
                <div>
                  <div className="text-xs font-medium text-cyan-400">
                    {t(lang, 'designPreviewTitle')} · {blueprint.engine === 'godot4' ? 'Godot 4 Mobile Vulkan' : 'Flutter Android APK'}
                  </div>
                  <h2 className="text-xl sm:text-2xl font-bold text-white mt-1 text-balance">
                    {blueprint.title}
                  </h2>
                </div>
                <div className="flex items-center gap-1.5 shrink-0">
                  {blueprint.themePalette.map((hex, i) => (
                    <span
                      key={i}
                      className="w-5 h-5 rounded-md border border-white/20"
                      style={{ backgroundColor: hex }}
                      title={hex}
                    />
                  ))}
                </div>
              </div>

              <p className="text-xs sm:text-sm text-slate-300 leading-relaxed">{blueprint.summary}</p>

              <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
                <div className="p-3 rounded-xl bg-white/[0.03] border border-white/10 space-y-1.5">
                  <div className="text-xs font-semibold text-white">Planned Capabilities</div>
                  <ul className="space-y-1 text-xs text-slate-300">
                    {blueprint.features.map((f, i) => (
                      <li key={i} className="flex items-start gap-2">
                        <CheckCircle2 className="w-3.5 h-3.5 text-emerald-400 shrink-0 mt-0.5" />
                        <span>{f}</span>
                      </li>
                    ))}
                  </ul>
                </div>

                <div className="p-3 rounded-xl bg-white/[0.03] border border-white/10 space-y-1.5">
                  <div className="text-xs font-semibold text-white">Screens & 3D Zones</div>
                  <div className="space-y-1 text-xs text-slate-300">
                    {blueprint.screensOrZones.map((z, i) => (
                      <div key={i} className="flex items-center gap-2">
                        <Layers className="w-3.5 h-3.5 text-purple-400 shrink-0" />
                        <span>{z}</span>
                      </div>
                    ))}
                  </div>
                </div>
              </div>
            </div>

            <div className="flex flex-wrap items-center justify-between gap-3 pt-3 border-t border-white/10">
              <div className="text-xs text-slate-400">
                Ask JARVIS to tweak theme/colors or approve to start 5-stage build.
              </div>
              <button
                type="button"
                onClick={onApproveDesignAndBuild}
                className="px-4 py-2.5 min-h-[44px] rounded-xl bg-cyan-500 hover:bg-cyan-400 text-slate-950 text-xs sm:text-sm font-bold transition-colors whitespace-nowrap"
              >
                {t(lang, 'approveAndBuild')}
              </button>
            </div>
          </div>
        ) : blueprint && blueprint.category === 'game_3d' && blueprint.game3d ? (
          /* 3) Real Three.js WebGL PBR 3D Game Viewport */
          <ThreeGameViewport
            ref={threeRef}
            config={blueprint.game3d}
            buildStage={Math.max(1, buildStage)}
            title={blueprint.title}
          />
        ) : blueprint && blueprint.commercial ? (
          /* 4) Interactive Commercial Market & Business App Viewport */
          <CommercialAppPreview
            config={blueprint.commercial}
            buildStage={Math.max(1, buildStage)}
          />
        ) : (
          /* 5) Clean First-Open Welcome Studio Stage with Instant Launch Starters */
          <div className="w-full h-full p-5 flex flex-col justify-between bg-gradient-to-br from-[#0b1120] via-[#070b14] to-[#0d1426]">
            <div className="space-y-2 max-w-lg">
              <div className="text-xs font-medium text-cyan-400">
                Display A · Edge-to-Edge Live Preview
              </div>
              <h2 className="text-xl sm:text-2xl font-bold text-white text-balance">
                Design & Test 3D PBR Games or Commercial Android Apps
              </h2>
              <p className="text-xs sm:text-sm text-slate-400 leading-relaxed">
                Speak to JARVIS or tap a starter below to render a Design Preview first, assemble in 5 progressive stages, and export to GitHub APK + Owner Admin Web Panel.
              </p>
            </div>

            <div className="grid grid-cols-2 sm:grid-cols-3 gap-2">
              {[
                { label: '3D Highway Racer', prompt: 'Build a 3D golden hour highway sports car racing game' },
                { label: 'Army Basecamp Jeep', prompt: 'Create a 3D tactical army basecamp armored jeep simulator' },
                { label: 'Quick-Commerce Store', prompt: 'Build a commercial grocery e-commerce app with cart and coupons' },
                { label: 'Khata POS Billing', prompt: 'Create a Khata book Udhar Jama accounting and UPI invoice app' },
                { label: 'Ride Booking App', prompt: 'Build a city ride and parcel booking app with route ETA' },
                { label: 'Teen Patti Table', prompt: 'Create a Teen Patti interactive card game table app' },
              ].map((s) => (
                <button
                  key={s.label}
                  type="button"
                  onClick={() => onQuickStartPrompt(s.prompt)}
                  className="p-2.5 min-h-[44px] rounded-xl bg-[#0f172a] hover:bg-[#152038] border border-white/10 text-left transition-colors"
                >
                  <div className="text-xs font-semibold text-white truncate">{s.label}</div>
                  <div className="text-[11px] text-slate-400 truncate mt-0.5">Tap to preview</div>
                </button>
              ))}
            </div>
          </div>
        )}

        {/* Top-Right Compact Viewport Controls (Vision QA + Fullscreen) */}
        <div className="absolute top-2.5 right-2.5 z-20 flex items-center gap-1.5">
          {blueprint && buildStage >= 3 && !generatedImageUrl && (
            <button
              type="button"
              onClick={onRunVisionQa}
              disabled={visionQaBusy}
              className="px-2.5 py-1.5 min-h-[36px] rounded-lg bg-[#070b14]/90 border border-purple-400/40 text-[11px] font-medium text-purple-200 hover:text-white flex items-center gap-1.5 whitespace-nowrap"
              title="Capture snapshot & run Vision Self-Heal QA"
            >
              <Eye className="w-3.5 h-3.5" />
              <span>{visionQaBusy ? 'Scanning...' : t(lang, 'visionQa')}</span>
            </button>
          )}
          <button
            type="button"
            onClick={onToggleFullscreen}
            className="p-2 min-h-[36px] min-w-[36px] rounded-lg bg-[#070b14]/90 border border-white/15 text-slate-200 hover:text-white flex items-center justify-center"
            aria-label={fullscreen ? t(lang, 'exitFullscreen') : t(lang, 'fullscreen')}
          >
            {fullscreen ? <Minimize2 className="w-4 h-4" /> : <Maximize2 className="w-4 h-4" />}
          </button>
        </div>

        {/* Vision QA Diagnostic Banner if present */}
        {visionQaNote && (
          <div className="absolute bottom-2 left-2 right-2 z-20 px-3 py-2 rounded-xl bg-[#070b14]/95 border border-purple-500/40 text-xs text-slate-200 flex items-center gap-2">
            <Sparkles className="w-3.5 h-3.5 text-purple-400 shrink-0" />
            <span className="truncate">{visionQaNote}</span>
          </div>
        )}
      </div>

      {/* Slim Progressive 5-Stage Assembly Strip (Only visible while building or ready) */}
      {blueprint && buildStage > 0 && (
        <div className="px-3 py-2 bg-[#070b14] border-t border-white/10 flex items-center justify-between gap-2 overflow-x-auto">
          <div className="flex items-center gap-1.5 shrink-0">
            {STAGE_KEYS.map((key, idx) => {
              const num = idx + 1;
              const done = buildStage >= num;
              const active = isBuilding && buildStage === num;
              return (
                <span
                  key={key}
                  className={`text-[11px] whitespace-nowrap font-medium ${
                    done
                      ? 'text-emerald-400'
                      : active
                      ? 'text-cyan-300'
                      : 'text-slate-500'
                  }`}
                >
                  {t(lang, key)}
                  {idx < 4 ? ' · ' : ''}
                </span>
              );
            })}
          </div>
          {buildStage === 5 && (
            <span className="text-[11px] font-semibold text-emerald-400 whitespace-nowrap shrink-0">
              OK Export Unlocked
            </span>
          )}
        </div>
      )}
    </section>
  );
}
