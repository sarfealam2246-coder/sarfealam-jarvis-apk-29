import { useState } from 'react';
import {
  CheckCircle2,
  CreditCard,
  MapPin,
  Minus,
  Navigation,
  Plus,
  QrCode,
  Receipt,
  Search,
  ShieldCheck,
  ShoppingBag,
  Sparkles,
  TrendingUp,
  Wallet,
} from 'lucide-react';
import { CommercialAppConfig } from '../types';

interface CommercialAppPreviewProps {
  config: CommercialAppConfig;
  buildStage: number;
}

// 1. E-COMMERCE / QUICK-COMMERCE PREVIEW
function EcommercePreview({ config }: { config: CommercialAppConfig }) {
  const [tab, setTab] = useState<'shop' | 'cart' | 'orders'>('shop');
  const [cat, setCat] = useState('All');
  const [query, setQuery] = useState('');
  const [coupon, setCoupon] = useState('');
  const [discountApplied, setDiscountApplied] = useState(config.discountPercent || 0);
  const [selectedId, setSelectedId] = useState<string | null>(null);
  const [orderPlaced, setOrderPlaced] = useState(false);

  const products = [
    { id: 'p1', name: 'Artisan Cold Brew Pack', cat: 'Express', price: 240, rating: '4.8', eta: '10 min' },
    { id: 'p2', name: 'Wireless Studio Earbuds', cat: 'Tech', price: 1890, rating: '4.9', eta: '18 min' },
    { id: 'p3', name: 'Organic Fresh Basket', cat: 'Express', price: 420, rating: '4.7', eta: '12 min' },
    { id: 'p4', name: 'Minimalist Smart Watch', cat: 'Tech', price: 2790, rating: '4.8', eta: '25 min' },
    { id: 'p5', name: 'Cotton Overshirt', cat: 'Style', price: 1290, rating: '4.6', eta: '22 min' },
    { id: 'p6', name: 'Insulated Travel Flask', cat: 'Style', price: 680, rating: '4.9', eta: '15 min' },
  ];

  const [cart, setCart] = useState<Record<string, number>>({ p1: 1, p2: 1 });

  const updateQty = (id: string, delta: number) => {
    setCart((prev) => {
      const next = (prev[id] || 0) + delta;
      if (next <= 0) {
        const copy = { ...prev };
        delete copy[id];
        return copy;
      }
      return { ...prev, [id]: next };
    });
  };

  const filtered = products.filter(
    (p) =>
      (cat === 'All' || p.cat === cat) &&
      p.name.toLowerCase().includes(query.trim().toLowerCase())
  );

  const subtotal = Object.entries(cart).reduce((sum, [id, qty]) => {
    const item = products.find((p) => p.id === id);
    return sum + (item ? item.price * qty : 0);
  }, 0);
  const discountAmt = Math.round((subtotal * discountApplied) / 100);
  const total = Math.max(0, subtotal - discountAmt);
  const cartCount = Object.values(cart).reduce((a, b) => a + b, 0);
  const detailItem = products.find((p) => p.id === selectedId);

  return (
    <div className="flex flex-col h-full bg-[#090e1a] text-slate-100">
      {/* Banner */}
      <div
        className="px-4 py-3 border-b border-white/10 flex items-center justify-between gap-2"
        style={{ background: `linear-gradient(90deg, ${config.primaryColor}22, #0f172a)` }}
      >
        <div className="min-w-0">
          <div className="text-sm font-bold text-white truncate">{config.appName}</div>
          <div className="text-[11px] text-cyan-300 truncate">{config.bannerText}</div>
        </div>
        <button
          type="button"
          onClick={() => setTab('cart')}
          className="px-3 py-1.5 rounded-lg bg-cyan-500/20 border border-cyan-400/40 text-xs font-semibold text-cyan-200 flex items-center gap-1.5 shrink-0"
        >
          <ShoppingBag className="w-3.5 h-3.5" />
          <span className="tabular-nums">{cartCount}</span>
        </button>
      </div>

      {config.customBannerDataUrl && (
        <img
          src={config.customBannerDataUrl}
          alt="Generated App Banner"
          referrerPolicy="no-referrer"
          className="w-full h-24 object-cover border-b border-white/10"
        />
      )}

      {/* Body */}
      <div className="flex-1 overflow-y-auto p-3 space-y-3">
        {tab === 'shop' && (
          <>
            <div className="flex items-center gap-2 bg-[#0f172a] border border-white/10 rounded-xl px-3 py-2">
              <Search className="w-4 h-4 text-slate-400 shrink-0" />
              <input
                value={query}
                onChange={(e) => setQuery(e.target.value)}
                placeholder="Search products, snacks, tech..."
                className="bg-transparent text-xs text-white w-full focus:outline-none"
              />
            </div>

            <div className="flex items-center gap-1.5 overflow-x-auto pb-1">
              {['All', 'Express', 'Tech', 'Style'].map((c) => (
                <button
                  key={c}
                  type="button"
                  onClick={() => setCat(c)}
                  className={`px-3 py-1.5 rounded-lg text-xs font-medium whitespace-nowrap ${
                    cat === c ? 'bg-cyan-500 text-slate-950' : 'bg-[#0f172a] text-slate-300 border border-white/10'
                  }`}
                >
                  {c}
                </button>
              ))}
            </div>

            {detailItem && (
              <div className="p-3 rounded-xl bg-[#0f172a] border border-cyan-500/40 space-y-2">
                <div className="flex items-center justify-between">
                  <div className="text-sm font-semibold text-white">{detailItem.name}</div>
                  <button
                    type="button"
                    onClick={() => setSelectedId(null)}
                    className="text-xs text-slate-400 hover:text-white"
                  >
                    Close
                  </button>
                </div>
                <div className="text-xs text-slate-400">
                  {detailItem.cat} · Rating {detailItem.rating} · Delivers in {detailItem.eta}
                </div>
                <div className="flex items-center justify-between pt-1">
                  <span className="text-base font-bold text-emerald-400 font-mono tabular-nums">
                    {config.currency}
                    {detailItem.price}
                  </span>
                  <button
                    type="button"
                    onClick={() => updateQty(detailItem.id, 1)}
                    className="px-3 py-1.5 rounded-lg bg-cyan-500 text-slate-950 text-xs font-semibold"
                  >
                    Add to Cart
                  </button>
                </div>
              </div>
            )}

            <div className="grid grid-cols-2 gap-2.5">
              {filtered.map((item) => {
                const qty = cart[item.id] || 0;
                return (
                  <div
                    key={item.id}
                    className="p-3 rounded-xl bg-[#0f172a] border border-white/10 flex flex-col justify-between gap-2"
                  >
                    <button
                      type="button"
                      onClick={() => setSelectedId(item.id)}
                      className="text-left"
                    >
                      <div className="text-[11px] text-slate-400">
                        {item.cat} · {item.eta}
                      </div>
                      <div className="text-xs font-semibold text-white mt-0.5 line-clamp-2">
                        {item.name}
                      </div>
                    </button>
                    <div className="flex items-center justify-between pt-1">
                      <span className="text-xs font-bold text-emerald-400 font-mono tabular-nums">
                        {config.currency}
                        {item.price}
                      </span>
                      {qty === 0 ? (
                        <button
                          type="button"
                          onClick={() => updateQty(item.id, 1)}
                          className="px-2.5 py-1 rounded-md bg-cyan-500/20 border border-cyan-400/40 text-[11px] font-semibold text-cyan-200"
                        >
                          Add
                        </button>
                      ) : (
                        <div className="flex items-center gap-1.5 bg-cyan-500/20 rounded-md px-1.5 py-0.5">
                          <button type="button" onClick={() => updateQty(item.id, -1)}>
                            <Minus className="w-3 h-3 text-cyan-200" />
                          </button>
                          <span className="text-xs font-mono tabular-nums">{qty}</span>
                          <button type="button" onClick={() => updateQty(item.id, 1)}>
                            <Plus className="w-3 h-3 text-cyan-200" />
                          </button>
                        </div>
                      )}
                    </div>
                  </div>
                );
              })}
            </div>
          </>
        )}

        {tab === 'cart' && (
          <div className="space-y-3">
            {Object.keys(cart).length === 0 ? (
              <div className="text-center py-8 text-xs text-slate-400">Your cart is empty.</div>
            ) : (
              <>
                {Object.entries(cart).map(([id, qty]) => {
                  const p = products.find((x) => x.id === id);
                  if (!p) return null;
                  return (
                    <div
                      key={id}
                      className="flex items-center justify-between p-2.5 rounded-xl bg-[#0f172a] border border-white/10"
                    >
                      <div>
                        <div className="text-xs font-semibold text-white">{p.name}</div>
                        <div className="text-[11px] text-slate-400 font-mono tabular-nums">
                          {config.currency}
                          {p.price} × {qty}
                        </div>
                      </div>
                      <div className="flex items-center gap-2">
                        <button
                          type="button"
                          onClick={() => updateQty(id, -1)}
                          className="w-7 h-7 rounded-lg bg-white/5 flex items-center justify-center"
                        >
                          <Minus className="w-3.5 h-3.5" />
                        </button>
                        <span className="text-xs font-mono tabular-nums">{qty}</span>
                        <button
                          type="button"
                          onClick={() => updateQty(id, 1)}
                          className="w-7 h-7 rounded-lg bg-white/5 flex items-center justify-center"
                        >
                          <Plus className="w-3.5 h-3.5" />
                        </button>
                      </div>
                    </div>
                  );
                })}

                <div className="flex gap-2">
                  <input
                    value={coupon}
                    onChange={(e) => setCoupon(e.target.value)}
                    placeholder="Coupon: SAVE15 or FIRST25"
                    className="flex-1 px-3 py-2 rounded-xl bg-[#0f172a] border border-white/10 text-xs text-white focus:outline-none"
                  />
                  <button
                    type="button"
                    onClick={() => {
                      const code = coupon.trim().toUpperCase();
                      if (code === 'FIRST25') setDiscountApplied(25);
                      else if (code === 'SAVE15') setDiscountApplied(15);
                      else setDiscountApplied(10);
                    }}
                    className="px-3 py-2 rounded-xl bg-purple-500/25 border border-purple-400/40 text-xs font-semibold text-purple-200"
                  >
                    Apply
                  </button>
                </div>

                <div className="p-3 rounded-xl bg-[#0f172a] border border-white/10 space-y-1.5 text-xs">
                  <div className="flex justify-between text-slate-400">
                    <span>Subtotal</span>
                    <span className="font-mono tabular-nums">
                      {config.currency}
                      {subtotal}
                    </span>
                  </div>
                  <div className="flex justify-between text-emerald-400">
                    <span>Discount ({discountApplied}%)</span>
                    <span className="font-mono tabular-nums">
                      -{config.currency}
                      {discountAmt}
                    </span>
                  </div>
                  <div className="flex justify-between text-sm font-bold text-white pt-1 border-t border-white/10">
                    <span>Total Payable</span>
                    <span className="font-mono tabular-nums">
                      {config.currency}
                      {total}
                    </span>
                  </div>
                </div>

                <button
                  type="button"
                  onClick={() => {
                    setOrderPlaced(true);
                    setTab('orders');
                  }}
                  className="w-full py-2.5 rounded-xl bg-emerald-500 text-slate-950 text-xs font-bold"
                >
                  Confirm & Place Order
                </button>
              </>
            )}
          </div>
        )}

        {tab === 'orders' && (
          <div className="p-4 rounded-xl bg-[#0f172a] border border-emerald-500/30 space-y-3">
            <div className="flex items-center gap-2 text-emerald-400 text-sm font-semibold">
              <CheckCircle2 className="w-4 h-4" />
              <span>{orderPlaced ? 'Order #AS-4092 Confirmed' : 'Live Order Tracker Ready'}</span>
            </div>
            <div className="space-y-2 text-xs text-slate-300">
              <div className="flex justify-between">
                <span>1. Order Accepted</span>
                <span className="text-emerald-400">Done</span>
              </div>
              <div className="flex justify-between">
                <span>2. Packing at Hub</span>
                <span className="text-cyan-400">In Progress</span>
              </div>
              <div className="flex justify-between text-slate-500">
                <span>3. Out for Delivery</span>
                <span>ETA 12 min</span>
              </div>
            </div>
          </div>
        )}
      </div>

      {/* Bottom Tabs */}
      <div className="grid grid-cols-3 border-t border-white/10 bg-[#070b14] text-xs">
        {(
          [
            ['shop', 'Shop'],
            ['cart', `Cart (${cartCount})`],
            ['orders', 'Track'],
          ] as const
        ).map(([id, label]) => (
          <button
            key={id}
            type="button"
            onClick={() => setTab(id)}
            className={`py-2.5 font-medium ${tab === id ? 'text-cyan-400 border-t-2 border-cyan-400' : 'text-slate-400'}`}
          >
            {label}
          </button>
        ))}
      </div>
    </div>
  );
}

// 2. KHATA BOOK / POS BILLING PREVIEW
function KhataPosPreview({ config }: { config: CommercialAppConfig }) {
  const [customers, setCustomers] = useState([
    { id: 'c1', name: 'Ramesh Kirana Store', balance: 2450, lastNote: 'Wheat & Oil Supply' },
    { id: 'c2', name: 'Aarti Hardware', balance: -820, lastNote: 'Advance Jama via UPI' },
    { id: 'c3', name: 'Suresh Traders', balance: 4100, lastNote: 'GST Invoice #118' },
  ]);
  const [selectedId, setSelectedId] = useState('c1');
  const [amount, setAmount] = useState('');
  const [note, setNote] = useState('');
  const [showQr, setShowQr] = useState(false);
  const [showInvoice, setShowInvoice] = useState(false);

  const selected = customers.find((c) => c.id === selectedId) || customers[0];
  const totalReceivable = customers.reduce((acc, c) => acc + (c.balance > 0 ? c.balance : 0), 0);
  const totalPayable = customers.reduce((acc, c) => acc + (c.balance < 0 ? Math.abs(c.balance) : 0), 0);

  const postEntry = (type: 'udhar' | 'jama') => {
    const val = Number(amount);
    if (!val || val <= 0) return;
    setCustomers((prev) =>
      prev.map((c) =>
        c.id === selected.id
          ? {
              ...c,
              balance: type === 'udhar' ? c.balance + val : c.balance - val,
              lastNote: note.trim() || (type === 'udhar' ? 'Udhar (Credit)' : 'Jama (Received)'),
            }
          : c
      )
    );
    setAmount('');
    setNote('');
  };

  return (
    <div className="flex flex-col h-full bg-[#090e1a] text-slate-100">
      <div className="px-4 py-3 border-b border-white/10 bg-[#0f172a] flex items-center justify-between">
        <div>
          <div className="text-sm font-bold text-white">{config.appName}</div>
          <div className="text-[11px] text-emerald-400">Net Khata & POS Ledger</div>
        </div>
        <div className="flex gap-1.5">
          <button
            type="button"
            onClick={() => {
              setShowQr((v) => !v);
              setShowInvoice(false);
            }}
            className="px-2.5 py-1.5 rounded-lg bg-cyan-500/20 border border-cyan-400/40 text-xs text-cyan-200 flex items-center gap-1"
          >
            <QrCode className="w-3.5 h-3.5" /> UPI QR
          </button>
          <button
            type="button"
            onClick={() => {
              setShowInvoice((v) => !v);
              setShowQr(false);
            }}
            className="px-2.5 py-1.5 rounded-lg bg-purple-500/20 border border-purple-400/40 text-xs text-purple-200 flex items-center gap-1"
          >
            <Receipt className="w-3.5 h-3.5" /> Invoice
          </button>
        </div>
      </div>

      <div className="flex-1 overflow-y-auto p-3 space-y-3">
        {/* Net Balance Row */}
        <div className="grid grid-cols-2 gap-2.5">
          <div className="p-3 rounded-xl bg-[#0f172a] border border-emerald-500/30">
            <div className="text-[11px] text-slate-400">You Will Get (Udhar)</div>
            <div className="text-lg font-bold text-emerald-400 font-mono tabular-nums">
              {config.currency}
              {totalReceivable.toLocaleString()}
            </div>
          </div>
          <div className="p-3 rounded-xl bg-[#0f172a] border border-rose-500/30">
            <div className="text-[11px] text-slate-400">You Will Give (Jama)</div>
            <div className="text-lg font-bold text-rose-400 font-mono tabular-nums">
              {config.currency}
              {totalPayable.toLocaleString()}
            </div>
          </div>
        </div>

        {showQr && (
          <div className="p-3 rounded-xl bg-[#0f172a] border border-cyan-500/40 text-center space-y-2">
            <div className="text-xs font-semibold text-cyan-300">
              Instant UPI Payment QR · {selected.name}
            </div>
            <div className="w-28 h-28 mx-auto rounded-lg bg-white p-2 grid grid-cols-5 gap-1">
              {Array.from({ length: 25 }).map((_, i) => (
                <div
                  key={i}
                  className={i % 2 === 0 || i % 3 === 0 ? 'bg-slate-950 rounded-[1px]' : 'bg-white'}
                />
              ))}
            </div>
            <div className="text-[11px] text-slate-400 font-mono">
              upi://pay?pa=merchant@upi&am={Math.abs(selected.balance)}
            </div>
          </div>
        )}

        {showInvoice && (
          <div className="p-3 rounded-xl bg-white text-slate-900 space-y-1.5 text-xs">
            <div className="flex justify-between font-bold border-b border-slate-200 pb-1">
              <span>{config.appName}</span>
              <span>TAX INVOICE</span>
            </div>
            <div>Party: {selected.name}</div>
            <div>Particulars: {selected.lastNote}</div>
            <div className="flex justify-between font-bold pt-1 border-t border-slate-200 font-mono tabular-nums">
              <span>Net Payable</span>
              <span>
                {config.currency}
                {Math.abs(selected.balance).toLocaleString()}
              </span>
            </div>
          </div>
        )}

        {/* Party List */}
        <div className="space-y-1.5">
          {customers.map((c) => (
            <button
              key={c.id}
              type="button"
              onClick={() => setSelectedId(c.id)}
              className={`w-full p-2.5 rounded-xl border text-left flex items-center justify-between ${
                c.id === selected.id
                  ? 'bg-cyan-500/10 border-cyan-400/50'
                  : 'bg-[#0f172a] border-white/10'
              }`}
            >
              <div>
                <div className="text-xs font-semibold text-white">{c.name}</div>
                <div className="text-[11px] text-slate-400">{c.lastNote}</div>
              </div>
              <div
                className={`text-xs font-bold font-mono tabular-nums ${
                  c.balance >= 0 ? 'text-emerald-400' : 'text-rose-400'
                }`}
              >
                {c.balance >= 0 ? '+' : '-'}
                {config.currency}
                {Math.abs(c.balance).toLocaleString()}
              </div>
            </button>
          ))}
        </div>

        {/* Udhar / Jama Entry Form */}
        <div className="p-3 rounded-xl bg-[#0f172a] border border-white/10 space-y-2">
          <div className="text-xs font-semibold text-slate-200">
            New Entry for {selected.name}
          </div>
          <div className="grid grid-cols-2 gap-2">
            <input
              type="number"
              value={amount}
              onChange={(e) => setAmount(e.target.value)}
              placeholder={`Amount (${config.currency})`}
              className="px-2.5 py-2 rounded-lg bg-[#070b14] border border-white/10 text-xs text-white focus:outline-none"
            />
            <input
              value={note}
              onChange={(e) => setNote(e.target.value)}
              placeholder="Item / Note"
              className="px-2.5 py-2 rounded-lg bg-[#070b14] border border-white/10 text-xs text-white focus:outline-none"
            />
          </div>
          <div className="grid grid-cols-2 gap-2">
            <button
              type="button"
              onClick={() => postEntry('udhar')}
              className="py-2 rounded-lg bg-rose-500/20 border border-rose-400/40 text-xs font-semibold text-rose-200"
            >
              + Udhar (Credit)
            </button>
            <button
              type="button"
              onClick={() => postEntry('jama')}
              className="py-2 rounded-lg bg-emerald-500/20 border border-emerald-400/40 text-xs font-semibold text-emerald-200"
            >
              + Jama (Debit)
            </button>
          </div>
        </div>
      </div>
    </div>
  );
}

// 3. RIDE / DELIVERY / SERVICE BOOKING PREVIEW
function RideBookingPreview({ config }: { config: CommercialAppConfig }) {
  const [pickup, setPickup] = useState('Central Metro Gate 2');
  const [drop, setDrop] = useState('Tech Park Sector 14');
  const [tier, setTier] = useState<'moto' | 'mini' | 'sedan'>('mini');
  const [booked, setBooked] = useState(false);

  const tiers = {
    moto: { name: 'Express Moto', eta: '3 min', fare: 64 },
    mini: { name: 'City Compact', eta: '5 min', fare: 148 },
    sedan: { name: 'Prime Sedan', eta: '7 min', fare: 224 },
  };

  return (
    <div className="flex flex-col h-full bg-[#090e1a] text-slate-100">
      <div className="px-4 py-3 border-b border-white/10 bg-[#0f172a] flex justify-between items-center">
        <div>
          <div className="text-sm font-bold text-white">{config.appName}</div>
          <div className="text-[11px] text-purple-300">{config.bannerText}</div>
        </div>
        <Navigation className="w-4 h-4 text-cyan-400" />
      </div>

      <div className="flex-1 overflow-y-auto p-3 space-y-3">
        {/* Interactive Route Map Card */}
        <div className="relative h-32 rounded-xl bg-[#0f172a] border border-cyan-500/30 overflow-hidden p-3 flex flex-col justify-between">
          <svg className="absolute inset-0 w-full h-full opacity-35" viewBox="0 0 320 120">
            <path d="M 30 92 Q 110 25, 190 65 T 290 28" fill="none" stroke="#06b6d4" strokeWidth="3" strokeDasharray="6 4" />
            <circle cx="30" cy="92" r="5" fill="#10b981" />
            <circle cx="290" cy="28" r="5" fill="#8b5cf6" />
          </svg>
          <div className="relative z-10 text-xs font-semibold text-white">
            Live Route · 8.4 km · Est. 19 mins
          </div>
          <div className="relative z-10 text-[11px] text-cyan-300">
            {booked ? 'Driver Vikram arriving in 3 mins (DL-04-AX-9281)' : 'Select vehicle tier to dispatch'}
          </div>
        </div>

        <div className="space-y-2">
          <div className="flex items-center gap-2 bg-[#0f172a] border border-white/10 rounded-xl px-3 py-2">
            <MapPin className="w-4 h-4 text-emerald-400 shrink-0" />
            <input
              value={pickup}
              onChange={(e) => setPickup(e.target.value)}
              className="bg-transparent text-xs text-white w-full focus:outline-none"
            />
          </div>
          <div className="flex items-center gap-2 bg-[#0f172a] border border-white/10 rounded-xl px-3 py-2">
            <MapPin className="w-4 h-4 text-purple-400 shrink-0" />
            <input
              value={drop}
              onChange={(e) => setDrop(e.target.value)}
              className="bg-transparent text-xs text-white w-full focus:outline-none"
            />
          </div>
        </div>

        <div className="space-y-1.5">
          {(['moto', 'mini', 'sedan'] as const).map((k) => {
            const item = tiers[k];
            return (
              <button
                key={k}
                type="button"
                onClick={() => setTier(k)}
                className={`w-full p-2.5 rounded-xl border flex items-center justify-between ${
                  tier === k
                    ? 'bg-purple-500/15 border-purple-400/60'
                    : 'bg-[#0f172a] border-white/10'
                }`}
              >
                <div className="text-left">
                  <div className="text-xs font-semibold text-white">{item.name}</div>
                  <div className="text-[11px] text-slate-400">Pickup in {item.eta}</div>
                </div>
                <div className="text-sm font-bold text-emerald-400 font-mono tabular-nums">
                  {config.currency}
                  {item.fare}
                </div>
              </button>
            );
          })}
        </div>

        <button
          type="button"
          onClick={() => setBooked((b) => !b)}
          className="w-full py-2.5 rounded-xl bg-cyan-500 text-slate-950 text-xs font-bold"
        >
          {booked ? 'Cancel Active Ride' : `Confirm ${tiers[tier].name} (${config.currency}${tiers[tier].fare})`}
        </button>
      </div>
    </div>
  );
}

// 4. BANKING / WALLET / FINANCE / FANTASY ANALYTICS PREVIEW
function FinanceWalletPreview({ config }: { config: CommercialAppConfig }) {
  const [balance, setBalance] = useState(18450);
  const [vip, setVip] = useState(Boolean(config.vipUnlocked));
  const [showKyc, setShowKyc] = useState(false);
  const [otp, setOtp] = useState('');
  const [kycVerified, setKycVerified] = useState(false);
  const [txs, setTxs] = useState([
    { id: 't1', label: 'Instant UPI Top-up', amt: 5000, time: 'Today, 11:20' },
    { id: 't2', label: 'Market Signal Payout', amt: 2450, time: 'Yesterday' },
    { id: 't3', label: 'Bank Withdrawal', amt: -1200, time: '2 days ago' },
  ]);

  const mutateBalance = (delta: number, label: string) => {
    setBalance((b) => Math.max(0, b + delta));
    setTxs((prev) => [{ id: `t_${Date.now()}`, label, amt: delta, time: 'Just now' }, ...prev]);
  };

  return (
    <div className="flex flex-col h-full bg-[#090e1a] text-slate-100">
      <div className="px-4 py-3 border-b border-white/10 bg-[#0f172a] flex justify-between items-center">
        <div>
          <div className="text-sm font-bold text-white">{config.appName}</div>
          <div className="text-[11px] text-cyan-300">
            {vip ? 'VIP Pro Tier Unlocked' : 'Standard Wallet'}
          </div>
        </div>
        <Wallet className="w-4 h-4 text-emerald-400" />
      </div>

      <div className="flex-1 overflow-y-auto p-3 space-y-3">
        <div className="p-4 rounded-2xl bg-gradient-to-br from-cyan-950/80 via-[#0f172a] to-purple-950/60 border border-cyan-500/30 space-y-3">
          <div className="flex justify-between items-center text-xs text-slate-300">
            <span>Available Balance</span>
            <span className="text-emerald-400">{kycVerified ? 'KYC Verified' : 'KYC Pending'}</span>
          </div>
          <div className="text-2xl font-bold text-white font-mono tabular-nums">
            {config.currency}
            {balance.toLocaleString()}
          </div>
          <div className="grid grid-cols-2 gap-2">
            <button
              type="button"
              onClick={() => mutateBalance(1000, 'Wallet Deposit')}
              className="py-2 rounded-lg bg-emerald-500 text-slate-950 text-xs font-bold"
            >
              + Add {config.currency}1,000
            </button>
            <button
              type="button"
              onClick={() => mutateBalance(-500, 'Instant Withdraw')}
              className="py-2 rounded-lg bg-white/10 text-white text-xs font-semibold"
            >
              Withdraw {config.currency}500
            </button>
          </div>
        </div>

        {/* Live Analytics / Odds Strip */}
        <div className="grid grid-cols-2 gap-2">
          <div className="p-2.5 rounded-xl bg-[#0f172a] border border-white/10">
            <div className="flex items-center gap-1 text-[11px] text-slate-400">
              <TrendingUp className="w-3.5 h-3.5 text-emerald-400" /> Live Index
            </div>
            <div className="text-sm font-bold text-emerald-400 font-mono tabular-nums mt-0.5">
              +14.8% ROI
            </div>
          </div>
          <button
            type="button"
            onClick={() => setVip((v) => !v)}
            className="p-2.5 rounded-xl bg-[#0f172a] border border-purple-400/30 text-left"
          >
            <div className="flex items-center gap-1 text-[11px] text-purple-300">
              <Sparkles className="w-3.5 h-3.5" /> VIP Access
            </div>
            <div className="text-xs font-semibold text-white mt-0.5">
              {vip ? 'Active · Tap to Lock' : 'Tap to Unlock VIP'}
            </div>
          </button>
        </div>

        {/* KYC / OTP Verification */}
        {showKyc ? (
          <div className="p-3 rounded-xl bg-[#0f172a] border border-cyan-500/40 space-y-2">
            <div className="text-xs font-semibold text-white flex items-center gap-1.5">
              <ShieldCheck className="w-4 h-4 text-cyan-400" /> Instant KYC OTP Verification
            </div>
            <div className="flex gap-2">
              <input
                value={otp}
                onChange={(e) => setOtp(e.target.value)}
                placeholder="Enter 4-digit OTP (e.g. 4821)"
                className="flex-1 px-2.5 py-1.5 rounded-lg bg-[#070b14] border border-white/10 text-xs text-white"
              />
              <button
                type="button"
                onClick={() => {
                  if (otp.trim().length >= 4) {
                    setKycVerified(true);
                    setShowKyc(false);
                  }
                }}
                className="px-3 py-1.5 rounded-lg bg-cyan-500 text-slate-950 text-xs font-bold"
              >
                Verify
              </button>
            </div>
          </div>
        ) : (
          <button
            type="button"
            onClick={() => setShowKyc(true)}
            className="w-full py-2 rounded-xl bg-[#0f172a] border border-white/10 text-xs text-cyan-300 flex items-center justify-center gap-1.5"
          >
            <CreditCard className="w-3.5 h-3.5" /> {kycVerified ? 'Re-verify KYC' : 'Complete KYC / OTP'}
          </button>
        )}

        {/* Ledger */}
        <div className="space-y-1.5">
          {txs.slice(0, 4).map((tx) => (
            <div
              key={tx.id}
              className="flex items-center justify-between p-2.5 rounded-xl bg-[#0f172a] border border-white/10 text-xs"
            >
              <div>
                <div className="font-medium text-white">{tx.label}</div>
                <div className="text-[11px] text-slate-400">{tx.time}</div>
              </div>
              <span
                className={`font-bold font-mono tabular-nums ${
                  tx.amt >= 0 ? 'text-emerald-400' : 'text-rose-400'
                }`}
              >
                {tx.amt >= 0 ? '+' : '-'}
                {config.currency}
                {Math.abs(tx.amt).toLocaleString()}
              </span>
            </div>
          ))}
        </div>
      </div>
    </div>
  );
}

// 5. CARD / BOARD TABLE GAME PREVIEW (Teen Patti / Rummy / Strategy)
function CardBoardPreview({ config }: { config: CommercialAppConfig }) {
  const [pot, setPot] = useState(1200);
  const [chips, setChips] = useState(9500);
  const [revealed, setRevealed] = useState(false);
  const [hand, setHand] = useState(['A♠', 'K♠', 'Q♠']);
  const [status, setStatus] = useState('Your Turn · 18s remaining');

  const deck = ['A♠', 'K♠', 'Q♠', 'J♥', '10♦', 'A♥', 'K♣', '9♠', 'Q♦', 'A♣'];

  const dealNew = () => {
    const shuffled = [...deck].sort(() => Math.random() - 0.5).slice(0, 3);
    setHand(shuffled);
    setPot(600);
    setRevealed(false);
    setStatus('New Hand Dealt · Choose Chaal / Fold / Show');
  };

  return (
    <div className="flex flex-col h-full bg-[#090e1a] text-slate-100">
      <div className="px-4 py-3 border-b border-white/10 bg-[#0f172a] flex justify-between items-center">
        <div>
          <div className="text-sm font-bold text-white">{config.appName}</div>
          <div className="text-[11px] text-emerald-400">{status}</div>
        </div>
        <div className="text-xs font-mono tabular-nums text-amber-300">
          Chips: {config.currency}
          {chips.toLocaleString()}
        </div>
      </div>

      <div className="flex-1 p-3 flex flex-col justify-between gap-3">
        {/* Green Felt Table */}
        <div className="flex-1 rounded-2xl bg-gradient-to-b from-emerald-950 via-emerald-900/80 to-emerald-950 border-2 border-amber-500/40 p-4 flex flex-col justify-between items-center relative">
          <div className="w-full flex justify-between text-[11px] text-emerald-200">
            <span>Seat 1 · Rohan (Playing)</span>
            <span>Seat 2 · Maya (Blind)</span>
          </div>

          <div className="text-center space-y-1">
            <div className="text-[11px] text-amber-300">TABLE POT</div>
            <div className="text-2xl font-bold text-white font-mono tabular-nums">
              {config.currency}
              {pot.toLocaleString()}
            </div>
          </div>

          <div className="flex items-center gap-2.5">
            {hand.map((card, i) => (
              <div
                key={i}
                className={`w-14 h-20 rounded-xl border flex items-center justify-center text-lg font-bold shadow-md ${
                  revealed
                    ? 'bg-white text-slate-950 border-slate-300'
                    : 'bg-[#0f172a] text-cyan-400 border-cyan-500/40'
                }`}
              >
                {revealed ? card : '?'}
              </div>
            ))}
          </div>
        </div>

        {/* Interactive Controls */}
        <div className="grid grid-cols-4 gap-2">
          <button
            type="button"
            onClick={() => setRevealed(true)}
            className="py-2.5 rounded-xl bg-cyan-500/20 border border-cyan-400/40 text-xs font-semibold text-cyan-200"
          >
            See
          </button>
          <button
            type="button"
            onClick={() => {
              setPot((p) => p + 400);
              setChips((c) => Math.max(0, c - 400));
              setStatus('Chaal +400 placed!');
            }}
            className="py-2.5 rounded-xl bg-emerald-500 text-slate-950 text-xs font-bold"
          >
            Bet
          </button>
          <button
            type="button"
            onClick={() => {
              setRevealed(true);
              setChips((c) => c + pot);
              setPot(0);
              setStatus('Showdown Won! Pot collected.');
            }}
            className="py-2.5 rounded-xl bg-amber-500 text-slate-950 text-xs font-bold"
          >
            Show
          </button>
          <button
            type="button"
            onClick={dealNew}
            className="py-2.5 rounded-xl bg-white/10 text-xs font-semibold text-white"
          >
            Deal
          </button>
        </div>
      </div>
    </div>
  );
}

export function CommercialAppPreview({ config, buildStage }: CommercialAppPreviewProps) {
  if (buildStage < 2) {
    return (
      <div className="w-full h-full bg-[#090e1a] flex flex-col items-center justify-center p-6 text-center space-y-2">
        <div className="text-sm font-semibold text-cyan-300">
          Stage {buildStage}/5 · Assembling {config.appName}
        </div>
        <div className="text-xs text-slate-400 max-w-xs">{config.tagline}</div>
      </div>
    );
  }

  switch (config.category) {
    case 'khata_pos':
      return <KhataPosPreview config={config} />;
    case 'ride_booking':
      return <RideBookingPreview config={config} />;
    case 'finance_wallet':
      return <FinanceWalletPreview config={config} />;
    case 'card_board':
      return <CardBoardPreview config={config} />;
    case 'ecommerce':
    default:
      return <EcommercePreview config={config} />;
  }
}
