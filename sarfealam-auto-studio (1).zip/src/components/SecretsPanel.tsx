import { useState } from 'react';
import {
  CheckCircle2,
  Copy,
  Database,
  Eye,
  EyeOff,
  Github,
  KeyRound,
  Plus,
  Smartphone,
  Trash2,
} from 'lucide-react';
import {
  DepartmentAssignment,
  Language,
  SecretsState,
} from '../types';
import { detectProviderFromKey } from '../services/secretsEngine';
import { validateGitHubCredentials } from '../services/githubExporter';
import {
  APPS_SUPABASE_SQL,
  STUDIO_SUPABASE_SQL,
  testSupabaseConnection,
} from '../services/supabaseClient';
import { t } from '../services/i18n';

interface SecretsPanelProps {
  lang: Language;
  secrets: SecretsState;
  routing: DepartmentAssignment[];
  onSaveSecrets: (next: SecretsState, announceRouting: boolean) => void;
  onRestoreFromStudioSupabase: () => void;
}

export function SecretsPanel({
  lang,
  secrets,
  routing,
  onSaveSecrets,
  onRestoreFromStudioSupabase,
}: SecretsPanelProps) {
  const [draft, setDraft] = useState<SecretsState>(secrets);
  const [revealKeys, setRevealKeys] = useState(false);
  const [ghBusy, setGhBusy] = useState(false);
  const [ghStatus, setGhStatus] = useState<string | null>(null);
  const [studioBusy, setStudioBusy] = useState(false);
  const [studioStatus, setStudioStatus] = useState<string | null>(null);
  const [appsBusy, setAppsBusy] = useState(false);
  const [appsStatus, setAppsStatus] = useState<string | null>(null);
  const [copiedSql, setCopiedSql] = useState<'studio' | 'apps' | null>(null);

  const updateKeyValue = (id: string, value: string) => {
    const detected = detectProviderFromKey(value);
    setDraft((prev) => ({
      ...prev,
      apiKeys: prev.apiKeys.map((k) =>
        k.id === id
          ? {
              ...k,
              value,
              provider: detected.provider,
              providerLabel: detected.label,
              verified: Boolean(detected.provider),
            }
          : k
      ),
    }));
  };

  const addKeyBox = () => {
    setDraft((prev) => ({
      ...prev,
      apiKeys: [
        ...prev.apiKeys,
        {
          id: `key_${Date.now()}`,
          value: '',
          provider: null,
          providerLabel: 'Empty',
          verified: false,
        },
      ],
    }));
  };

  const removeKeyBox = (id: string) => {
    setDraft((prev) => ({
      ...prev,
      apiKeys: prev.apiKeys.length > 5 ? prev.apiKeys.filter((k) => k.id !== id) : prev.apiKeys.map((k) => (k.id === id ? { ...k, value: '', provider: null, providerLabel: 'Empty', verified: false } : k)),
    }));
  };

  const handleSaveAiKeys = () => {
    onSaveSecrets(draft, true);
  };

  const handleConnectGithub = async () => {
    setGhBusy(true);
    setGhStatus('Validating directly against https://api.github.com/user ...');
    const res = await validateGitHubCredentials(draft.github.username, draft.github.token);
    const updated: SecretsState = {
      ...draft,
      github: {
        ...draft.github,
        username: res.login || draft.github.username.trim(),
        connected: res.ok,
        verifiedLogin: res.login,
        avatarUrl: res.avatarUrl,
        lastCheckedAt: new Date().toISOString(),
        error: res.ok ? undefined : res.message,
      },
    };
    setDraft(updated);
    onSaveSecrets(updated, false);
    setGhStatus(res.message);
    setGhBusy(false);
  };

  const handleTestStudioSupabase = async () => {
    setStudioBusy(true);
    setStudioStatus('Testing direct REST connection to Studio Supabase...');
    const res = await testSupabaseConnection(draft.studioSupabase, 'studio_state');
    const updated: SecretsState = {
      ...draft,
      studioSupabase: {
        ...draft.studioSupabase,
        connected: res.ok,
        lastSyncedAt: res.ok ? new Date().toISOString() : undefined,
        error: res.ok ? undefined : res.message,
      },
    };
    setDraft(updated);
    onSaveSecrets(updated, false);
    setStudioStatus(res.message);
    setStudioBusy(false);
    if (res.ok && res.tableReady) {
      onRestoreFromStudioSupabase();
    }
  };

  const handleTestAppsSupabase = async () => {
    setAppsBusy(true);
    setAppsStatus('Testing direct REST connection to Apps Supabase...');
    const res = await testSupabaseConnection(draft.appsSupabase, 'apps_config');
    const updated: SecretsState = {
      ...draft,
      appsSupabase: {
        ...draft.appsSupabase,
        connected: res.ok,
        lastSyncedAt: res.ok ? new Date().toISOString() : undefined,
        error: res.ok ? undefined : res.message,
      },
    };
    setDraft(updated);
    onSaveSecrets(updated, false);
    setAppsStatus(res.message);
    setAppsBusy(false);
  };

  const copySql = async (which: 'studio' | 'apps') => {
    try {
      await navigator.clipboard.writeText(which === 'studio' ? STUDIO_SUPABASE_SQL : APPS_SUPABASE_SQL);
      setCopiedSql(which);
      setTimeout(() => setCopiedSql(null), 2000);
    } catch {
      // Ignore clipboard failure in restricted WebView
    }
  };

  return (
    <div className="space-y-6 pb-6">
      {/* A) 5 Plain Auto-Detect API Key Boxes */}
      <div className="p-4 rounded-2xl bg-[#0b1120] border border-white/10 space-y-3">
        <div className="flex items-center justify-between gap-2">
          <div className="flex items-center gap-2">
            <KeyRound className="w-4 h-4 text-cyan-400" />
            <h3 className="text-sm font-bold text-white">AI Provider Keys (Auto-Detect)</h3>
          </div>
          <button
            type="button"
            onClick={() => setRevealKeys((r) => !r)}
            className="px-2.5 py-1.5 rounded-lg bg-[#070b14] border border-white/10 text-xs text-slate-300 flex items-center gap-1"
          >
            {revealKeys ? <EyeOff className="w-3.5 h-3.5" /> : <Eye className="w-3.5 h-3.5" />}
            <span>{revealKeys ? 'Hide' : 'Show'}</span>
          </button>
        </div>

        <p className="text-xs text-slate-400">
          Paste any key in any box — Gemini (<code className="text-cyan-300">AIza / AQ.</code>), Groq (<code className="text-cyan-300">gsk_</code>), NVIDIA NIM (<code className="text-cyan-300">nvapi-</code>), OpenRouter (<code className="text-cyan-300">sk-or-v1-</code>), or Cohere. JARVIS auto-assigns departments and fails over automatically.
        </p>

        <div className="space-y-2.5">
          {draft.apiKeys.map((entry) => {
            const detected = detectProviderFromKey(entry.value);
            return (
              <div key={entry.id} className="space-y-1">
                <div className="flex items-center justify-between text-[11px]">
                  <label className="text-slate-300 font-medium">API Key</label>
                  <span className={detected.provider ? 'text-emerald-400 font-medium' : 'text-slate-500'}>
                    {detected.label}
                  </span>
                </div>
                <div className="flex items-center gap-2">
                  <input
                    type={revealKeys ? 'text' : 'password'}
                    value={entry.value}
                    onChange={(e) => updateKeyValue(entry.id, e.target.value)}
                    placeholder="Paste any AI API Key..."
                    className="flex-1 min-h-[42px] px-3 rounded-xl bg-[#070b14] border border-white/10 focus:border-cyan-400/60 text-xs font-mono text-white placeholder:text-slate-600 focus:outline-none"
                  />
                  <button
                    type="button"
                    onClick={() => removeKeyBox(entry.id)}
                    className="min-h-[42px] min-w-[42px] rounded-xl bg-[#070b14] border border-white/10 text-slate-400 hover:text-rose-400 flex items-center justify-center"
                    aria-label="Clear key"
                  >
                    <Trash2 className="w-4 h-4" />
                  </button>
                </div>
              </div>
            );
          })}
        </div>

        <div className="flex flex-wrap items-center gap-2 pt-1">
          <button
            type="button"
            onClick={handleSaveAiKeys}
            className="px-4 py-2.5 min-h-[44px] rounded-xl bg-cyan-500 hover:bg-cyan-400 text-slate-950 text-xs font-bold transition-colors"
          >
            {t(lang, 'saveKeys')}
          </button>
          <button
            type="button"
            onClick={addKeyBox}
            className="px-3.5 py-2.5 min-h-[44px] rounded-xl bg-[#070b14] border border-white/15 text-xs font-medium text-slate-200 flex items-center gap-1"
          >
            <Plus className="w-3.5 h-3.5" />
            <span>{t(lang, 'addKeyBox')}</span>
          </button>
        </div>

        {/* Live Assigned Department Routing Summary */}
        <div className="pt-3 border-t border-white/10 space-y-1.5">
          <div className="text-xs font-semibold text-slate-200">Active Department Routing</div>
          <div className="grid grid-cols-1 sm:grid-cols-2 gap-1.5 text-xs">
            {routing.map((dept) => (
              <div
                key={dept.department}
                className="flex items-center justify-between px-2.5 py-1.5 rounded-lg bg-[#070b14] border border-white/5"
              >
                <span className="text-slate-400 font-medium">{dept.label}</span>
                <span
                  className={`font-mono text-[11px] truncate max-w-[190px] ${
                    dept.available ? 'text-emerald-400' : 'text-slate-500'
                  }`}
                >
                  {dept.available ? dept.model : 'Missing key'}
                </span>
              </div>
            ))}
          </div>
        </div>
      </div>

      {/* B) GitHub Permanent Connection */}
      <div className="p-4 rounded-2xl bg-[#0b1120] border border-white/10 space-y-3">
        <div className="flex items-center justify-between gap-2">
          <div className="flex items-center gap-2">
            <Github className="w-4 h-4 text-white" />
            <h3 className="text-sm font-bold text-white">GitHub Permanent Connection</h3>
          </div>
          <span
            className={`text-xs font-medium ${
              draft.github.connected ? 'text-emerald-400' : 'text-slate-500'
            }`}
          >
            {draft.github.connected
              ? `Connected (@${draft.github.verifiedLogin || draft.github.username})`
              : 'Not Connected'}
          </span>
        </div>

        <p className="text-xs text-slate-400">
          Validates directly via <code className="text-cyan-300">https://api.github.com/user</code>. Required scopes: <code className="text-slate-200">repo</code> and <code className="text-slate-200">workflow</code> for automatic APK Releases & Owner Admin Pages.
        </p>

        <div className="grid grid-cols-1 sm:grid-cols-2 gap-2.5">
          <div className="space-y-1">
            <label className="text-[11px] text-slate-300">GitHub Username</label>
            <input
              value={draft.github.username}
              onChange={(e) =>
                setDraft((p) => ({
                  ...p,
                  github: { ...p.github, username: e.target.value, connected: false },
                }))
              }
              placeholder="e.g. sarfealam2246-coder"
              className="w-full min-h-[42px] px-3 rounded-xl bg-[#070b14] border border-white/10 text-xs text-white focus:outline-none focus:border-cyan-400/60"
            />
          </div>
          <div className="space-y-1">
            <label className="text-[11px] text-slate-300">GitHub PAT Token</label>
            <input
              type={revealKeys ? 'text' : 'password'}
              value={draft.github.token}
              onChange={(e) =>
                setDraft((p) => ({
                  ...p,
                  github: { ...p.github, token: e.target.value, connected: false },
                }))
              }
              placeholder="ghp_... or github_pat_..."
              className="w-full min-h-[42px] px-3 rounded-xl bg-[#070b14] border border-white/10 text-xs font-mono text-white focus:outline-none focus:border-cyan-400/60"
            />
          </div>
        </div>

        <button
          type="button"
          onClick={handleConnectGithub}
          disabled={ghBusy}
          className="px-4 py-2.5 min-h-[44px] rounded-xl bg-emerald-500 hover:bg-emerald-400 text-slate-950 text-xs font-bold transition-colors disabled:opacity-50"
        >
          {ghBusy ? 'Validating with GitHub...' : t(lang, 'connectGithub')}
        </button>

        {ghStatus && (
          <div className={`text-xs ${draft.github.connected ? 'text-emerald-400' : 'text-amber-300'}`}>
            {ghStatus}
          </div>
        )}
      </div>

      {/* C) Dual Supabase Servers (Strict Separation) */}
      <div className="grid grid-cols-1 lg:grid-cols-2 gap-4">
        {/* 1. Studio Supabase */}
        <div className="p-4 rounded-2xl bg-[#0b1120] border border-white/10 space-y-3">
          <div className="flex items-center justify-between gap-2">
            <div className="flex items-center gap-2">
              <Database className="w-4 h-4 text-cyan-400" />
              <h3 className="text-sm font-bold text-white">1. Studio Supabase</h3>
            </div>
            <span className={`text-xs ${draft.studioSupabase.connected ? 'text-emerald-400' : 'text-slate-500'}`}>
              {draft.studioSupabase.connected ? 'Connected' : 'Local Only'}
            </span>
          </div>
          <p className="text-xs text-slate-400">
            Stores ONLY Studio records (<code className="text-slate-200">studio_state</code>, Vault, checkpoints, dynamic skills) across app restarts.
          </p>
          <input
            value={draft.studioSupabase.url}
            onChange={(e) =>
              setDraft((p) => ({
                ...p,
                studioSupabase: { ...p.studioSupabase, url: e.target.value, connected: false },
              }))
            }
            placeholder="https://studio-project.supabase.co"
            className="w-full min-h-[42px] px-3 rounded-xl bg-[#070b14] border border-white/10 text-xs text-white focus:outline-none"
          />
          <input
            type={revealKeys ? 'text' : 'password'}
            value={draft.studioSupabase.anonKey}
            onChange={(e) =>
              setDraft((p) => ({
                ...p,
                studioSupabase: { ...p.studioSupabase, anonKey: e.target.value, connected: false },
              }))
            }
            placeholder="Studio Anon / Publishable Key"
            className="w-full min-h-[42px] px-3 rounded-xl bg-[#070b14] border border-white/10 text-xs font-mono text-white focus:outline-none"
          />
          <div className="flex flex-wrap gap-2">
            <button
              type="button"
              onClick={handleTestStudioSupabase}
              disabled={studioBusy}
              className="px-3.5 py-2 min-h-[40px] rounded-xl bg-cyan-500 text-slate-950 text-xs font-bold"
            >
              {studioBusy ? 'Testing...' : t(lang, 'testSyncStudio')}
            </button>
            <button
              type="button"
              onClick={() => copySql('studio')}
              className="px-3 py-2 min-h-[40px] rounded-xl bg-[#070b14] border border-white/10 text-xs text-slate-300 flex items-center gap-1"
            >
              {copiedSql === 'studio' ? <CheckCircle2 className="w-3.5 h-3.5 text-emerald-400" /> : <Copy className="w-3.5 h-3.5" />}
              <span>{copiedSql === 'studio' ? 'SQL Copied' : 'Copy Table SQL'}</span>
            </button>
          </div>
          {studioStatus && <div className="text-xs text-cyan-300">{studioStatus}</div>}
        </div>

        {/* 2. Apps Supabase */}
        <div className="p-4 rounded-2xl bg-[#0b1120] border border-white/10 space-y-3">
          <div className="flex items-center justify-between gap-2">
            <div className="flex items-center gap-2">
              <Database className="w-4 h-4 text-purple-400" />
              <h3 className="text-sm font-bold text-white">2. Apps Supabase</h3>
            </div>
            <span className={`text-xs ${draft.appsSupabase.connected ? 'text-emerald-400' : 'text-slate-500'}`}>
              {draft.appsSupabase.connected ? 'Connected' : 'Not Configured'}
            </span>
          </div>
          <p className="text-xs text-slate-400">
            Strictly isolated for exported APKs & Owner Admin Web Panels (<code className="text-slate-200">apps_config</code> table).
          </p>
          <input
            value={draft.appsSupabase.url}
            onChange={(e) =>
              setDraft((p) => ({
                ...p,
                appsSupabase: { ...p.appsSupabase, url: e.target.value, connected: false },
              }))
            }
            placeholder="https://apps-project.supabase.co"
            className="w-full min-h-[42px] px-3 rounded-xl bg-[#070b14] border border-white/10 text-xs text-white focus:outline-none"
          />
          <input
            type={revealKeys ? 'text' : 'password'}
            value={draft.appsSupabase.anonKey}
            onChange={(e) =>
              setDraft((p) => ({
                ...p,
                appsSupabase: { ...p.appsSupabase, anonKey: e.target.value, connected: false },
              }))
            }
            placeholder="Apps Anon / Publishable Key"
            className="w-full min-h-[42px] px-3 rounded-xl bg-[#070b14] border border-white/10 text-xs font-mono text-white focus:outline-none"
          />
          <div className="flex flex-wrap gap-2">
            <button
              type="button"
              onClick={handleTestAppsSupabase}
              disabled={appsBusy}
              className="px-3.5 py-2 min-h-[40px] rounded-xl bg-purple-500 text-white text-xs font-bold"
            >
              {appsBusy ? 'Testing...' : t(lang, 'testSyncApps')}
            </button>
            <button
              type="button"
              onClick={() => copySql('apps')}
              className="px-3 py-2 min-h-[40px] rounded-xl bg-[#070b14] border border-white/10 text-xs text-slate-300 flex items-center gap-1"
            >
              {copiedSql === 'apps' ? <CheckCircle2 className="w-3.5 h-3.5 text-emerald-400" /> : <Copy className="w-3.5 h-3.5" />}
              <span>{copiedSql === 'apps' ? 'SQL Copied' : 'Copy Table SQL'}</span>
            </button>
          </div>
          {appsStatus && <div className="text-xs text-purple-300">{appsStatus}</div>}
        </div>
      </div>

      {/* D) Android Capacitor APK Permissions Guide */}
      <div className="p-4 rounded-2xl bg-[#0b1120] border border-white/10 space-y-2">
        <div className="flex items-center gap-2 text-sm font-bold text-white">
          <Smartphone className="w-4 h-4 text-emerald-400" />
          <span>Android Capacitor APK Audio & HTTP Setup</span>
        </div>
        <p className="text-xs text-slate-400">
          <code className="text-emerald-300">capacitor.config.json</code> is pre-configured with <code className="text-cyan-300">"CapacitorHttp": &#123; "enabled": true &#125;</code>. Include these permissions in <code className="text-slate-200">android/app/src/main/AndroidManifest.xml</code> so Live Voice works without mic denials:
        </p>
        <pre className="p-3 rounded-xl bg-[#070b14] border border-white/10 text-[11px] font-mono text-cyan-200 overflow-x-auto">
{`<uses-permission android:name="android.permission.INTERNET" />
<uses-permission android:name="android.permission.RECORD_AUDIO" />
<uses-permission android:name="android.permission.MODIFY_AUDIO_SETTINGS" />`}
        </pre>
      </div>
    </div>
  );
}
